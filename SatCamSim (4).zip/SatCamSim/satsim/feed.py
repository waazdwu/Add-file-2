"""Трансляция кадров бортовой камеры и запись датасетов.

Кадр = изображение (RGB, uint8, H×W×3) + метаданные (точное положение,
ориентация, внутренние параметры камеры, освещённость и т.д.).
Метаданные — это «истина» (ground truth) для будущих исследований:
по ним можно проверять алгоритмы определения горизонта, ориентации,
навигации по ориентирам и т.п.
"""
from __future__ import annotations

import csv
import json
import queue
import threading
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

import cv2
import numpy as np

from . import imgio


@dataclass
class Frame:
    index: int
    image: np.ndarray        # RGB uint8 (H, W, 3)
    meta: dict

    def bgr(self) -> np.ndarray:
        """Тот же кадр в порядке каналов OpenCV."""
        return cv2.cvtColor(self.image, cv2.COLOR_RGB2BGR)


class CameraFeed:
    """Издатель кадров: любой код может подписаться и получать кадры.

    Пример::

        def on_frame(frame):
            gray = cv2.cvtColor(frame.image, cv2.COLOR_RGB2GRAY)
            ...
        unsubscribe = engine.feed.subscribe(on_frame)
    """

    def __init__(self):
        self._subs: list[Callable[[Frame], None]] = []
        self._lock = threading.Lock()
        self.latest: Frame | None = None

    def subscribe(self, fn: Callable[[Frame], None]) -> Callable[[], None]:
        with self._lock:
            self._subs.append(fn)

        def unsubscribe():
            with self._lock:
                if fn in self._subs:
                    self._subs.remove(fn)
        return unsubscribe

    def publish(self, frame: Frame) -> None:
        self.latest = frame
        with self._lock:
            subs = list(self._subs)
        for fn in subs:
            try:
                fn(frame)
            except Exception as exc:     # ошибка подписчика не должна ронять симуляцию
                print(f"[feed] подписчик {fn!r} упал: {exc}")


class Recorder:
    """Запись кадров (PNG и/или MP4) и метаданных (CSV) в папку прогона.

    Запись идёт в фоновом потоке, чтобы не тормозить симуляцию.
    """

    def __init__(self, root: str | Path = "output"):
        self.root = Path(root)
        self.active = False
        self.run_dir: Path | None = None
        self.count = 0
        self._q: queue.Queue = queue.Queue(maxsize=256)
        self._thread: threading.Thread | None = None
        self._csv = None
        self._writer = None
        self._video = None
        self.save_png = True
        self.save_mp4 = False
        self.every_n = 1
        self._seen = 0
        self.dropped = 0

    def start(self, config: dict, save_png: bool = True, save_mp4: bool = False,
              every_n: int = 1, name: str | None = None) -> Path:
        self.stop()
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.run_dir = self.root / (name or f"run_{stamp}")
        (self.run_dir / "frames").mkdir(parents=True, exist_ok=True)
        (self.run_dir / "scenario.json").write_text(
            json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
        self.save_png, self.save_mp4, self.every_n = save_png, save_mp4, max(1, int(every_n))
        self.count = self._seen = self.dropped = 0
        self.active = True
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()
        return self.run_dir

    def push(self, frame: Frame) -> None:
        if not self.active:
            return
        self._seen += 1
        if (self._seen - 1) % self.every_n:
            return
        try:
            self._q.put_nowait(frame)
        except queue.Full:
            self.dropped += 1

    def stop(self) -> None:
        if not self.active:
            return
        self.active = False
        self._q.put(None)
        if self._thread:
            self._thread.join(timeout=30)
        if self._csv:
            self._csv.close()
        if self._video is not None:
            self._video.release()
        self._csv = self._writer = self._video = None

    def _worker(self):
        while True:
            fr = self._q.get()
            if fr is None:
                break
            self._write(fr)

    def _write(self, fr: Frame):
        rd = self.run_dir
        name = f"{self.count:06d}.png"
        if self.save_png:
            imgio.imwrite(rd / "frames" / name, fr.bgr())
        if self.save_mp4:
            if self._video is None:
                h, w = fr.image.shape[:2]
                self._video = imgio.VideoWriter(rd / "video.mp4", 20.0, (w, h))
            self._video.write(fr.bgr())
        row = {"frame": name if self.save_png else "", **_flat(fr.meta)}
        if self._writer is None:
            self._csv = open(rd / "telemetry.csv", "w", newline="", encoding="utf-8-sig")  # BOM — чтобы Excel понял кириллицу
            self._writer = csv.DictWriter(self._csv, fieldnames=list(row.keys()), extrasaction="ignore")
            self._writer.writeheader()
            intr = {k: fr.meta[k] for k in ("fx", "fy", "cx", "cy", "width", "height") if k in fr.meta}
            (rd / "camera_intrinsics.json").write_text(json.dumps(intr, indent=2), encoding="utf-8")
        self._writer.writerow(row)
        self.count += 1
        if self.count % 50 == 0:
            self._csv.flush()


def save_snapshot(frame: Frame, folder: str | Path = "output/snapshots") -> Path:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
    p = folder / f"snap_{stamp}.png"
    imgio.imwrite(p, frame.bgr())
    p.with_suffix(".json").write_text(json.dumps(frame.meta, ensure_ascii=False, indent=2,
                                                 default=str), encoding="utf-8")
    return p


def _flat(meta: dict) -> dict:
    out = {}
    for k, v in meta.items():
        if isinstance(v, float):
            out[k] = f"{v:.9g}"
        elif v is None:
            out[k] = ""
        else:
            out[k] = v
    return out
