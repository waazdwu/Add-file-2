"""Геометрия аппарата, режимы ориентации и крепление камеры.

Связанная система координат (СК) аппарата, метры:
    +Z — «нижняя» грань (в режиме LVLH смотрит в надир);
    +X — по направлению полёта (в режиме LVLH);
    ±Y — грани, к которым крепятся панели солнечных батарей.

Камера использует «компьютерно-зрительную» конвенцию:
    x — вправо по кадру, y — вниз по кадру, z — вдоль оптической оси.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

BODY_HALF = np.array([0.5, 0.5, 0.65])        # полуразмеры корпуса, м
PANEL_HALF = np.array([0.55, 1.25, 0.012])    # полуразмеры одной панели
PANEL_OFFSET_Y = 0.5 + 0.3 + PANEL_HALF[1]    # центр панели по Y
CAM_HOUSING_HALF = np.array([0.07, 0.07, 0.06])
CAM_LENS_STANDOFF = 0.125                      # от грани до объектива, м


# ---- Малые помощники для поворотов -----------------------------------------
def Rx(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]], dtype=float)


def Ry(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]], dtype=float)


def Rz(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], dtype=float)


def unit(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / n if n > 0 else v


def matrix_to_quaternion(R: np.ndarray) -> np.ndarray:
    """Кватернион (w, x, y, z) для матрицы поворота R."""
    t = np.trace(R)
    if t > 0:
        s = math.sqrt(t + 1.0) * 2
        q = [0.25 * s, (R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s]
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        q = [(R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s]
    elif R[1, 1] > R[2, 2]:
        s = math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        q = [(R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s]
    else:
        s = math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        q = [(R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s]
    q = np.array(q)
    return q / np.linalg.norm(q) * (1 if q[0] >= 0 else -1)


# ---- Ориентация аппарата ----------------------------------------------------
ATTITUDE_MODES = {
    "lvlh": "Орбитальная (LVLH, +Z в надир)",
    "inertial": "Инерциальная (оси ECI)",
    "sun": "Солнечная (-Z на Солнце)",
}


def lvlh_matrix(r: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Орбитальная СК: z — в надир, y — против нормали орбиты, x — ≈ по скорости."""
    z = unit(-r)
    y = unit(-np.cross(r, v))
    x = np.cross(y, z)
    return np.column_stack([x, y, z])


def body_attitude(mode: str, r: np.ndarray, v: np.ndarray, sun_dir: np.ndarray,
                  yaw_deg: float = 0.0, pitch_deg: float = 0.0, roll_deg: float = 0.0) -> np.ndarray:
    """Матрица R_body: столбцы — оси связанной СК в ECI."""
    if mode == "inertial":
        base = np.eye(3)
    elif mode == "sun":
        z = unit(-sun_dir)                       # -Z смотрит на Солнце
        x_hint = unit(v)
        x = x_hint - np.dot(x_hint, z) * z
        if np.linalg.norm(x) < 1e-6:
            x = np.array([1.0, 0, 0]) - z[0] * z
        x = unit(x)
        y = np.cross(z, x)
        base = np.column_stack([x, y, z])
    else:
        base = lvlh_matrix(r, v)
    offs = Rz(math.radians(yaw_deg)) @ Ry(math.radians(pitch_deg)) @ Rx(math.radians(roll_deg))
    return base @ offs


def panel_tracking_angle(sun_body: np.ndarray) -> float:
    """Угол поворота панелей вокруг оси Y, при котором нормаль ближе всего к Солнцу."""
    return math.atan2(sun_body[0], sun_body[2])


# ---- Части аппарата для рендеринга -----------------------------------------
@dataclass
class Part:
    name: str
    kind: str                      # "box" или "disk"
    center: np.ndarray             # центр в СК аппарата, м
    R: np.ndarray                  # ориентация части в СК аппарата
    half: np.ndarray               # полуразмеры (box) или [радиус,0,0] (disk)
    color: tuple                   # базовый цвет RGB 0..1
    specular: float = 0.2
    shininess: float = 20.0
    pattern: str = ""              # "cells" — сетка солнечных элементов
    is_camera: bool = False        # не рисуется в кадре собственной камеры

    @property
    def bound_radius(self) -> float:
        return float(np.linalg.norm(self.half)) if self.kind == "box" else float(self.half[0])


GOLD = (0.83, 0.62, 0.22)
SILVER = (0.72, 0.73, 0.76)
WHITE = (0.88, 0.88, 0.86)
PANEL = (0.07, 0.11, 0.30)
DARK = (0.12, 0.12, 0.13)
GLASS = (0.02, 0.03, 0.05)


def build_parts(panel_angle: float, cam_pos_body: np.ndarray, cam_R_body: np.ndarray,
                face_normal: np.ndarray) -> list[Part]:
    """Список частей аппарата в его связанной СК."""
    I = np.eye(3)
    parts = [
        Part("body", "box", np.zeros(3), I, BODY_HALF.copy(), GOLD, specular=0.45, shininess=12),
        Part("radiator", "box", np.array([-0.505, 0, 0]), I, np.array([0.006, 0.42, 0.55]), WHITE,
             specular=0.1),
        Part("startracker", "box", np.array([0.25, -0.2, -0.72]), I, np.array([0.08, 0.08, 0.07]), DARK),
        Part("mast", "box", np.array([-0.2, 0.15, -0.8]), I, np.array([0.025, 0.025, 0.15]), SILVER),
        Part("dish", "disk", np.array([-0.2, 0.15, -0.96]), I, np.array([0.32, 0, 0]), WHITE,
             specular=0.3),
    ]
    Rp = Ry(panel_angle)
    for sgn in (+1, -1):
        parts.append(Part(f"strut{'+' if sgn > 0 else '-'}", "box",
                          np.array([0, sgn * 0.65, 0]), Rp, np.array([0.03, 0.15, 0.03]), SILVER))
        parts.append(Part(f"panel{'+' if sgn > 0 else '-'}", "box",
                          np.array([0, sgn * PANEL_OFFSET_Y, 0]), Rp, PANEL_HALF.copy(), PANEL,
                          specular=0.6, shininess=60, pattern="cells"))

    # Корпус камеры: ось z корпуса — по нормали к грани, объектив — по оси визирования
    face_R = face_frame(face_normal)
    housing_c = cam_pos_body - face_normal * (CAM_LENS_STANDOFF - CAM_HOUSING_HALF[2])
    parts.append(Part("camera", "box", housing_c, face_R, CAM_HOUSING_HALF.copy(), DARK,
                      specular=0.3, is_camera=True))
    parts.append(Part("lens", "disk", cam_pos_body + cam_R_body[:, 2] * 0.005, cam_R_body,
                      np.array([0.045, 0, 0]), GLASS, specular=1.0, shininess=120, is_camera=True))
    return parts


# ---- Крепление камеры -------------------------------------------------------
# Для каждой грани: нормаль n и «вертикаль» up — направление, которое в кадре
# по возможности остаётся «вверху». Для боковых граней это зенит (−Z), поэтому
# горизонт в кадре горизонтален, а Земля — внизу; для ±Z — направление полёта.
FACE_UP = {
    "+X": (np.array([1.0, 0, 0]), np.array([0, 0, -1.0])),
    "-X": (np.array([-1.0, 0, 0]), np.array([0, 0, -1.0])),
    "+Y": (np.array([0, 1.0, 0]), np.array([0, 0, -1.0])),
    "-Y": (np.array([0, -1.0, 0]), np.array([0, 0, -1.0])),
    "+Z": (np.array([0, 0, 1.0]), np.array([1.0, 0, 0])),
    "-Z": (np.array([0, 0, -1.0]), np.array([1.0, 0, 0])),
}
# Базис грани: e1 = n × up (вправо по кадру), e2 = −up (вниз по кадру), n
FACES = {k: (n, np.cross(n, up), -up) for k, (n, up) in FACE_UP.items()}
FACE_NAMES = {
    "+X": "+X (по полёту)", "-X": "−X (против полёта)",
    "+Y": "+Y (бок, панель)", "-Y": "−Y (бок, панель)",
    "+Z": "+Z (надир)", "-Z": "−Z (зенит)",
}


def face_frame(normal: np.ndarray) -> np.ndarray:
    for n, e1, e2 in FACES.values():
        if np.allclose(n, normal):
            return np.column_stack([e1, e2, n])
    raise ValueError("unknown face normal")


def face_half_extent(face: str) -> tuple[float, float]:
    """Допустимые полудиапазоны смещения (u, v) камеры по грани, м."""
    n, e1, e2 = FACES[face]
    hu = float(np.abs(e1) @ BODY_HALF) - CAM_HOUSING_HALF[0]
    hv = float(np.abs(e2) @ BODY_HALF) - CAM_HOUSING_HALF[1]
    return hu, hv


@dataclass
class CameraMount:
    """Камера на двухосном приводе «азимут — угол места» на грани корпуса.

    azimuth_deg — поворот вокруг вертикали грани (+ вправо по кадру);
    tilt_deg    — угол места относительно нормали грани (+ вверх, − вниз);
    roll_deg    — поворот кадра вокруг оси визирования;
    max_tilt_deg — предельный угол отклонения оси от нормали грани
                   (дальше смотреть мешает собственный корпус).
    Для боковых граней: tilt = −90° — надир, tilt ≈ −22° — горизонт с 500 км.
    Для грани +Z (надир): 0/0 — надир, tilt > 0 — вперёд по полёту,
    azimuth — поперёк трассы.
    """
    face: str = "+Z"
    u: float = 0.0           # смещение по e1 грани (вправо по кадру), м
    v: float = 0.0           # смещение по e2 грани (вниз по кадру), м
    azimuth_deg: float = 0.0
    tilt_deg: float = 0.0
    roll_deg: float = 0.0
    max_tilt_deg: float = 90.0

    def frame(self) -> np.ndarray:
        n, e1, e2 = FACES[self.face]
        return np.column_stack([e1, e2, n])

    def position_body(self) -> np.ndarray:
        n, e1, e2 = FACES[self.face]
        hu, hv = face_half_extent(self.face)
        u = max(-hu, min(hu, self.u))
        v = max(-hv, min(hv, self.v))
        center = n * float(np.abs(n) @ BODY_HALF)
        return center + u * e1 + v * e2 + n * CAM_LENS_STANDOFF

    def _axes(self):
        n, up = FACE_UP[self.face]
        return n, np.cross(n, up), up

    def boresight_body(self) -> np.ndarray:
        n, s, up = self._axes()
        a, t = math.radians(self.azimuth_deg), math.radians(self.tilt_deg)
        return math.cos(t) * (math.cos(a) * n + math.sin(a) * s) + math.sin(t) * up

    def off_normal_deg(self) -> float:
        n = FACE_UP[self.face][0]
        return math.degrees(math.acos(max(-1.0, min(1.0, float(self.boresight_body() @ n)))))

    def clamp_to_limit(self) -> bool:
        """Если ось вне конуса привода — прижать к его границе. True, если была в пределах."""
        if self.off_normal_deg() <= self.max_tilt_deg + 1e-9:
            return True
        n, s, up = self._axes()
        b = self.boresight_body()
        perp = b - (b @ n) * n
        if np.linalg.norm(perp) < 1e-12:
            perp = up
        m = math.radians(self.max_tilt_deg)
        self._set_from_direction(math.cos(m) * n + math.sin(m) * unit(perp))
        return False

    def _set_from_direction(self, d: np.ndarray) -> None:
        n, s, up = self._axes()
        d = unit(d)
        self.tilt_deg = math.degrees(math.asin(max(-1.0, min(1.0, float(d @ up)))))
        if math.hypot(float(d @ s), float(d @ n)) > 1e-9:
            self.azimuth_deg = math.degrees(math.atan2(float(d @ s), float(d @ n)))

    def rotation_body(self) -> np.ndarray:
        """Матрица: столбцы — оси камеры (x вправо, y вниз, z вдоль оси) в СК аппарата."""
        n, s, up = self._axes()
        a = math.radians(self.azimuth_deg)
        b = self.boresight_body()
        x = math.cos(a) * s - math.sin(a) * n          # «горизонтальная» ось вправо
        y = np.cross(b, x)
        return np.column_stack([x, y, b]) @ Rz(math.radians(self.roll_deg))

    def point_at(self, d_body: np.ndarray) -> bool:
        """Навести ось камеры на направление d (СК аппарата).

        Возвращает False, если направление вне досягаемости привода —
        тогда ось упирается в границу конуса.
        """
        self._set_from_direction(d_body)
        return self.clamp_to_limit()


POINTING_MODES = {
    "manual": "Ручное",
    "nadir": "Надир (центр Земли)",
    "target": "Точка на Земле (шир/долг)",
    "sun": "Солнце",
    "velocity": "По вектору скорости",
}
