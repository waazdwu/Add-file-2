"""Локальный веб-сервер: интерфейс управления и трансляция камеры.

Только стандартная библиотека. Конечные точки:
    GET  /                       — интерфейс
    GET  /stream/camera.mjpg     — видеопоток камеры (MJPEG; читается OpenCV/VLC/ffmpeg)
    GET  /stream/overview.mjpg   — видеопоток общего вида
    GET  /api/frame/<view>.jpg   — последний кадр (?after=N — дождаться кадра новее N)
    GET  /api/frame/camera.png   — последний кадр камеры без сжатия
    GET  /api/state              — телеметрия + текущие параметры
    GET  /api/meta               — полные метаданные последнего кадра камеры
    GET  /api/schema             — списки режимов для интерфейса
    GET  /api/scenario           — сценарий (JSON) для сохранения
    POST /api/params             — {"camera.tilt_deg": 30, ...}
    POST /api/action             — {"action": "pause" | "reset_time" | ...}
    POST /api/view               — вращение/масштаб общего вида мышью
    POST /api/scenario           — загрузить сценарий
"""
from __future__ import annotations

import json
import math
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import cv2
import numpy as np

from . import camera_model
from .config import SimConfig
from .engine import Engine
from .feed import save_snapshot
from .orbit import sun_synchronous_inclination
from .render import VIEW_MODES
from .spacecraft import ATTITUDE_MODES, FACE_NAMES, POINTING_MODES, face_half_extent

WEB = Path(__file__).parent / "web"
MIME = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml"}

PRESETS = {
    "iss": ("МКС-подобная, 420 км, 51.6°",
            {"orbit.perigee_alt_km": 420, "orbit.eccentricity": 0.0, "orbit.inclination_deg": 51.6}),
    "sso600": ("Солнечно-синхронная, 600 км",
               {"orbit.perigee_alt_km": 600, "orbit.eccentricity": 0.0,
                "orbit.inclination_deg": round(sun_synchronous_inclination(600), 3), "orbit.use_j2": True}),
    "polar800": ("Полярная, 800 км",
                 {"orbit.perigee_alt_km": 800, "orbit.eccentricity": 0.0, "orbit.inclination_deg": 90.0}),
    "equator": ("Экваториальная, 500 км",
                {"orbit.perigee_alt_km": 500, "orbit.eccentricity": 0.0, "orbit.inclination_deg": 0.0}),
    "molniya": ("«Молния» (e = 0.72)",
                {"orbit.perigee_alt_km": 600, "orbit.eccentricity": 0.72, "orbit.inclination_deg": 63.4,
                 "orbit.arg_perigee_deg": 270}),
}


class LiveFrames:
    """Последние JPEG-кадры видов с номерами; ожидание нового кадра."""

    def __init__(self):
        self.cond = threading.Condition()
        self.jpeg = {"camera": None, "overview": None}
        self.seq = {"camera": 0, "overview": 0}

    def put(self, view: str, data: bytes):
        with self.cond:
            self.jpeg[view] = data
            self.seq[view] += 1
            self.cond.notify_all()

    def wait(self, view: str, after: int, timeout: float = 2.0):
        with self.cond:
            self.cond.wait_for(lambda: self.seq[view] > after, timeout=timeout)
            return self.jpeg[view], self.seq[view]


class App:
    def __init__(self, cfg: SimConfig, allow_download: bool = True):
        self.engine = Engine(cfg, allow_download=allow_download)
        self.engine.sim.realtime = True          # время идёт по часам
        self.cfg = cfg
        self.ov_requested = 0.0                  # когда браузер в последний раз просил картинку общего вида
        self._tex_cache: dict = {}
        self.frames = LiveFrames()
        self.telemetry: dict = {}
        self.fps = 0.0
        self.running = True
        self.last_png_frame = None
        self.last_error = None
        self.message = f"Текстура Земли: {self.engine.renderer.texture_source}"
        self.thread = threading.Thread(target=self._loop, daemon=True)
        # диагностика
        self.ticks = 0
        self.tick_ms = 0.0
        self.http_hits = {"state": 0, "frame": 0, "post": 0, "static": 0, "scene": 0}
        self.http_errors = 0

    def start(self):
        self.thread.start()
        threading.Thread(target=self._heartbeat, daemon=True).start()

    def _heartbeat(self, period: float = 5.0):
        """Раз в несколько секунд печатать в консоль, что происходит."""
        prev_t, prev_ticks = self.engine.sim.t, self.ticks
        prev_hits = dict(self.http_hits)
        while self.running:
            time.sleep(period)
            t, ticks = self.engine.sim.t, self.ticks
            hits = {k: self.http_hits[k] - prev_hits[k] for k in self.http_hits}
            tel = self.telemetry
            line = (f"[{time.strftime('%H:%M:%S')}] модельное время {tel.get('utc', '—')} "
                    f"(+{t - prev_t:.0f} с за {period:.0f} с), кадров {ticks - prev_ticks}, "
                    f"кадр {self.tick_ms:.0f} мс, ×{self.cfg.time.time_scale:g}"
                    f"{' ПАУЗА' if self.cfg.time.paused else ''} | браузер: состояние {hits['state']}, "
                    f"сцена {hits['scene']}, кадры камеры {hits['frame']}, команды {hits['post']}")
            if hits["state"] == 0 and hits["frame"] == 0 and hits["scene"] == 0:
                line += "  ← браузер не обращается к программе (страница закрыта или не та вкладка/порт?)"
            if self.last_error:
                line += f"\n    ОШИБКА расчёта: {self.last_error}"
            print(line, flush=True)
            prev_t, prev_ticks, prev_hits = t, ticks, dict(self.http_hits)

    def _loop(self):
        last = time.perf_counter()
        while self.running:
            t0 = time.perf_counter()
            dt = min(t0 - last, 10.0)    # модельное время идёт по реальным часам даже при низкой частоте кадров
            last = t0
            try:
                # общий вид рисует браузер (WebGL); картинку здесь считаем, только если
                # браузер без WebGL сам её запрашивает
                need_ov = time.time() - self.ov_requested < 3.0
                st, frame, ov = self.engine.tick(dt, overview=need_ov)
                q = [int(cv2.IMWRITE_JPEG_QUALITY), 88]
                self.frames.put("camera", cv2.imencode(".jpg", frame.bgr(), q)[1].tobytes())
                if ov is not None:
                    self.frames.put("overview", cv2.imencode(
                        ".jpg", cv2.cvtColor(ov, cv2.COLOR_RGB2BGR), q)[1].tobytes())
                tel = dict(st.telemetry)
                tel["saturated_fraction"] = frame.meta["saturated_fraction"]
                tel["render_body_fraction"] = frame.meta["render_body_fraction"]
                # камера: производные характеристики и фактический размер кадра трансляции
                tel["camera"] = camera_model.derived(self.cfg.camera, tel.get("range_km"))
                tel["frame_w"], tel["frame_h"] = frame.image.shape[1], frame.image.shape[0]
                self.telemetry = tel
                self.last_error = None
                self.ticks += 1
            except Exception as exc:
                traceback.print_exc()
                self.last_error = f"{type(exc).__name__}: {exc}"
                time.sleep(0.5)
            el = time.perf_counter() - t0
            self.tick_ms = 0.8 * self.tick_ms + 0.2 * el * 1000 if self.tick_ms else el * 1000
            self.fps = 0.85 * self.fps + 0.15 / max(el, 1e-3) if self.fps else 1 / max(el, 1e-3)
            pause = 1.0 / max(self.cfg.fps, 1) - el
            if pause > 0:
                time.sleep(pause)

    # ---- данные для WebGL-вида в браузере -----------------------------------
    def scene(self) -> dict:
        """Компактное состояние сцены на текущий момент (для плавной отрисовки в браузере)."""
        from .astro import R_EARTH, rot_z
        from .orbit import orbit_track, propagate
        eng = self.engine
        with eng.lock:
            st = eng.sim.state()
            vc = self.cfg.view
            orbit = orbit_track(self.cfg.orbit, st.t, 180) if vc.show_orbit else None
            track = None
            if vc.show_ground_track:
                T = self.cfg.orbit.period_s
                pts = []
                for tk in st.t + np.linspace(0, T, 160):
                    r, _ = propagate(self.cfg.orbit, tk)
                    p = rot_z(-7.2921150e-5 * (tk - st.t)) @ r
                    pts.append(p / np.linalg.norm(p) * R_EARTH * 1.002)
                track = np.array(pts)
            time_cfg = self.cfg.time
        parts = [{
            "k": p.kind, "c": p.center, "R": p.R, "h": p.half, "col": p.color,
            "sp": p.specular, "sh": p.shininess, "cells": p.pattern == "cells", "cam": p.is_camera,
        } for p in st.parts]
        g = st.metrics.get("ground")
        return {
            "t": st.t, "scale": time_cfg.time_scale, "paused": time_cfg.paused,
            "r": st.r, "v": st.v, "Rb": st.R_body,
            "sunE": st.sun_pos / np.linalg.norm(st.sun_pos), "gmst": st.theta_g, "sunlit": st.sunlit,
            "camPosB": st.mount.position_body(), "camRB": st.mount.rotation_body(),
            "fov": st.intr.fov_h_deg, "aspect": st.intr.width / st.intr.height,
            "range": g["range_km"] if g else None,
            "parts": parts, "orbit": orbit, "track": track,
        }

    def texture(self, name: str) -> bytes | None:
        """Текстуры для браузера: размеры — степени двойки (нужно WebGL для мип-уровней)."""
        if name in self._tex_cache:
            return self._tex_cache[name]
        r = self.engine.renderer
        if name == "earth.jpg":
            src = cv2.cvtColor(r.texture, cv2.COLOR_RGB2BGR)
        elif name == "clouds.jpg":
            src = r.clouds
        else:
            return None
        w = 4096 if src.shape[1] > 2048 else 2048
        img = cv2.resize(src, (w, w // 2), interpolation=cv2.INTER_AREA)
        data = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 90])[1].tobytes()
        self._tex_cache[name] = data
        return data

    # ---- команды -------------------------------------------------------------
    def set_params(self, changes: dict) -> list:
        with self.engine.lock:
            changed = self.cfg.update(changes)
            c = self.cfg.camera
            hu, hv = face_half_extent(c.face)
            c.u = max(-hu, min(hu, c.u))
            c.v = max(-hv, min(hv, c.v))
            c.width = max(64, min(1920, c.width))
            c.pixel_um = max(0.5, min(50.0, c.pixel_um))
            c.sensor_w_px = max(16, min(16384, c.sensor_w_px))
            c.sensor_h_px = max(16, min(16384, c.sensor_h_px))
            c.binning = c.binning if c.binning in (1, 2, 4) else 1
            c.focal_mm = max(1.0, min(2000.0, c.focal_mm))
            c.f_number = max(0.7, min(32.0, c.f_number))
            c.preview_scale = max(1, min(8, c.preview_scale))
            c.optics_mode = c.optics_mode if c.optics_mode in ("sensor", "fov") else "sensor"
            c.height = max(48, min(1080, c.height))
            c.fov_h_deg = max(0.5, min(150.0, c.fov_h_deg))
        return changed

    def action(self, a: dict) -> dict:
        name = a.get("action")
        eng = self.engine
        with eng.lock:
            if name == "pause":
                self.cfg.time.paused = not self.cfg.time.paused
            elif name == "reset_time":
                eng.sim.t = 0.0
            elif name == "step":
                eng.sim.t += float(a.get("seconds", 60))
            elif name == "jump_to_shadow":
                eng.sim.t = _find_light_change(eng, want_shadow=True)
            elif name == "jump_to_sun":
                eng.sim.t = _find_light_change(eng, want_shadow=False)
            elif name == "preset":
                p = PRESETS.get(a.get("id"))
                if p:
                    self.cfg.update(p[1])
            elif name == "sso_inclination":
                self.cfg.orbit.inclination_deg = round(
                    sun_synchronous_inclination(self.cfg.orbit.perigee_alt_km), 3)
            elif name == "sensor_preset":
                camera_model.apply_sensor_preset(self.cfg.camera, a.get("id"))
            elif name == "lens_preset":
                camera_model.apply_lens_preset(self.cfg.camera, a.get("id"))
            elif name == "camera_zero":
                self.cfg.update({"camera.azimuth_deg": 0, "camera.tilt_deg": 0, "camera.roll_deg": 0,
                                 "camera.pointing": "manual"})
            elif name == "freeze_pointing":
                # перенести текущие углы автонаведения в ручной режим
                self.cfg.camera.azimuth_deg = self.telemetry.get("cam_azimuth_deg", 0.0)
                self.cfg.camera.tilt_deg = self.telemetry.get("cam_tilt_deg", 0.0)
                self.cfg.camera.pointing = "manual"
        if name == "record_start":
            o = a.get("options", {})
            run = eng.recorder.start(self.cfg.to_dict(), save_png=o.get("png", True),
                                     save_mp4=o.get("mp4", False), every_n=o.get("every_n", 1))
            return {"ok": True, "message": f"Запись: {run.resolve()}"}
        if name == "record_stop":
            n = eng.recorder.count
            run = eng.recorder.run_dir
            eng.recorder.stop()
            return {"ok": True, "message": f"Записано кадров: {n} → {run.resolve() if run else ''}"}
        if name == "snapshot":
            fr = eng.feed.latest
            if fr is not None:
                p = save_snapshot(fr)
                return {"ok": True, "message": f"Снимок: {p.resolve()}"}
        return {"ok": True}

    def drag_view(self, d: dict):
        with self.engine.lock:
            v = self.cfg.view
            v.azimuth_deg = (v.azimuth_deg - float(d.get("dx", 0)) * 0.3) % 360
            v.elevation_deg = max(-89.0, min(89.0, v.elevation_deg + float(d.get("dy", 0)) * 0.3))
            z = float(d.get("zoom", 0))
            if z:
                k = math.exp(max(-400.0, min(400.0, z)) * 0.0008)
                if v.mode == "closeup":
                    v.distance_m = max(2.5, min(200.0, v.distance_m * k))
                elif v.mode == "follow":
                    v.follow_distance_km = max(0.05, min(30000.0, v.follow_distance_km * k))
                else:
                    v.distance_km = max(7500.0, min(400000.0, v.distance_km * k))

    def state(self) -> dict:
        rec = self.engine.recorder
        return {
            "telemetry": self.telemetry,
            "config": self.cfg.to_dict(),
            "fps": round(self.fps, 1),
            "frame_seq": self.frames.seq,
            "recording": {"active": rec.active, "count": rec.count, "dropped": rec.dropped,
                          "dir": str(rec.run_dir.resolve()) if rec.run_dir else None},
            "message": self.message,
            "error": self.last_error,
        }


def _find_light_change(eng: Engine, want_shadow: bool) -> float:
    """Ближайший момент входа в тень (или выхода на Солнце) после текущего."""
    from .astro import sunlit_fraction, sun_position_eci, julian_date
    from .orbit import propagate
    from datetime import timedelta
    sim = eng.sim
    T = eng.cfg.orbit.period_s
    t, step = sim.t, 20.0

    def lit(tt):
        r, _ = propagate(eng.cfg.orbit, tt)
        return sunlit_fraction(r, sun_position_eci(julian_date(sim.epoch + timedelta(seconds=tt))))
    prev = lit(t)
    while t < sim.t + 2 * T:
        t += step
        cur = lit(t)
        if want_shadow and prev > 0.5 >= cur:
            return t - 60.0
        if not want_shadow and prev < 0.5 <= cur:
            return t - 60.0
        prev = cur
    return sim.t


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass

        def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, obj, code=200):
            self._send(code, json.dumps(obj, ensure_ascii=False, default=_json_default).encode(),
                       "application/json; charset=utf-8")

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n) or b"{}")

        def do_GET(self):
            u = urlparse(self.path)
            path, qs = u.path, parse_qs(u.query)
            try:
                if path in ("/", "/index.html") or path.startswith("/static/"):
                    app.http_hits["static"] += 1
                elif path.startswith("/api/frame/") or path.startswith("/stream/"):
                    app.http_hits["frame"] += 1
                elif path == "/api/state":
                    app.http_hits["state"] += 1
                if path in ("/", "/index.html"):
                    return self._static("index.html")
                if path.startswith("/static/"):
                    return self._static(path[len("/static/"):])
                if path == "/api/scene":
                    app.http_hits["scene"] += 1
                    return self._json(app.scene())
                if path.startswith("/api/texture/"):
                    data = app.texture(path.rsplit("/", 1)[1])
                    if data is None:
                        return self._send(404, b"", "text/plain")
                    return self._send(200, data, "image/jpeg")
                if path.startswith("/api/frame/"):
                    name = path.rsplit("/", 1)[1]
                    if name.startswith("overview"):
                        app.ov_requested = time.time()
                    if name == "camera.png":
                        fr = app.engine.feed.latest
                        if fr is None:
                            return self._send(503, b"", "text/plain")
                        return self._send(200, cv2.imencode(".png", fr.bgr())[1].tobytes(), "image/png")
                    view = name.split(".")[0]
                    if view not in app.frames.seq:
                        return self._send(404, b"", "text/plain")
                    after = int(qs.get("after", ["0"])[0])
                    data, seq = app.frames.wait(view, after)
                    if data is None:
                        return self._send(503, b"", "text/plain")
                    return self._send(200, data, "image/jpeg", {"X-Seq": str(seq)})
                if path.startswith("/stream/"):
                    return self._mjpeg(path.rsplit("/", 1)[1].split(".")[0])
                if path == "/api/state":
                    return self._json(app.state())
                if path == "/api/meta":
                    fr = app.engine.feed.latest
                    return self._json(fr.meta if fr else {})
                if path == "/api/schema":
                    return self._json({
                        "faces": FACE_NAMES, "pointing": POINTING_MODES, "attitude": ATTITUDE_MODES,
                        "views": VIEW_MODES, "presets": {k: v[0] for k, v in PRESETS.items()},
                        "sensors": {k: v["name"] for k, v in camera_model.SENSORS.items()},
                        "lenses": {k: v["name"] for k, v in camera_model.LENSES.items()},
                        "face_extent": {f: face_half_extent(f) for f in FACE_NAMES},
                    })
                if path == "/api/scenario":
                    body = json.dumps(app.cfg.to_dict(), ensure_ascii=False, indent=2).encode()
                    return self._send(200, body, "application/json; charset=utf-8",
                                      {"Content-Disposition": 'attachment; filename="scenario.json"'})
                self._send(404, b"not found", "text/plain")
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_POST(self):
            path = urlparse(self.path).path
            app.http_hits["post"] += 1
            try:
                body = self._body()
                if path == "/api/params":
                    return self._json({"changed": app.set_params(body)})
                if path == "/api/action":
                    return self._json(app.action(body))
                if path == "/api/view":
                    app.drag_view(body)
                    return self._json({"ok": True})
                if path == "/api/scenario":
                    with app.engine.lock:
                        app.cfg.load_dict(body)
                    return self._json({"ok": True})
                self._send(404, b"not found", "text/plain")
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as exc:
                traceback.print_exc()
                self._json({"ok": False, "error": str(exc)}, 400)

        def _static(self, name: str):
            p = (WEB / name).resolve()
            if WEB.resolve() not in p.parents or not p.is_file():
                return self._send(404, b"not found", "text/plain")
            self._send(200, p.read_bytes(), MIME.get(p.suffix, "application/octet-stream"))

        def _mjpeg(self, view: str):
            if view not in app.frames.seq:
                return self._send(404, b"", "text/plain")
            self.send_response(200)
            self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Connection", "close")
            self.end_headers()
            seq = 0
            try:
                while app.running:
                    data, seq = app.frames.wait(view, seq, timeout=5)
                    if data is None:
                        continue
                    self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                                     + str(len(data)).encode() + b"\r\n\r\n" + data + b"\r\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass
            self.close_connection = True

    return Handler


def _json_default(o):
    try:
        import numpy as np
        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:
        pass
    return str(o)


def serve(app: App, host: str = "127.0.0.1", port: int = 8765) -> ThreadingHTTPServer:
    httpd = ThreadingHTTPServer((host, port), make_handler(app))
    httpd.daemon_threads = True
    return httpd
