"""Сборка состояния всей системы на заданный момент модельного времени."""
from __future__ import annotations

import copy
import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

import numpy as np

from . import astro, camera_model
from .config import SimConfig
from .orbit import propagate
from .sensor import Intrinsics, camera_metrics, ray_sphere
from .spacecraft import (CameraMount, Part, body_attitude, build_parts, matrix_to_quaternion,
                         panel_tracking_angle, unit)


@dataclass
class SimState:
    t: float                      # модельное время от эпохи, с
    utc: datetime
    jd: float
    theta_g: float                # GMST, рад
    r: np.ndarray                 # положение КА, ECI км
    v: np.ndarray                 # скорость КА, ECI км/с
    sun_pos: np.ndarray           # Земля→Солнце, ECI км
    sun_dir: np.ndarray
    sunlit: float                 # доля диска Солнца, видимая с КА
    R_body: np.ndarray            # оси КА в ECI
    panel_angle: float
    mount: CameraMount            # крепление с учётом автонаведения
    pointing_ok: bool
    cam_pos: np.ndarray           # положение объектива, ECI км
    cam_R: np.ndarray             # оси камеры в ECI
    intr: Intrinsics
    parts: list[Part]
    metrics: dict
    telemetry: dict = field(default_factory=dict)


class Simulation:
    """Модельное время двух видов:
    * обычное (скрипты, датасеты) — меняется только через step()/присваивание t;
    * realtime (интерфейс) — идёт по реальным часам с ускорением time_scale,
      независимо от того, как быстро рисуются кадры.
    """

    def __init__(self, cfg: SimConfig | None = None, realtime: bool = False):
        self.cfg = cfg or SimConfig()
        self.realtime = realtime
        self._t = 0.0
        self._wall = time.perf_counter()
        self._scale = self.cfg.time.time_scale
        self._paused = self.cfg.time.paused

    def _rebase(self) -> None:
        w = time.perf_counter()
        if not self._paused:
            self._t += (w - self._wall) * self._scale
        self._wall = w
        self._scale = self.cfg.time.time_scale
        self._paused = self.cfg.time.paused

    @property
    def t(self) -> float:
        if not self.realtime:
            return self._t
        c = self.cfg.time
        if c.time_scale != self._scale or c.paused != self._paused:
            self._rebase()
        if self._paused:
            return self._t
        return self._t + (time.perf_counter() - self._wall) * self._scale

    @t.setter
    def t(self, value: float) -> None:
        self._t = float(value)
        self._wall = time.perf_counter()
        self._scale = self.cfg.time.time_scale
        self._paused = self.cfg.time.paused

    @property
    def epoch(self) -> datetime:
        s = self.cfg.time.epoch_utc.replace("Z", "")
        try:
            e = datetime.fromisoformat(s)
        except ValueError:
            e = datetime(2026, 6, 21, 6, 0, 0)
        return e.replace(tzinfo=timezone.utc) if e.tzinfo is None else e

    def step(self, dt_real: float) -> None:
        """Шаг времени для нереального режима (в realtime время идёт само)."""
        if not self.realtime and not self.cfg.time.paused:
            self._t += dt_real * self.cfg.time.time_scale

    def state(self, t: float | None = None) -> SimState:
        cfg = self.cfg
        t = self.t if t is None else t
        utc = self.epoch + timedelta(seconds=t)
        jd = astro.julian_date(utc)
        theta_g = astro.gmst(jd)

        r, v = propagate(cfg.orbit, t)
        sun_pos = astro.sun_position_eci(jd)
        sun_dir = unit(sun_pos - r)
        sunlit = astro.sunlit_fraction(r, sun_pos)

        a = cfg.attitude
        R_body = body_attitude(a.mode, r, v, sun_dir, a.yaw_deg, a.pitch_deg, a.roll_deg)
        sun_body = R_body.T @ sun_dir
        panel_angle = (panel_tracking_angle(sun_body) if a.panel_tracking
                       else math.radians(a.panel_angle_deg))

        c = cfg.camera
        mount = CameraMount(c.face, c.u, c.v, c.azimuth_deg, c.tilt_deg, c.roll_deg, c.max_tilt_deg)
        cam_pos_body = mount.position_body()
        cam_pos = r + R_body @ cam_pos_body / 1000.0

        pointing_ok = True
        target_visible = None
        if c.pointing == "manual":
            pointing_ok = mount.clamp_to_limit()
        else:
            if c.pointing == "nadir":
                d = -cam_pos
            elif c.pointing == "sun":
                d = sun_pos - cam_pos
            elif c.pointing == "velocity":
                d = v
            else:  # target
                tgt = astro.rot_z(theta_g) @ astro.latlon_to_ecef(math.radians(c.target_lat),
                                                                 math.radians(c.target_lon))
                d = tgt - cam_pos
                hit = ray_sphere(cam_pos, unit(d), np.zeros(3), astro.R_EARTH - 1e-3)
                target_visible = bool(hit is None or hit >= float(np.linalg.norm(d)) - 1.0)
            pointing_ok = mount.point_at(R_body.T @ unit(d))
            if target_visible is False:
                pointing_ok = False

        cam_R_body = mount.rotation_body()
        cam_R = R_body @ cam_R_body
        intr = camera_model.intrinsics(c)

        flux_here = astro.solar_flux(cam_pos, sun_pos)
        metrics = camera_metrics(cam_pos, cam_R, intr, sun_pos, sunlit, flux_here, theta_g)
        parts = build_parts(panel_angle, cam_pos_body, cam_R_body, mount.frame()[:, 2])

        st = SimState(t, utc, jd, theta_g, r, v, sun_pos, sun_dir, sunlit, R_body, panel_angle,
                      mount, pointing_ok, cam_pos, cam_R, intr, parts, metrics)
        st.telemetry = self._telemetry(st, target_visible)
        return st

    # ------------------------------------------------------------------------
    def _telemetry(self, s: SimState, target_visible) -> dict:
        r_mag = float(np.linalg.norm(s.r))
        lat, lon = astro.ecef_to_latlon(astro.eci_to_ecef_matrix(s.theta_g) @ s.r)
        h = np.cross(s.r, s.v)
        beta = math.degrees(math.asin(float(np.dot(unit(h), unit(s.sun_pos)))))
        if s.sunlit >= 0.999:
            light = "Солнце"
        elif s.sunlit <= 0.001:
            light = "Тень"
        else:
            light = "Полутень"
        m = s.metrics
        tel = {
            "t": s.t,
            "utc": s.utc.strftime("%Y-%m-%d %H:%M:%S"),
            "alt_km": r_mag - astro.R_EARTH,
            "speed_kms": float(np.linalg.norm(s.v)),
            "period_min": self.cfg.orbit.period_s / 60.0,
            "sub_lat": math.degrees(lat),
            "sub_lon": math.degrees(lon),
            "beta_deg": beta,
            "sunlit": s.sunlit,
            "light": light,
            "panel_angle_deg": math.degrees(s.panel_angle),
            "cam_azimuth_deg": s.mount.azimuth_deg,
            "cam_tilt_deg": s.mount.tilt_deg,
            "pointing_ok": s.pointing_ok,
            "target_visible": target_visible,
            "sun_angle_deg": m["sun_angle_deg"],
            "nadir_angle_deg": m["nadir_angle_deg"],
            "sun_in_fov": m["sun_in_fov"],
            "flux_w_m2": m["flux_w_m2"],
            "earth_fraction": m["earth_fraction"],
            "fov_v_deg": s.intr.fov_v_deg,
            "ifov_urad": s.intr.ifov_rad * 1e6,
        }
        g = m["ground"]
        tel.update({
            "gp_lat": g["lat"] if g else None,
            "gp_lon": g["lon"] if g else None,
            "range_km": g["range_km"] if g else None,
            "gsd_m": g["gsd_m"] if g else None,
            "gp_sun_el": g["sun_elevation_deg"] if g else None,
        })
        return tel

    def frame_metadata(self, s: SimState) -> dict:
        """Полные метаданные кадра (ground truth) для датасетов."""
        q_body = matrix_to_quaternion(s.R_body)
        q_cam = matrix_to_quaternion(s.cam_R)
        meta = dict(s.telemetry)
        meta.update({
            "jd": s.jd, "gmst_rad": s.theta_g,
            "sat_x_km": s.r[0], "sat_y_km": s.r[1], "sat_z_km": s.r[2],
            "sat_vx_kms": s.v[0], "sat_vy_kms": s.v[1], "sat_vz_kms": s.v[2],
            "cam_x_km": s.cam_pos[0], "cam_y_km": s.cam_pos[1], "cam_z_km": s.cam_pos[2],
            "q_body_w": q_body[0], "q_body_x": q_body[1], "q_body_y": q_body[2], "q_body_z": q_body[3],
            "q_cam_w": q_cam[0], "q_cam_x": q_cam[1], "q_cam_y": q_cam[2], "q_cam_z": q_cam[3],
            "sun_dir_x": s.sun_dir[0], "sun_dir_y": s.sun_dir[1], "sun_dir_z": s.sun_dir[2],
            "fx": s.intr.fx, "fy": s.intr.fy, "cx": s.intr.cx, "cy": s.intr.cy,
            "width": s.intr.width, "height": s.intr.height,
        })
        return {k: (float(v) if isinstance(v, (np.floating,)) else v) for k, v in meta.items()}

    def clone_config(self) -> SimConfig:
        return copy.deepcopy(self.cfg)
