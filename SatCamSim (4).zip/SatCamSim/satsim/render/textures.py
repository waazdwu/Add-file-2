"""Текстуры Земли: поиск реальной карты, загрузка или синтетическая генерация.

Порядок поиска текстуры поверхности (равнопромежуточная проекция 2:1):
  1. assets/earth_day.(jpg|png) или любой assets/earth*.jpg|png;
  2. однократная загрузка NASA Blue Marble (public domain) в assets/;
  3. синтетическая «процедурная» Земля (кэшируется в assets/).
Облачность генерируется процедурно и кэшируется.
"""
from __future__ import annotations

import logging
import urllib.request
from pathlib import Path

import cv2
import numpy as np

from .. import imgio

log = logging.getLogger(__name__)

ASSETS = Path(__file__).resolve().parents[2] / "assets"
DOWNLOAD_URLS = [
    "https://eoimages.gsfc.nasa.gov/images/imagerecords/57000/57752/land_shallow_topo_2048.jpg",
    "https://commons.wikimedia.org/wiki/Special:FilePath/Land_shallow_topo_2048.jpg",
]
MAX_WIDTH = 8192


def _read(path: Path) -> np.ndarray | None:
    img = imgio.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        return None
    if img.shape[1] > MAX_WIDTH:
        img = cv2.resize(img, (MAX_WIDTH, MAX_WIDTH // 2), interpolation=cv2.INTER_AREA)
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def try_download(dest: Path, timeout: float = 20.0) -> bool:
    dest.parent.mkdir(parents=True, exist_ok=True)
    for url in DOWNLOAD_URLS:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "SatCamSim/1.0 (education)"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
            arr = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
            if arr is not None and arr.shape[1] >= 1024:
                dest.write_bytes(data)
                log.info("Текстура Земли загружена: %s", url)
                return True
        except Exception as exc:          # сеть недоступна — не страшно
            log.info("Не удалось скачать %s: %s", url, exc)
    return False


def load_earth_texture(allow_download: bool = True) -> tuple[np.ndarray, str]:
    """Возвращает (RGB uint8 H×W×3, описание источника)."""
    if ASSETS.exists():
        cands = sorted(ASSETS.glob("earth_day.*")) + sorted(
            p for p in ASSETS.glob("earth*.*")
            if p.suffix.lower() in (".jpg", ".jpeg", ".png") and "synthetic" not in p.name
            and "clouds" not in p.name)
        for p in cands:
            img = _read(p)
            if img is not None:
                return img, f"файл {p.name}"
    if allow_download:
        dest = ASSETS / "earth_day.jpg"
        if try_download(dest):
            img = _read(dest)
            if img is not None:
                return img, "NASA Blue Marble (загружено)"
    synth = ASSETS / "earth_synthetic.png"
    img = _read(synth) if synth.exists() else None
    if img is None:
        img = synthetic_earth()
        try:
            ASSETS.mkdir(parents=True, exist_ok=True)
            imgio.imwrite(synth, cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        except OSError:
            pass
    return img, "синтетическая текстура"


def load_cloud_texture() -> np.ndarray:
    """Прозрачность облаков, uint8 H×W (0 — ясно, 255 — плотная облачность)."""
    path = ASSETS / "earth_clouds.png"
    if path.exists():
        img = imgio.imread(path, cv2.IMREAD_GRAYSCALE)
        if img is not None:
            return img
    img = synthetic_clouds()
    try:
        ASSETS.mkdir(parents=True, exist_ok=True)
        imgio.imwrite(path, img)
    except OSError:
        pass
    return img


# ---- Процедурный шум на сфере (без швов) ------------------------------------
def _sphere_grid(w: int, h: int) -> np.ndarray:
    lon = (np.arange(w) + 0.5) / w * 2 * np.pi - np.pi
    lat = np.pi / 2 - (np.arange(h) + 0.5) / h * np.pi
    LON, LAT = np.meshgrid(lon, lat)
    return np.stack([np.cos(LAT) * np.cos(LON), np.cos(LAT) * np.sin(LON), np.sin(LAT)], -1), LAT


def _value_noise3(p: np.ndarray, freq: float, rng: np.random.Generator, size: int = 64) -> np.ndarray:
    lattice = rng.random((size, size, size)).astype(np.float32)
    q = (p * freq) % size
    i0 = np.floor(q).astype(np.int32)
    f = q - i0
    f = f * f * (3 - 2 * f)
    i1 = (i0 + 1) % size
    out = 0.0
    for dx in (0, 1):
        for dy in (0, 1):
            for dz in (0, 1):
                ix = i1[..., 0] if dx else i0[..., 0]
                iy = i1[..., 1] if dy else i0[..., 1]
                iz = i1[..., 2] if dz else i0[..., 2]
                wx = f[..., 0] if dx else 1 - f[..., 0]
                wy = f[..., 1] if dy else 1 - f[..., 1]
                wz = f[..., 2] if dz else 1 - f[..., 2]
                out = out + lattice[ix, iy, iz] * wx * wy * wz
    return out


def _fbm(p: np.ndarray, base: float, octaves: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    total, amp, norm = 0.0, 1.0, 0.0
    for k in range(octaves):
        total = total + amp * _value_noise3(p + 17.3 * k, base * 2 ** k, rng)
        norm += amp
        amp *= 0.5
    return total / norm


def synthetic_earth(w: int = 2048, h: int = 1024, seed: int = 7) -> np.ndarray:
    """Правдоподобная, но вымышленная карта Земли (океаны, суша, льды)."""
    p, LAT = _sphere_grid(w, h)
    p = p + 3.0
    n = _fbm(p, 1.6, 7, seed)
    land = n > 0.53
    hgt = np.clip((n - 0.53) / 0.2, 0, 1)
    moist = _fbm(p + 9.1, 2.5, 5, seed + 1)
    alat = np.abs(np.degrees(LAT))

    ocean_deep = np.array([0.02, 0.07, 0.22])
    ocean_shallow = np.array([0.05, 0.22, 0.42])
    depth = np.clip((0.53 - n) / 0.12, 0, 1)[..., None]
    img = ocean_shallow * (1 - depth) + ocean_deep * depth

    forest = np.array([0.11, 0.25, 0.08])
    grass = np.array([0.30, 0.38, 0.16])
    desert = np.array([0.72, 0.60, 0.40])
    tundra = np.array([0.42, 0.40, 0.33])
    rock = np.array([0.45, 0.40, 0.35])
    dry = np.clip((0.55 - moist) / 0.15, 0, 1)
    desert_belt = np.exp(-((alat - 24) / 9) ** 2)
    w_des = np.clip(dry * 1.3 * desert_belt + 0.25 * dry, 0, 1)[..., None]
    w_tun = np.clip((alat - 52) / 12, 0, 1)[..., None]
    veg = forest * np.clip(moist[..., None] * 1.4, 0, 1) + grass * (1 - np.clip(moist[..., None] * 1.4, 0, 1))
    landc = veg * (1 - w_des) + desert * w_des
    landc = landc * (1 - w_tun) + tundra * w_tun
    landc = landc * (1 - 0.5 * hgt[..., None]) + rock * 0.5 * hgt[..., None]
    img = np.where(land[..., None], landc, img)

    ice = (alat + 6 * (_fbm(p + 4.4, 4, 4, seed + 2) - 0.5)) > 72
    img = np.where(ice[..., None], np.array([0.92, 0.94, 0.97]), img)
    img = np.clip(img, 0, 1) ** (1 / 2.2)       # в sRGB
    return (img * 255).astype(np.uint8)


def synthetic_clouds(w: int = 2048, h: int = 1024, seed: int = 21) -> np.ndarray:
    p, LAT = _sphere_grid(w, h)
    # лёгкое «закручивание» по широте — полосы, как у реальной облачности
    swirl = np.stack([p[..., 0] * 1.6, p[..., 1] * 1.6, p[..., 2] * 4.0], -1)
    n = _fbm(swirl + 5.0, 2.2, 7, seed)
    alat = np.abs(np.degrees(LAT))
    bias = 0.04 * np.exp(-((alat - 55) / 15) ** 2) + 0.03 * np.exp(-(alat / 8) ** 2) \
        - 0.05 * np.exp(-((alat - 25) / 8) ** 2)
    c = np.clip((n + bias - 0.50) / 0.18, 0, 1) ** 1.3
    return (c * 255).astype(np.uint8)
