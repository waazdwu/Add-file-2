"""Программный рендерер сцены методом трассировки лучей (numpy).

Один и тот же рендерер строит и кадр бортовой камеры, и «общий вид».
Все расстояния считаются в двойной точности относительно положения
наблюдателя, поэтому в одном кадре корректно сосуществуют метровые детали
аппарата и Земля радиусом 6378 км — без проблем буфера глубины GPU.

Модель излучения упрощённая, в условных единицах «яркости»:
освещённая Солнцем ламбертова поверхность с альбедо a под прямым углом
имеет яркость a; диск Солнца — 3000 (заведомо пересвечивает матрицу).
"""
from __future__ import annotations

import math
import os
from concurrent.futures import ThreadPoolExecutor

CHUNK_MAX = 131072            # лучей в одной полосе (ограничение памяти)
from dataclasses import dataclass

import cv2
import numpy as np

from ..astro import R_EARTH, SUN_ANGULAR_RADIUS, eci_to_ecef_matrix, sunlit_fraction
from ..sensor import Intrinsics
from ..spacecraft import Part
from .textures import load_cloud_texture, load_earth_texture

_GAMMA_LUT = (np.clip(np.arange(4096) / 4095.0, 0, 1) ** (1 / 2.2) * 255 + 0.5).astype(np.uint8)
ATM_COLOR = np.array([0.30, 0.52, 1.0], dtype=np.float32)
ATM_HEIGHT_KM = 120.0
ATM_SCALE_KM = 22.0
SUN_RADIANCE = 3000.0


@dataclass
class ViewCamera:
    pos: np.ndarray            # положение, ECI км
    R: np.ndarray              # столбцы: x (вправо), y (вниз), z (вперёд) в ECI
    intr: Intrinsics
    sat_scale: float = 1.0     # увеличение аппарата (для общего вида)
    hide_camera_parts: bool = False
    show_body: bool = True


@dataclass
class RenderOptions:
    exposure_ev: float = 0.0
    noise: float = 0.0
    bloom: bool = True
    stars: bool = True
    clouds: bool = True
    atmosphere: bool = True
    sun_glint: bool = True
    surface_detail: bool = True
    glare: bool = True
    night_ambient: float = 0.0    # условная подсветка ночной стороны (только для общего вида)
    seed: int | None = None


@dataclass
class RenderInfo:
    earth_fraction: float
    body_fraction: float
    saturated_fraction: float


class Renderer:
    def __init__(self, allow_download: bool = True):
        tex, src = load_earth_texture(allow_download)
        self.texture = tex
        self.texture_source = src
        self.clouds = load_cloud_texture()
        rng = np.random.default_rng(42)
        v = rng.normal(size=(6000, 3))
        self.star_dirs = v / np.linalg.norm(v, axis=1, keepdims=True)
        mags = rng.uniform(0, 1, 6000) ** 0.35 * 6.5          # больше слабых звёзд
        self.star_flux = (10 ** (-0.4 * (mags - 1.0))).astype(np.float32) * 0.6
        self.detail = _periodic_fractal(512, beta=1.9, seed=3)
        self._ray_cache: dict = {}
        self._rng = np.random.default_rng()
        # лучи независимы — кадр делится на полосы и считается на всех ядрах
        # (numpy и OpenCV отпускают GIL на тяжёлых операциях)
        self.workers = max(1, min(8, os.cpu_count() or 2))
        self._pool = ThreadPoolExecutor(max_workers=self.workers) if self.workers > 1 else None

    # ------------------------------------------------------------------------
    def _rays(self, intr: Intrinsics) -> np.ndarray:
        key = (intr.width, intr.height, round(intr.fov_h_deg, 6))
        r = self._ray_cache.get(key)
        if r is None:
            if len(self._ray_cache) > 8:
                self._ray_cache.clear()
            r = intr.local_rays().reshape(-1, 3)
            self._ray_cache[key] = r
        return r

    @staticmethod
    def _sample(tex: np.ndarray, u: np.ndarray, v: np.ndarray) -> np.ndarray:
        """Билинейная выборка из текстуры по нормированным координатам u,v ∈ [0,1)."""
        k = u.size
        cols = 2048
        rows = (k + cols - 1) // cols
        pad = rows * cols - k
        mx = np.concatenate([u * tex.shape[1] - 0.5, np.zeros(pad)]).astype(np.float32).reshape(rows, cols)
        my = np.concatenate([v * tex.shape[0] - 0.5, np.zeros(pad)]).astype(np.float32).reshape(rows, cols)
        # по долготе — циклический повтор, по широте — прижатие к краю
        out = cv2.remap(tex, mx, my, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_WRAP)
        if out.ndim == 2:
            return out.reshape(-1)[:k]
        return out.reshape(-1, tex.shape[2])[:k]

    # ------------------------------------------------------------------------
    def render(self, view: ViewCamera, st, opts: RenderOptions) -> tuple[np.ndarray, RenderInfo]:
        intr = view.intr
        H, W = intr.height, intr.width
        N = H * W
        d = self._rays(intr) @ view.R.T                         # (N,3) в ECI
        img = np.zeros((N, 3), dtype=np.float32)
        hit = np.zeros(N, dtype=bool)
        part_mask = np.zeros(N, dtype=bool)
        sun_c = st.sun_pos - view.pos
        sun_c = sun_c / np.linalg.norm(sun_c)                   # на Солнце от наблюдателя
        sun_e = st.sun_pos / np.linalg.norm(st.sun_pos)         # на Солнце от центра Земли
        sun_vis = sunlit_fraction(view.pos, st.sun_pos)
        geo = self._part_geometry(view, st) if view.show_body else []

        def work(lo: int, hi: int) -> None:
            self._trace(view, st, d[lo:hi], img[lo:hi], hit[lo:hi], part_mask[lo:hi], lo, hi,
                        geo, sun_c, sun_e, sun_vis, opts)

        # Полосы не крупнее CHUNK_MAX лучей: промежуточные массивы трассировки занимают
        # ~300 байт на луч, и кадр полного разрешения матрицы (2048×1536) целиком
        # требовал около 1 ГБ памяти. Одновременно считается не больше `workers` полос.
        n_chunks = max(1, -(-N // CHUNK_MAX))
        if self._pool:
            n_chunks = max(n_chunks, min(self.workers, max(1, N // 30000)))
        if n_chunks == 1:
            work(0, N)
        else:
            bounds = np.linspace(0, N, n_chunks + 1).astype(int)
            spans = list(zip(bounds[:-1], bounds[1:]))
            if self._pool:
                list(self._pool.map(lambda b: work(int(b[0]), int(b[1])), spans))
            else:
                for lo, hi in spans:
                    work(int(lo), int(hi))

        if geo and self._sun_blocked(geo, sun_c):
            sun_vis = 0.0
            ang_r = max(SUN_ANGULAR_RADIUS, 1.6 / intr.fx)
            disk = ~hit & ~part_mask & ((d @ sun_c) > math.cos(ang_r))
            img[disk] = 0.0
        background = ~hit & ~part_mask

        if opts.stars:
            self._stars(img, view, background)

        # ---------------- сенсор ----------------
        img = img.reshape(H, W, 3)
        gain = 2.0 ** opts.exposure_ev
        img *= gain
        if sun_vis > 0 and opts.glare:
            img += self._veiling_glare(view, sun_c, sun_vis * gain)
        if opts.bloom:
            img = self._bloom(img)
        if opts.noise > 0:
            rng = np.random.default_rng(opts.seed) if opts.seed is not None else self._rng
            img += rng.standard_normal(img.shape, dtype=np.float32) * np.float32(opts.noise)
        lum = np.maximum(np.maximum(img[..., 0], img[..., 1]), img[..., 2])
        sat = float(np.count_nonzero(lum >= 1.0)) / N
        q = np.clip(img * 4095.0, 0, 4095).astype(np.uint16)
        out = _GAMMA_LUT[q]
        info = RenderInfo(float(hit.mean()), float(part_mask.mean()), sat)
        return out, info

    # ------------------------------------------------------------------------
    def _trace(self, view, st, d, img, hit_out, part_mask, lo, hi, geo, sun_c, sun_e, sun_vis, opts):
        """Трассировка полосы лучей [lo, hi): Земля, атмосфера, Солнце, аппарат."""
        n = d.shape[0]
        depth = np.full(n, np.inf)                              # метры
        C = -view.pos                                           # центр Земли относит. наблюдателя
        b = d @ C
        c2 = float(C @ C) - R_EARTH ** 2
        disc = b * b - c2
        hit = (disc > 0) & (b > 0)
        hit_out[:] = hit
        idx = np.nonzero(hit)[0]
        if idx.size:
            t = b[idx] - np.sqrt(disc[idx])
            depth[idx] = t * 1000.0
            img[idx] = self._shade_earth(d[idx], t, view.pos, st, sun_e, opts)
        miss = ~hit
        if opts.atmosphere:
            self._limb_glow(img, d, b, C, miss, sun_e)
        ang_r = max(SUN_ANGULAR_RADIUS, 1.6 / view.intr.fx)
        disk = miss & ((d @ sun_c) > math.cos(ang_r))
        img[disk] += SUN_RADIANCE * sun_vis
        if geo:
            self._render_parts(view, st, d, img, depth, part_mask, sun_c, geo, lo, hi)

    def _part_geometry(self, view, st):
        scale = view.sat_scale
        rel_sat = (st.r - view.pos) * 1000.0                     # центр КА относит. наблюдателя, м
        geo = []
        for p in st.parts:
            if view.hide_camera_parts and p.is_camera:
                continue
            Rw = st.R_body @ p.R
            c = rel_sat + st.R_body @ (p.center * scale)
            geo.append((p, Rw, c, p.half * scale))
        return geo

    @staticmethod
    def _sun_blocked(geo, sun_c) -> bool:
        """Закрыт ли диск Солнца элементами аппарата (для засветки)."""
        for p, Rw, c, half in geo:
            t, _, _ = _intersect(p.kind, sun_c[None, :], np.zeros(3), Rw, c, half)
            if np.isfinite(t[0]) and t[0] > 0:
                return True
        return False

    def _shade_earth(self, d, t, cam_pos, st, sun_e, opts):
        p = cam_pos + d * t[:, None]                            # ECI, км
        # дальше достаточно float32 (0.5 м на радиусе Земли)
        n = (p / R_EARTH).astype(np.float32)
        d = d.astype(np.float32)
        sun_e = sun_e.astype(np.float32)
        e = n @ eci_to_ecef_matrix(st.theta_g).T.astype(np.float32)   # ECEF
        lat = np.arcsin(np.clip(e[:, 2], -1, 1))
        lon = np.arctan2(e[:, 1], e[:, 0])
        u = (lon + np.pi) / (2 * np.pi)
        v = (np.pi / 2 - lat) / np.pi
        albedo = (self._sample(self.texture, u, v).astype(np.float32) / 255.0) ** 2.2
        if opts.surface_detail:
            # мелкая неоднородность поверхности (~0.3 км на элемент), трипланарное
            # наложение в координатах Земли — без растяжения у полюсов и без швов
            k = np.float32(R_EARTH / 150.0)
            w = np.abs(e) ** 4
            w /= w.sum(axis=1, keepdims=True)
            q = (e * k) % 1.0
            det = (w[:, 0] * self._sample(self.detail, q[:, 1], q[:, 2])
                   + w[:, 1] * self._sample(self.detail, q[:, 0], q[:, 2])
                   + w[:, 2] * self._sample(self.detail, q[:, 0], q[:, 1]))
            land = albedo[:, 2] < albedo[:, 0] * 1.4
            amp = np.where(land, 1.0, 0.35).astype(np.float32)
            albedo *= (1.0 + (det - 1.0) * amp)[:, None]

        ndl = n @ sun_e
        light = np.clip(ndl, 0, 1).astype(np.float32)
        # мягкий терминатор (рассеяние в атмосфере)
        twilight = (np.clip((ndl + 0.10) / 0.10, 0, 1) * 0.015).astype(np.float32)
        col = albedo * (light + twilight + np.float32(opts.night_ambient))[:, None] * 1.35

        if opts.sun_glint:
            ocean = (albedo[:, 2] > albedo[:, 0] * 1.4) & (albedo[:, 2] > albedo[:, 1] * 1.05)
            if ocean.any():
                h = sun_e[None, :] - d
                h /= np.linalg.norm(h, axis=1, keepdims=True)
                spec = np.clip(np.einsum("ij,ij->i", n, h), 0, 1) ** 180 * 0.30
                col += (spec * ocean * (ndl > 0))[:, None].astype(np.float32) * np.array(
                    [1.0, 0.95, 0.85], np.float32)

        if opts.clouds:
            a = self._sample(self.clouds, u, v).astype(np.float32) / 255.0
            cl = (light * 0.95 + twilight * 2)[:, None] * np.array([1.0, 1.0, 1.0], np.float32)
            col = col * (1 - a[:, None]) + cl * a[:, None]

        if opts.atmosphere:
            mu = np.clip(-np.einsum("ij,ij->i", d, n), 0, 1)
            haze = ((1 - mu) ** 4 * 0.6 + 0.012) * np.clip(ndl + 0.15, 0, 1)
            col = col * (1 - 0.25 * (1 - mu) ** 2)[:, None] + haze[:, None].astype(np.float32) * ATM_COLOR
        return col

    def _limb_glow(self, img, d, b, C, miss, sun_e):
        cc = float(C @ C)
        sel = miss & (b > 0)
        idx = np.nonzero(sel)[0]
        if not idx.size:
            return
        bb = b[idx]
        dmin = np.sqrt(np.maximum(cc - bb * bb, 0))
        hgt = dmin - R_EARTH
        near = hgt < ATM_HEIGHT_KM
        if not near.any():
            return
        idx, bb, hgt = idx[near], bb[near], hgt[near]
        q = -C[None, :] + d[idx] * bb[:, None]                  # ближайшая к центру точка луча
        q /= np.linalg.norm(q, axis=1, keepdims=True)
        lit = np.clip(q @ sun_e + 0.2, 0, 1)
        glow = np.exp(-np.maximum(hgt, 0) / ATM_SCALE_KM) * lit * 0.55
        img[idx] += glow[:, None].astype(np.float32) * ATM_COLOR

    def _stars(self, img, view, background):
        intr = view.intr
        pc = self.star_dirs @ view.R                             # в СК камеры
        front = pc[:, 2] > 0.05
        pc, flux = pc[front], self.star_flux[front]
        px = intr.project(pc)
        x = np.round(px[:, 0]).astype(int)
        y = np.round(px[:, 1]).astype(int)
        ok = (x >= 0) & (x < intr.width) & (y >= 0) & (y < intr.height)
        lin = y[ok] * intr.width + x[ok]
        f = flux[ok]
        keep = background[lin]
        np.add.at(img, lin[keep], f[keep, None] * np.array([0.9, 0.95, 1.0], np.float32))

    def _veiling_glare(self, view, sun_c, amp):
        """Рассеяние света Солнца в оптике: ореол и вуалирующая засветка.

        Работает и когда Солнце чуть за краем кадра — как реальная засветка.
        Функция гладкая, поэтому считается на сетке 1/4 и интерполируется.
        """
        intr = view.intr
        q = 4
        key = (intr.width, intr.height, round(intr.fov_h_deg, 6), "q")
        rays = self._ray_cache.get(key)
        if rays is None:
            rays = intr.local_rays(q)
            self._ray_cache[key] = rays
        cos_s = (rays @ (view.R.T @ sun_c)).astype(np.float32)
        ang = np.arccos(np.clip(cos_s, -1, 1))
        a0 = np.float32(max(SUN_ANGULAR_RADIUS, 1.0 / intr.fx))
        halo = 36.0 * (a0 / (ang + a0)) ** 2.2
        veil = 0.10 * np.exp(-ang / 0.30) + 0.03 * np.exp(-ang / 1.0)
        g = cv2.resize((halo + veil) * np.float32(amp), (intr.width, intr.height),
                       interpolation=cv2.INTER_LINEAR)
        return g[..., None] * np.array([1.0, 0.97, 0.9], np.float32)

    @staticmethod
    def _bloom(img):
        """Ореол вокруг пересвеченных областей (рассеяние в оптике и матрице)."""
        over = np.clip(img - 1.0, 0, 30)
        if not over.any():
            return img
        H, W = img.shape[:2]
        small = cv2.resize(over, (W // 4, H // 4), interpolation=cv2.INTER_AREA)
        s = max(W, H) / 4
        b1 = cv2.GaussianBlur(small, (0, 0), s / 160 + 0.5)
        b2 = cv2.GaussianBlur(small, (0, 0), s / 35)
        b = cv2.resize(0.35 * b1 + 0.10 * b2, (W, H), interpolation=cv2.INTER_LINEAR)
        return img + b

    # ------------------------------------------------------------------------
    def _render_parts(self, view, st, d, img, depth, part_mask, sun_c, geo, lo, hi) -> None:
        """Отрисовка частей аппарата в полосе лучей [lo, hi)."""
        scale = view.sat_scale

        nadir = -st.r / np.linalg.norm(st.r)
        earth_lit = float(np.clip(0.5 + 0.5 * (st.r / np.linalg.norm(st.r)) @ (st.sun_pos / np.linalg.norm(st.sun_pos)), 0, 1))

        hit_part = np.full(d.shape[0], -1, dtype=np.int32)
        hit_n = np.zeros_like(d)
        hit_loc = np.zeros_like(d)
        for k, (p, Rw, c, half) in enumerate(geo):
            cand = _screen_candidates(view, p.kind, Rw, c, half, d)
            if cand is not None:
                cand = cand[(cand >= lo) & (cand < hi)] - lo
            else:
                rb = float(np.linalg.norm(half)) if p.kind == "box" else float(half[0])
                bb = d @ c
                disc = bb * bb - (float(c @ c) - rb * rb)
                cand = np.nonzero((disc > 0) & (bb + np.sqrt(np.maximum(disc, 0)) > 0))[0]
            if not cand.size:
                continue
            t, nrm, loc = _intersect(p.kind, d[cand], np.zeros(3), Rw, c, half)
            ok = np.isfinite(t) & (t > 0) & (t < depth[cand])
            sel = cand[ok]
            depth[sel] = t[ok]
            hit_part[sel] = k
            hit_n[sel] = nrm[ok]
            hit_loc[sel] = loc[ok]

        sel = np.nonzero(hit_part >= 0)[0]
        part_mask[sel] = True
        if sel.size:
            pos = d[sel] * depth[sel][:, None]                    # точки попадания, м (отн. наблюдателя)
            n = hit_n[sel]
            ndl = np.clip(n @ sun_c, 0, 1) * st.sunlit
            # тени от других частей аппарата
            lit_pts = np.nonzero(ndl > 0)[0]
            if lit_pts.size:
                shadow = np.zeros(lit_pts.size, dtype=bool)
                origins = pos[lit_pts] + n[lit_pts] * 1e-4 * scale
                for k, (p, Rw, c, half) in enumerate(geo):
                    if p.is_camera and view.hide_camera_parts:
                        continue
                    dir_ = np.broadcast_to(sun_c, origins.shape)
                    t, _, _ = _intersect(p.kind, dir_, origins, Rw, c, half)
                    shadow |= np.isfinite(t) & (t > 1e-5 * scale)
                ndl[lit_pts[shadow]] = 0.0
            earthshine = np.clip(n @ nadir, 0, 1) * 0.22 * earth_lit
            hvec = sun_c[None, :] - d[sel]
            hvec /= np.linalg.norm(hvec, axis=1, keepdims=True)
            ndh = np.clip(np.einsum("ij,ij->i", n, hvec), 0, 1)
            pid = hit_part[sel]
            col = np.zeros((sel.size, 3), dtype=np.float32)
            for k, (p, Rw, c, half) in enumerate(geo):
                m = pid == k
                if not m.any():
                    continue
                base = np.array(p.color, np.float32)
                bc = np.broadcast_to(base, (int(m.sum()), 3)).copy()
                if p.pattern == "cells":
                    loc = hit_loc[sel][m]
                    front = (Rw[:, 2] @ n[m].T) > 0                 # лицевая сторона панели
                    gx = np.abs(((loc[:, 0] / scale) / 0.11) % 1 - 0.5) > 0.44
                    gy = np.abs(((loc[:, 1] / scale) / 0.11) % 1 - 0.5) > 0.44
                    grid = (gx | gy) & front
                    bc[grid] = (0.55, 0.57, 0.62)
                    bc[~front] = (0.70, 0.70, 0.70)
                spec = p.specular * (ndh[m] ** p.shininess) * (ndl[m] > 0)
                lam = ndl[m] + earthshine[m] + 0.025
                col[m] = bc * lam[:, None] + spec[:, None] * 1.4
            img[sel] = col


def _screen_candidates(view, kind, Rw, c, half, d):
    """Индексы лучей внутри экранного прямоугольника проекции части.

    Если часть целиком позади камеры — пустой массив; если пересекает
    плоскость камеры — None (тогда используется ограничивающая сфера).
    """
    if kind == "box":
        signs = np.array([[sx, sy, sz] for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)], float)
        corners = c + (signs * half) @ Rw.T
    else:
        r = half[0]
        sq = np.array([[1, 1, 0], [1, -1, 0], [-1, 1, 0], [-1, -1, 0]], float) * r
        corners = c + sq @ Rw.T
    pc = corners @ view.R
    z = pc[:, 2]
    if (z <= 0).all():
        return np.empty(0, dtype=np.int64)
    if (z <= 1e-6).any():
        return None
    intr = view.intr
    px = intr.project(pc)
    x0 = max(int(np.floor(px[:, 0].min())) - 1, 0)
    x1 = min(int(np.ceil(px[:, 0].max())) + 1, intr.width - 1)
    y0 = max(int(np.floor(px[:, 1].min())) - 1, 0)
    y1 = min(int(np.ceil(px[:, 1].max())) + 1, intr.height - 1)
    if x0 > x1 or y0 > y1:
        return np.empty(0, dtype=np.int64)
    ys = np.arange(y0, y1 + 1)
    xs = np.arange(x0, x1 + 1)
    return (ys[:, None] * intr.width + xs[None, :]).ravel()


def _periodic_fractal(n: int, beta: float, seed: int) -> np.ndarray:
    """Бесшовная (периодическая) фрактальная текстура: шум с 1/f^beta спектром."""
    rng = np.random.default_rng(seed)
    f = np.fft.fftfreq(n)
    k = np.sqrt(f[:, None] ** 2 + f[None, :] ** 2)
    k[0, 0] = 1.0
    spec = np.fft.fft2(rng.standard_normal((n, n))) / k ** (beta / 2)
    spec[0, 0] = 0
    x = np.real(np.fft.ifft2(spec))
    x = (x - x.mean()) / x.std()
    return (1.0 + 0.16 * x).astype(np.float32)


def _intersect(kind: str, d: np.ndarray, o: np.ndarray, Rw: np.ndarray, c: np.ndarray,
               half: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Пересечение лучей o + t d (o — (3,) или (K,3)) с параллелепипедом/диском.

    Возвращает t (inf при промахе), нормаль в мире, точку в локальной СК.
    """
    ol = (o - c) @ Rw                                         # в локальной СК
    dl = d @ Rw
    K = d.shape[0]
    if ol.ndim == 1:
        ol = np.broadcast_to(ol, (K, 3))
    if kind == "disk":
        dz = dl[:, 2]
        with np.errstate(divide="ignore", invalid="ignore"):
            t = -ol[:, 2] / dz
        loc = ol + dl * t[:, None]
        ok = np.isfinite(t) & (t > 0) & (loc[:, 0] ** 2 + loc[:, 1] ** 2 <= half[0] ** 2)
        t = np.where(ok, t, np.inf)
        sgn = np.where(dz > 0, -1.0, 1.0)
        nrm = Rw[:, 2][None, :] * sgn[:, None]
        return t, nrm, loc
    dl = np.where(np.abs(dl) < 1e-12, 1e-12, dl)
    inv = 1.0 / dl
    t1 = (-half - ol) * inv
    t2 = (half - ol) * inv
    tn = np.minimum(t1, t2)
    tf = np.maximum(t1, t2)
    tmin = np.maximum(np.maximum(tn[:, 0], tn[:, 1]), tn[:, 2])
    tmax = np.minimum(np.minimum(tf[:, 0], tf[:, 1]), tf[:, 2])
    ok = (tmax >= tmin) & (tmin > 0)
    t = np.full(K, np.inf)
    nrm = np.zeros((K, 3))
    loc = np.zeros((K, 3))
    k = np.nonzero(ok)[0]
    if k.size:
        tk = tmin[k]
        t[k] = tk
        tnk = tn[k]
        axis = np.where(tnk[:, 0] == tk, 0, np.where(tnk[:, 1] == tk, 1, 2))
        sgn = -np.sign(dl[k, axis])
        nrm[k] = Rw.T[axis] * sgn[:, None]
        loc[k] = ol[k] + dl[k] * tk[:, None]
    return t, nrm, loc
