"""Камера «общего вида» и векторные наложения (орбита, след, пятно обзора)."""
from __future__ import annotations

import math

import cv2
import numpy as np

from ..astro import R_EARTH, rot_z
from ..config import ViewConfig
from ..orbit import orbit_track, propagate
from ..sensor import Intrinsics
from ..spacecraft import unit
from .raycast import ViewCamera

VIEW_MODES = {
    "earth": "Земля и орбита",
    "follow": "Следовать за спутником",
    "closeup": "Спутник крупным планом",
}


def look_at(pos: np.ndarray, target: np.ndarray, up_hint: np.ndarray) -> np.ndarray:
    f = unit(target - pos)
    r = np.cross(f, up_hint)
    if np.linalg.norm(r) < 1e-9:
        r = np.cross(f, np.array([1.0, 0, 0]) if abs(f[0]) < 0.9 else np.array([0, 1.0, 0]))
    r = unit(r)
    down = np.cross(f, r)
    return np.column_stack([r, down, f])


def overview_camera(vc: ViewConfig, st) -> ViewCamera:
    az, el = math.radians(vc.azimuth_deg), math.radians(vc.elevation_deg)
    if vc.mode == "closeup":
        # СК аппарата: «верх» экрана — зенит (−Z связанной СК)
        B = st.R_body
        dir_ = (math.cos(el) * math.cos(az) * B[:, 0] + math.cos(el) * math.sin(az) * B[:, 1]
                - math.sin(el) * B[:, 2])
        pos = st.r + dir_ * vc.distance_m / 1000.0
        R = look_at(pos, st.r, -B[:, 2])
        intr = Intrinsics(vc.width, vc.height, 50.0)
        return ViewCamera(pos, R, intr, sat_scale=1.0, hide_camera_parts=False)

    if vc.mode == "follow":
        # камера-«преследователь»: az=0 — позади КА, el — над местным горизонтом
        up = unit(st.r)
        fwd = unit(st.v - np.dot(st.v, up) * up)
        side = np.cross(up, fwd)
        dir_ = (math.cos(el) * (-math.cos(az) * fwd + math.sin(az) * side) + math.sin(el) * up)
        dist = vc.follow_distance_km
        pos = st.r + dir_ * dist
        R = look_at(pos, st.r, up)
        intr = Intrinsics(vc.width, vc.height, 45.0)
        frac = 0.10
    else:
        # инерциальная СК, привязанная к плоскости орбиты: el = 90° — взгляд сверху на виток
        h = unit(np.cross(st.r, st.v))
        node = np.cross(np.array([0, 0, 1.0]), h)
        node = unit(node) if np.linalg.norm(node) > 1e-6 else np.array([1.0, 0, 0])
        E = np.column_stack([node, np.cross(h, node), h])
        dir_ = E @ np.array([math.cos(el) * math.cos(az), math.cos(el) * math.sin(az), math.sin(el)])
        dist = vc.distance_km
        pos = dir_ * dist
        R = look_at(pos, np.zeros(3), h if abs(math.sin(el)) < 0.98 else E[:, 1])
        intr = Intrinsics(vc.width, vc.height, 40.0)
        frac = 0.035
    # Видимый размер КА — доля ширины кадра (реальный был бы меньше пикселя)
    span_m = 5.6
    want_m = frac * 2 * dist * math.tan(math.radians(intr.fov_h_deg / 2)) * 1000
    scale = max(1.0, want_m / span_m) * vc.sat_scale
    return ViewCamera(pos, R, intr, sat_scale=scale, hide_camera_parts=False)


# ---- Наложения ---------------------------------------------------------------
def _project(view: ViewCamera, P: np.ndarray):
    """Пиксели и признак видимости (перед камерой и не за Землёй) для точек ECI."""
    rel = P - view.pos
    pc = rel @ view.R
    front = pc[:, 2] > 1e-6
    px = np.full((len(P), 2), np.nan)
    px[front] = view.intr.project(pc[front])
    L = np.linalg.norm(rel, axis=1)
    d = rel / L[:, None]
    C = -view.pos
    b = d @ C
    disc = b * b - (C @ C - R_EARTH ** 2)
    tn = b - np.sqrt(np.maximum(disc, 0))
    behind = (disc > 0) & (tn > 0) & (tn < L - 1.0)
    return px, front & ~behind


def _polyline(img, px, vis, color, width=2, hidden_color=None, closed=False):
    n = len(px)
    rng = range(n if closed else n - 1)
    for i in rng:
        j = (i + 1) % n
        a, b = px[i], px[j]
        if np.isnan(a).any() or np.isnan(b).any():
            continue
        if abs(a[0]) > 1e5 or abs(b[0]) > 1e5 or abs(a[1]) > 1e5 or abs(b[1]) > 1e5:
            continue
        both = vis[i] and vis[j]
        col = color if both else hidden_color
        if col is None:
            continue
        cv2.line(img, (int(a[0] * 16), int(a[1] * 16)), (int(b[0] * 16), int(b[1] * 16)), col,
                 width if both else 1, cv2.LINE_AA, shift=4)


def footprint(st, n_edge: int = 24) -> np.ndarray | None:
    """Контур поля зрения камеры на поверхности Земли (ECI, км)."""
    intr = st.intr
    W, H = intr.width - 1, intr.height - 1
    xs = np.linspace(0, W, n_edge)
    ys = np.linspace(0, H, n_edge)
    border = np.concatenate([
        np.stack([xs, np.zeros_like(xs)], 1), np.stack([np.full_like(ys, W), ys], 1),
        np.stack([xs[::-1], np.full_like(xs, H)], 1), np.stack([np.zeros_like(ys), ys[::-1]], 1)])
    loc = np.stack([(border[:, 0] - intr.cx) / intr.fx, (border[:, 1] - intr.cy) / intr.fy,
                    np.ones(len(border))], 1)
    d = loc @ st.cam_R.T
    d /= np.linalg.norm(d, axis=1, keepdims=True)
    C = -st.cam_pos
    b = d @ C
    disc = b * b - (C @ C - R_EARTH ** 2)
    ok = (disc > 0) & (b > 0)
    if ok.sum() < 3:
        return None
    t = b - np.sqrt(np.maximum(disc, 0))
    # лучи мимо Земли прижимаем к горизонту (касательная точка)
    t_h = np.sqrt(max(C @ C - R_EARTH ** 2, 0))
    t = np.where(ok, t, t_h)
    P = st.cam_pos + d * t[:, None]
    P = P / np.linalg.norm(P, axis=1, keepdims=True) * R_EARTH * 1.0015
    return P


def draw_overlays(img: np.ndarray, view: ViewCamera, st, vc: ViewConfig, orbit_el) -> None:
    closeup = vc.mode == "closeup"
    if vc.show_orbit and not closeup:
        pts = orbit_track(orbit_el, st.t, 240)
        px, vis = _project(view, pts)
        _polyline(img, px, vis, (90, 220, 255), 2, hidden_color=(40, 90, 110))

    if vc.show_ground_track and not closeup:
        T = orbit_el.period_s
        ts = st.t + np.linspace(0, T, 200)
        pts = []
        for tk in ts:
            r, _ = propagate(orbit_el, tk)
            # учёт вращения Земли: «замораживаем» Землю в текущем положении
            ang = 7.2921150e-5 * (tk - st.t)
            p = rot_z(-ang) @ r
            pts.append(p / np.linalg.norm(p) * R_EARTH * 1.002)
        px, vis = _project(view, np.array(pts))
        _polyline(img, px, vis, (255, 170, 60), 2)

    if vc.show_footprint:
        fp = footprint(st)
        if fp is not None:
            px, vis = _project(view, fp)
            _polyline(img, px, vis, (120, 255, 120), 2, closed=True)
            if not closeup:
                corners = fp[[0, 24, 48, 72]]
                for P in corners:
                    px2, vis2 = _project(view, np.array([st.cam_pos, P]))
                    _polyline(img, px2, vis2, (120, 255, 120), 1)

    if not closeup:
        # маркер спутника, чтобы его было легко найти на общем виде
        px, vis = _project(view, st.r[None, :])
        if not np.isnan(px).any():
            c = (int(px[0][0]), int(px[0][1]))
            col = (255, 255, 255) if vis[0] else (110, 110, 130)
            cv2.circle(img, c, 16, col, 1, cv2.LINE_AA)
            cv2.line(img, (c[0] + 12, c[1] - 12), (c[0] + 24, c[1] - 24), col, 1, cv2.LINE_AA)

    if vc.show_vectors:
        if closeup:
            L = 2.5 / 1000.0
            items = [(st.cam_pos, st.cam_R[:, 2] * 6 * L, (255, 80, 220)),
                     (st.r, st.sun_dir * L * 1.4, (255, 220, 60)),
                     (st.r, -unit(st.r) * L * 1.4, (90, 220, 255))]
        else:
            Re = R_EARTH
            t_b = _ground_range(st)
            bore_len = t_b if t_b is not None else 3000.0
            items = [(np.zeros(3), unit(st.sun_pos) * Re * 1.9, (255, 220, 60)),
                     (st.cam_pos, st.cam_R[:, 2] * bore_len, (255, 80, 220)),
                     (st.r, unit(st.v) * Re * 0.25, (220, 220, 220))]
        for p0, vec, col in items:
            P = np.array([p0, p0 + vec])
            px, vis = _project(view, P)
            if np.isnan(px).any():
                continue
            _polyline(img, px, vis, col, 2, hidden_color=None)
            if vis[1]:
                cv2.circle(img, (int(px[1][0]), int(px[1][1])), 3, col, -1, cv2.LINE_AA)


def _ground_range(st):
    g = st.metrics.get("ground")
    return g["range_km"] if g else None
