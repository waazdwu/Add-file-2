"""Параметры сценария. Всё, что можно менять из интерфейса, лежит здесь.

Сценарий целиком сохраняется/загружается как JSON.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any

from .orbit import OrbitElements


@dataclass
class TimeConfig:
    epoch_utc: str = "2026-06-21T06:00:00"   # момент начала моделирования (UTC)
    time_scale: float = 60.0                 # ускорение времени (модельные с / реальную с); 60× — виток за ~95 с
    paused: bool = False


@dataclass
class AttitudeConfig:
    mode: str = "lvlh"           # lvlh | inertial | sun
    yaw_deg: float = 0.0
    pitch_deg: float = 0.0
    roll_deg: float = 0.0
    panel_tracking: bool = True  # автоповорот панелей на Солнце
    panel_angle_deg: float = 0.0


@dataclass
class CameraConfig:
    # крепление
    face: str = "+Z"
    u: float = 0.0
    v: float = 0.0
    azimuth_deg: float = 0.0     # привод: азимут относительно нормали грани
    tilt_deg: float = 0.0        # привод: угол места (+ вверх, − вниз)
    roll_deg: float = 0.0        # поворот кадра вокруг оси
    max_tilt_deg: float = 90.0   # предельное отклонение оси от нормали грани
    # наведение
    pointing: str = "manual"     # manual | nadir | target | sun | velocity
    target_lat: float = 55.75
    target_lon: float = 37.62
    # модель камеры: sensor — реальная (матрица + объектив), fov — условная (поле зрения задаётся напрямую)
    optics_mode: str = "sensor"
    # матрица (по умолчанию — паспорт Sony IMX265LQR-C)
    sensor_preset: str = "imx265lqr"
    pixel_um: float = 3.45
    sensor_w_px: int = 2048
    sensor_h_px: int = 1536
    binning: int = 1             # объединение пикселей N×N (1 — нет, 2 — 2×2)
    # объектив (по умолчанию — 50 мм f/1,8)
    lens_preset: str = "50f18"
    focal_mm: float = 50.0
    f_number: float = 1.8
    # предпросмотр: кадр в окне трансляции считается в 1/N разрешения (запись датасетов — в полном)
    preview_scale: int = 4
    # условная камера (режим fov)
    width: int = 640
    height: int = 480
    fov_h_deg: float = 60.0
    exposure_ev: float = 0.0     # экспокоррекция, ступени
    noise: float = 0.0           # СКО шума, доли полной шкалы
    bloom: bool = True           # засветка / ореол от ярких объектов
    stars: bool = True
    show_own_body: bool = True   # видеть элементы конструкции аппарата


@dataclass
class SceneConfig:
    clouds: bool = True
    atmosphere: bool = True
    sun_glint: bool = True        # солнечный блик на океане
    surface_detail: bool = True   # мелкая процедурная детализация поверхности


@dataclass
class ViewConfig:
    mode: str = "earth"          # earth | follow | closeup
    azimuth_deg: float = -60.0
    elevation_deg: float = 78.0       # для режима earth — угол над плоскостью орбиты
    distance_km: float = 40000.0  # для режима earth
    follow_distance_km: float = 2500.0  # для режима follow
    distance_m: float = 9.0       # для режима closeup
    width: int = 880
    height: int = 600
    sat_scale: float = 1.0        # доп. множитель видимого размера аппарата
    render_scale: float = 0.75    # разрешение рендера общего вида (доля), меньше — быстрее
    show_orbit: bool = True
    show_footprint: bool = True
    show_vectors: bool = True
    show_ground_track: bool = False


@dataclass
class SimConfig:
    orbit: OrbitElements = field(default_factory=lambda: OrbitElements(
        perigee_alt_km=500.0, inclination_deg=51.6, raan_deg=110.0, mean_anomaly_deg=0.0))
    attitude: AttitudeConfig = field(default_factory=AttitudeConfig)
    camera: CameraConfig = field(default_factory=CameraConfig)
    time: TimeConfig = field(default_factory=TimeConfig)
    view: ViewConfig = field(default_factory=ViewConfig)
    scene: SceneConfig = field(default_factory=SceneConfig)
    fps: float = 20.0

    # ---- сериализация ------------------------------------------------------
    def to_dict(self) -> dict:
        return asdict(self)

    def update(self, changes: dict[str, Any]) -> list[str]:
        """Обновить поля по «точечным» ключам: {"orbit.inclination_deg": 97.4}.

        Значения приводятся к типу существующего поля. Возвращает список
        реально изменённых ключей; неизвестные ключи игнорируются.
        """
        changed = []
        for key, value in changes.items():
            obj: Any = self
            parts = key.split(".")
            try:
                for p in parts[:-1]:
                    obj = getattr(obj, p)
                name = parts[-1]
                old = getattr(obj, name)
            except AttributeError:
                continue
            if is_dataclass(old):
                continue
            new = _coerce(value, old)
            if new != old:
                setattr(obj, name, new)
                changed.append(key)
        return changed

    def load_dict(self, d: dict) -> None:
        # Сценарии, сохранённые до появления модели «матрица + объектив»,
        # открываются в прежнем режиме условной камеры (с их полем зрения).
        cam = d.get("camera")
        if isinstance(cam, dict) and "optics_mode" not in cam:
            cam = dict(cam, optics_mode="fov")
            d = dict(d, camera=cam)
        flat = {}

        def walk(prefix, node):
            for k, v in node.items():
                key = f"{prefix}{k}"
                if isinstance(v, dict):
                    walk(key + ".", v)
                else:
                    flat[key] = v
        walk("", d)
        self.update(flat)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "SimConfig":
        cfg = cls()
        cfg.load_dict(json.loads(Path(path).read_text(encoding="utf-8")))
        return cfg


def _coerce(value: Any, like: Any) -> Any:
    if isinstance(like, bool):
        if isinstance(value, str):
            return value.lower() in ("1", "true", "yes", "on")
        return bool(value)
    if isinstance(like, int):
        return int(round(float(value)))
    if isinstance(like, float):
        return float(value)
    return str(value) if value is not None else like


def field_names(dc) -> list[str]:
    return [f.name for f in fields(dc)]
