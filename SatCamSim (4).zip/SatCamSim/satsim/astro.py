"""Астрономические расчёты: время, Солнце, вращение Земли, тень Земли.

Система координат ECI: ось X — на точку весеннего равноденствия,
ось Z — на северный полюс мира (упрощённая J2000 без прецессии/нутации).
Единицы: километры, секунды, радианы.
"""
from __future__ import annotations

import math
from datetime import datetime, timezone

import numpy as np

# ---- Константы -------------------------------------------------------------
MU_EARTH = 398600.4418          # км^3/с^2, гравитационный параметр Земли
R_EARTH = 6378.137              # км, экваториальный радиус (WGS-84)
J2 = 1.08262668e-3              # вторая зональная гармоника
OMEGA_EARTH = 7.2921150e-5      # рад/с, угловая скорость вращения Земли
AU = 149597870.7                # км, астрономическая единица
R_SUN = 695700.0                # км, радиус Солнца
SOLAR_CONSTANT = 1361.0         # Вт/м^2 на 1 а.е.
SUN_ANGULAR_RADIUS = R_SUN / AU  # рад (~0.2666°)


# ---- Время ------------------------------------------------------------------
def julian_date(t: datetime) -> float:
    """Юлианская дата для момента UTC."""
    if t.tzinfo is None:
        t = t.replace(tzinfo=timezone.utc)
    t = t.astimezone(timezone.utc)
    # JD для 2000-01-01 12:00 UTC = 2451545.0
    epoch = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    return 2451545.0 + (t - epoch).total_seconds() / 86400.0


def gmst(jd: float) -> float:
    """Гринвичское среднее звёздное время, рад (IAU-82, упрощённо)."""
    d = jd - 2451545.0
    T = d / 36525.0
    deg = 280.46061837 + 360.98564736629 * d + 0.000387933 * T * T - T ** 3 / 38710000.0
    return math.radians(deg % 360.0)


# ---- Солнце -----------------------------------------------------------------
def sun_position_eci(jd: float) -> np.ndarray:
    """Вектор Земля→Солнце в ECI, км.

    Алгоритм низкой точности из Astronomical Almanac (точность ~0.01°
    в 1950–2050 гг.), более чем достаточно для освещённости и тени.
    """
    n = jd - 2451545.0
    L = math.radians((280.460 + 0.9856474 * n) % 360.0)
    g = math.radians((357.528 + 0.9856003 * n) % 360.0)
    lam = L + math.radians(1.915) * math.sin(g) + math.radians(0.020) * math.sin(2 * g)
    eps = math.radians(23.439 - 0.0000004 * n)
    r_au = 1.00014 - 0.01671 * math.cos(g) - 0.00014 * math.cos(2 * g)
    r = r_au * AU
    return np.array([
        r * math.cos(lam),
        r * math.cos(eps) * math.sin(lam),
        r * math.sin(eps) * math.sin(lam),
    ])


# ---- Преобразования ECI <-> ECEF -------------------------------------------
def rot_z(angle: float) -> np.ndarray:
    c, s = math.cos(angle), math.sin(angle)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def eci_to_ecef_matrix(theta_g: float) -> np.ndarray:
    """Матрица перехода ECI→ECEF (поворот на -GMST вокруг Z)."""
    return rot_z(-theta_g)


def ecef_to_latlon(p: np.ndarray) -> tuple[float, float]:
    """Геоцентрические широта и долгота (рад) точки ECEF."""
    x, y, z = p
    lon = math.atan2(y, x)
    lat = math.atan2(z, math.hypot(x, y))
    return lat, lon


def latlon_to_ecef(lat: float, lon: float, r: float = R_EARTH) -> np.ndarray:
    cl = math.cos(lat)
    return np.array([r * cl * math.cos(lon), r * cl * math.sin(lon), r * math.sin(lat)])


# ---- Тень Земли (коническая модель) -----------------------------------------
def _disk_overlap_fraction(a: float, b: float, c: float) -> float:
    """Доля площади диска радиуса a, закрытая диском радиуса b,
    при угловом расстоянии центров c (все величины — углы, рад)."""
    if c >= a + b:
        return 0.0
    if c <= abs(b - a):
        return 1.0 if b >= a else (b * b) / (a * a)
    # Площадь пересечения двух кругов (плоское приближение малых углов)
    x = (c * c + a * a - b * b) / (2 * c)
    y = math.sqrt(max(a * a - x * x, 0.0))
    area = (a * a * math.acos(max(-1.0, min(1.0, x / a)))
            + b * b * math.acos(max(-1.0, min(1.0, (c - x) / b)))
            - c * y)
    return max(0.0, min(1.0, area / (math.pi * a * a)))


def sunlit_fraction(r_obj: np.ndarray, r_sun: np.ndarray) -> float:
    """Доля видимого диска Солнца из точки r_obj (ECI, км).

    1 — полностью освещено, 0 — полная тень (умбра), между — полутень.
    Используется модель видимых дисков Солнца и Земли.
    """
    to_sun = r_sun - r_obj
    d_sun = np.linalg.norm(to_sun)
    d_earth = np.linalg.norm(r_obj)
    if d_earth <= R_EARTH:
        return 0.0
    a = math.asin(min(1.0, R_SUN / d_sun))            # угловой радиус Солнца
    b = math.asin(min(1.0, R_EARTH / d_earth))        # угловой радиус Земли
    cosc = float(np.dot(to_sun, -r_obj) / (d_sun * d_earth))
    c = math.acos(max(-1.0, min(1.0, cosc)))          # угол между центрами
    return 1.0 - _disk_overlap_fraction(a, b, c)


def solar_flux(r_obj: np.ndarray, r_sun: np.ndarray) -> float:
    """Плотность потока солнечного излучения в точке, Вт/м^2 (без учёта тени)."""
    d = np.linalg.norm(r_sun - r_obj)
    return SOLAR_CONSTANT * (AU / d) ** 2
