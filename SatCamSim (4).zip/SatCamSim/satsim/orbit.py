"""Кеплерова орбита с опциональными вековыми возмущениями от J2."""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .astro import J2, MU_EARTH, R_EARTH


@dataclass
class OrbitElements:
    """Элементы орбиты. Углы — в градусах (как в интерфейсе)."""
    perigee_alt_km: float = 500.0     # высота перигея над экватором
    eccentricity: float = 0.0
    inclination_deg: float = 51.6
    raan_deg: float = 0.0             # долгота восходящего узла
    arg_perigee_deg: float = 0.0
    mean_anomaly_deg: float = 0.0     # средняя аномалия на эпоху
    use_j2: bool = False

    @property
    def a(self) -> float:
        return (R_EARTH + self.perigee_alt_km) / (1.0 - self.eccentricity)

    @property
    def period_s(self) -> float:
        return 2 * math.pi * math.sqrt(self.a ** 3 / MU_EARTH)


def solve_kepler(M: float, e: float, tol: float = 1e-12) -> float:
    """Решение уравнения Кеплера E - e sin E = M методом Ньютона."""
    M = math.fmod(M, 2 * math.pi)
    E = M if e < 0.8 else math.pi
    for _ in range(50):
        f = E - e * math.sin(E) - M
        dE = -f / (1 - e * math.cos(E))
        E += dE
        if abs(dE) < tol:
            break
    return E


def j2_rates(el: OrbitElements) -> tuple[float, float, float]:
    """Вековые скорости (рад/с) изменения RAAN, аргумента перигея и ср. аномалии."""
    a, e = el.a, el.eccentricity
    i = math.radians(el.inclination_deg)
    n = math.sqrt(MU_EARTH / a ** 3)
    p = a * (1 - e * e)
    k = 1.5 * J2 * (R_EARTH / p) ** 2 * n
    d_raan = -k * math.cos(i)
    d_argp = k * (2 - 2.5 * math.sin(i) ** 2)
    d_M = k * math.sqrt(1 - e * e) * (1 - 1.5 * math.sin(i) ** 2)
    return d_raan, d_argp, d_M


def sun_synchronous_inclination(alt_km: float) -> float:
    """Наклонение (град) солнечно-синхронной круговой орбиты на высоте alt_km."""
    a = R_EARTH + alt_km
    n = math.sqrt(MU_EARTH / a ** 3)
    target = 2 * math.pi / (365.2421897 * 86400.0)   # рад/с
    cos_i = -target / (1.5 * J2 * (R_EARTH / a) ** 2 * n)
    return math.degrees(math.acos(max(-1.0, min(1.0, cos_i))))


def propagate(el: OrbitElements, t: float) -> tuple[np.ndarray, np.ndarray]:
    """Положение и скорость (ECI, км и км/с) через t секунд после эпохи."""
    a, e = el.a, el.eccentricity
    n = math.sqrt(MU_EARTH / a ** 3)
    raan = math.radians(el.raan_deg)
    argp = math.radians(el.arg_perigee_deg)
    M = math.radians(el.mean_anomaly_deg) + n * t
    if el.use_j2:
        d_raan, d_argp, d_M = j2_rates(el)
        raan += d_raan * t
        argp += d_argp * t
        M += d_M * t

    E = solve_kepler(M, e)
    cosE, sinE = math.cos(E), math.sin(E)
    sq = math.sqrt(1 - e * e)
    # Перифокальная система
    r_pf = np.array([a * (cosE - e), a * sq * sinE, 0.0])
    r_mag = a * (1 - e * cosE)
    v_pf = np.array([-math.sin(E), sq * cosE, 0.0]) * (math.sqrt(MU_EARTH * a) / r_mag)

    Q = perifocal_to_eci(raan, math.radians(el.inclination_deg), argp)
    return Q @ r_pf, Q @ v_pf


def perifocal_to_eci(raan: float, inc: float, argp: float) -> np.ndarray:
    cO, sO = math.cos(raan), math.sin(raan)
    ci, si = math.cos(inc), math.sin(inc)
    cw, sw = math.cos(argp), math.sin(argp)
    return np.array([
        [cO * cw - sO * sw * ci, -cO * sw - sO * cw * ci, sO * si],
        [sO * cw + cO * sw * ci, -sO * sw + cO * cw * ci, -cO * si],
        [sw * si, cw * si, ci],
    ])


def orbit_track(el: OrbitElements, t: float, n: int = 240) -> np.ndarray:
    """Точки текущего витка (ECI, км) для отрисовки, начиная с момента t."""
    T = el.period_s
    return np.array([propagate(el, t + T * k / (n - 1))[0] for k in range(n)])
