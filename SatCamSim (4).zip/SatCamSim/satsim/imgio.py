"""Чтение/запись изображений, устойчивые к не-ASCII путям (кириллица в Windows).

cv2.imread/imwrite в Windows не открывают пути с кириллицей, поэтому
кодирование выполняется в памяти, а файл пишет/читает сам Python.
"""
from __future__ import annotations

import os
import shutil
import uuid
from pathlib import Path

import cv2
import numpy as np


def imread(path, flags=cv2.IMREAD_COLOR):
    try:
        data = np.fromfile(str(path), dtype=np.uint8)
    except OSError:
        return None
    if data.size == 0:
        return None
    return cv2.imdecode(data, flags)


def imwrite(path, img, params=None) -> bool:
    path = Path(path)
    ok, buf = cv2.imencode(path.suffix or ".png", img, params or [])
    if not ok:
        return False
    buf.tofile(str(path))
    return True


class VideoWriter:
    """cv2.VideoWriter, который корректно работает с не-ASCII путями:
    пишет во временный файл с ASCII-именем в текущей папке и переносит при закрытии."""

    def __init__(self, path, fps: float, size: tuple[int, int]):
        self.final = Path(path)
        target = str(self.final)
        self.tmp = None
        if not target.isascii():
            self.tmp = f"_satsim_video_{uuid.uuid4().hex[:8]}.mp4"
            target = self.tmp
        self.vw = cv2.VideoWriter(target, cv2.VideoWriter_fourcc(*"mp4v"), fps, size)

    def write(self, img):
        self.vw.write(img)

    def release(self):
        self.vw.release()
        if self.tmp and os.path.exists(self.tmp):
            shutil.move(self.tmp, self.final)
