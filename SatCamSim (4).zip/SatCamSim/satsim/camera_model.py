"""Модель камеры как реального прибора: матрица + объектив.

Этап 1 — геометрия. Камера задаётся так же, как реальная:
    размер пикселя p, число пикселей W × H, бининг, фокусное расстояние f,
    диафрагменное число N.
Поле зрения, угловой размер пикселя, размер матрицы, апертура и т.д.
вычисляются из них (а не задаются напрямую, как в «условной» камере).

Паспортные данные матрицы Sony IMX265 (Pregius, 1/1,8″, глобальный затвор):
    FRAMOS IMX265LQR-C / IMX265LLR-C; измерения EMVA 1288 — камеры
    Teledyne FLIR Blackfly S BFS-U3-31S4 (M — моно, C — цвет).
Параметры матрицы, не влияющие на геометрию (шумы, ёмкость, квантовая
эффективность), хранятся здесь для следующих этапов.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .sensor import Intrinsics

WAVELENGTH_UM = 0.55          # расчётная длина волны (полоса V)

# ---- Паспортные данные матриц ------------------------------------------------
SENSORS = {
    "imx265lqr": {
        "name": "Sony IMX265LQR-C (цветная, Байер)",
        "short": "IMX265LQR-C",
        "chroma": "bayer",
        "pixel_um": 3.45, "w_px": 2048, "h_px": 1536,       # рабочее разрешение
        "total_w_px": 2064, "total_h_px": 1544,             # эффективное разрешение
        "max_fps": 55.6, "adc_bits": 12, "shutter": "глобальный",
        # EMVA 1288 (FLIR BFS-U3-31S4C): для следующих этапов
        "full_well_e": 10689, "read_noise_e": 2.21,
        "qe": {"R": 0.4453, "G": 0.5621, "B": 0.4713}, "dynamic_range_db": 71.92,
    },
    "imx265llr": {
        "name": "Sony IMX265LLR-C (монохромная)",
        "short": "IMX265LLR-C",
        "chroma": "mono",
        "pixel_um": 3.45, "w_px": 2048, "h_px": 1536,
        "total_w_px": 2064, "total_h_px": 1544,
        "max_fps": 55.6, "adc_bits": 12, "shutter": "глобальный",
        # EMVA 1288 (FLIR BFS-U3-31S4M)
        "full_well_e": 10791, "read_noise_e": 2.26,
        "qe": {"mono": 0.6236}, "dynamic_range_db": 71.83,
    },
}

# ---- Типовые объективы -----------------------------------------------------
LENSES = {
    "25f14": {"name": "25 мм f/1,4 — широкий обзор, поиск", "focal_mm": 25.0, "f_number": 1.4},
    "50f18": {"name": "50 мм f/1,8 — основной (компромисс)", "focal_mm": 50.0, "f_number": 1.8},
    "75f20": {"name": "75 мм f/2,0 — сопровождение, слабые объекты", "focal_mm": 75.0, "f_number": 2.0},
}


@dataclass
class CameraGeometry:
    """Геометрия камеры с учётом бининга."""
    pixel_um: float           # эффективный размер пикселя (с бинингом)
    w_px: int                 # эффективное число пикселей (с бинингом)
    h_px: int
    focal_mm: float
    f_number: float
    binning: int = 1

    # размер матрицы — не зависит от бининга
    @property
    def sensor_w_mm(self) -> float:
        return self.w_px * self.pixel_um / 1000.0

    @property
    def sensor_h_mm(self) -> float:
        return self.h_px * self.pixel_um / 1000.0

    @property
    def sensor_diag_mm(self) -> float:
        return math.hypot(self.sensor_w_mm, self.sensor_h_mm)

    def _fov(self, size_mm: float) -> float:
        return math.degrees(2 * math.atan(size_mm / (2 * self.focal_mm)))

    @property
    def fov_h_deg(self) -> float:
        return self._fov(self.sensor_w_mm)

    @property
    def fov_v_deg(self) -> float:
        return self._fov(self.sensor_h_mm)

    @property
    def fov_d_deg(self) -> float:
        return self._fov(self.sensor_diag_mm)

    @property
    def ifov_rad(self) -> float:
        """Угловой размер пикселя (в центре кадра): p / f."""
        return self.pixel_um / (self.focal_mm * 1000.0)

    @property
    def aperture_mm(self) -> float:
        return self.focal_mm / self.f_number

    @property
    def airy_um(self) -> float:
        """Диаметр дифракционного пятна (до первого тёмного кольца): 2,44·λ·N."""
        return 2.44 * WAVELENGTH_UM * self.f_number

    @property
    def megapixels(self) -> float:
        return self.w_px * self.h_px / 1e6

    def pixel_at_range_m(self, range_km: float) -> float:
        """Размер пикселя на дальности R (поперёк луча), м."""
        return range_km * 1000.0 * self.ifov_rad

    def intrinsics(self) -> Intrinsics:
        # fx = (W/2)/tan(fov/2) = f/p — точно согласовано с геометрией
        return Intrinsics(self.w_px, self.h_px, self.fov_h_deg)


def geometry(c) -> CameraGeometry:
    """Геометрия из настроек камеры (CameraConfig) в режиме «матрица + объектив»."""
    b = max(1, int(c.binning))
    return CameraGeometry(pixel_um=c.pixel_um * b, w_px=max(1, c.sensor_w_px // b),
                          h_px=max(1, c.sensor_h_px // b), focal_mm=c.focal_mm,
                          f_number=c.f_number, binning=b)


def intrinsics(c) -> Intrinsics:
    """Внутренние параметры камеры для расчёта кадра (полное разрешение матрицы)."""
    if c.optics_mode == "sensor":
        return geometry(c).intrinsics()
    return Intrinsics(c.width, c.height, c.fov_h_deg)


def passport_deviations(c) -> list[str]:
    """Какие параметры отличаются от паспорта выбранной матрицы и объектива."""
    out = []
    s = SENSORS.get(c.sensor_preset)
    if s:
        if abs(c.pixel_um - s["pixel_um"]) > 1e-6:
            out.append("размер пикселя")
        if c.sensor_w_px != s["w_px"] or c.sensor_h_px != s["h_px"]:
            out.append("число пикселей")
    else:
        out.append("матрица задана вручную")
    lens = LENSES.get(c.lens_preset)
    if lens:
        if abs(c.focal_mm - lens["focal_mm"]) > 1e-6 or abs(c.f_number - lens["f_number"]) > 1e-6:
            out.append("объектив")
    else:
        out.append("объектив задан вручную")
    return out


def derived(c, range_km: float | None = None) -> dict:
    """Производные характеристики для панели расчёта и метаданных кадра."""
    if c.optics_mode != "sensor":
        i = Intrinsics(c.width, c.height, c.fov_h_deg)
        return {"mode": "fov", "fov_h_deg": c.fov_h_deg, "fov_v_deg": i.fov_v_deg,
                "w_px": c.width, "h_px": c.height, "ifov_urad": i.ifov_rad * 1e6}
    g = geometry(c)
    s = SENSORS.get(c.sensor_preset, {})
    d = {
        "mode": "sensor",
        "sensor": s.get("short", "своя матрица"),
        "chroma": s.get("chroma"),
        "pixel_um": g.pixel_um, "binning": g.binning,
        "w_px": g.w_px, "h_px": g.h_px, "megapixels": g.megapixels,
        "sensor_w_mm": g.sensor_w_mm, "sensor_h_mm": g.sensor_h_mm, "sensor_diag_mm": g.sensor_diag_mm,
        "focal_mm": g.focal_mm, "f_number": g.f_number, "aperture_mm": g.aperture_mm,
        "fov_h_deg": g.fov_h_deg, "fov_v_deg": g.fov_v_deg, "fov_d_deg": g.fov_d_deg,
        "ifov_urad": g.ifov_rad * 1e6, "ifov_arcsec": math.degrees(g.ifov_rad) * 3600,
        "airy_um": g.airy_um, "airy_px": g.airy_um / g.pixel_um,
        "pixel_100km_m": g.pixel_at_range_m(100.0),
        "deviations": passport_deviations(c),
    }
    if range_km is not None:
        d["pixel_at_range_m"] = g.pixel_at_range_m(range_km)
    return d


def apply_sensor_preset(c, key: str) -> bool:
    s = SENSORS.get(key)
    if not s:
        return False
    c.sensor_preset = key
    c.pixel_um = s["pixel_um"]
    c.sensor_w_px = s["w_px"]
    c.sensor_h_px = s["h_px"]
    return True


def apply_lens_preset(c, key: str) -> bool:
    lens = LENSES.get(key)
    if not lens:
        return False
    c.lens_preset = key
    c.focal_mm = lens["focal_mm"]
    c.f_number = lens["f_number"]
    return True
