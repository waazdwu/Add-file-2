"""Модель камеры (центральная проекция) и физические метрики кадра."""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .astro import R_EARTH, SUN_ANGULAR_RADIUS, eci_to_ecef_matrix, ecef_to_latlon


@dataclass
class Intrinsics:
    """Внутренние параметры pinhole-камеры."""
    width: int = 640
    height: int = 480
    fov_h_deg: float = 60.0

    @property
    def fx(self) -> float:
        return (self.width / 2.0) / math.tan(math.radians(self.fov_h_deg) / 2.0)

    @property
    def fy(self) -> float:
        return self.fx            # квадратные пиксели

    @property
    def cx(self) -> float:
        return (self.width - 1) / 2.0

    @property
    def cy(self) -> float:
        return (self.height - 1) / 2.0

    @property
    def fov_v_deg(self) -> float:
        return math.degrees(2 * math.atan((self.height / 2.0) / self.fy))

    @property
    def K(self) -> np.ndarray:
        return np.array([[self.fx, 0, self.cx], [0, self.fy, self.cy], [0, 0, 1.0]])

    @property
    def ifov_rad(self) -> float:
        """Угловой размер пикселя в центре кадра."""
        return 1.0 / self.fx

    def scaled(self, k: int) -> "Intrinsics":
        """Та же камера (то же поле зрения) с разрешением в k раз меньше — для предпросмотра."""
        if k <= 1:
            return self
        return Intrinsics(max(16, int(round(self.width / k))), max(12, int(round(self.height / k))),
                          self.fov_h_deg)

    def local_rays(self, step: int = 1) -> np.ndarray:
        """Единичные направления лучей в СК камеры, массив (H, W, 3)."""
        xs = (np.arange(0, self.width, step) - self.cx) / self.fx
        ys = (np.arange(0, self.height, step) - self.cy) / self.fy
        X, Y = np.meshgrid(xs, ys)
        d = np.stack([X, Y, np.ones_like(X)], axis=-1)
        return d / np.linalg.norm(d, axis=-1, keepdims=True)

    def project(self, p_cam: np.ndarray) -> np.ndarray:
        """Проекция точек в СК камеры (N,3) в пиксели (N,2); z>0 обязательно."""
        z = p_cam[..., 2:3]
        return np.concatenate([self.fx * p_cam[..., 0:1] / z + self.cx,
                               self.fy * p_cam[..., 1:2] / z + self.cy], axis=-1)


def ray_sphere(o: np.ndarray, d: np.ndarray, c: np.ndarray, r: float) -> float | None:
    """Ближайшее пересечение луча o + t d (|d|=1) со сферой, t>0, иначе None."""
    oc = c - o
    b = float(np.dot(d, oc))
    disc = b * b - (float(np.dot(oc, oc)) - r * r)
    if disc < 0:
        return None
    s = math.sqrt(disc)
    t = b - s
    if t <= 0:
        t = b + s
    return t if t > 0 else None


def camera_metrics(cam_pos: np.ndarray, cam_R: np.ndarray, intr: Intrinsics,
                   sun_pos: np.ndarray, sunlit: float, flux_1au_scaled: float,
                   theta_g: float) -> dict:
    """Набор величин, описывающих, что «видит» камера в данный момент.

    cam_pos — положение камеры, ECI км; cam_R — столбцы осей камеры в ECI.
    """
    bore = cam_R[:, 2]
    to_sun = sun_pos - cam_pos
    sun_dir = to_sun / np.linalg.norm(to_sun)
    cos_sun = float(np.dot(bore, sun_dir))
    ang_sun = math.degrees(math.acos(max(-1.0, min(1.0, cos_sun))))

    # Солнце в кадре: проецируем направление на Солнце
    s_cam = cam_R.T @ sun_dir
    sun_in_fov = False
    sun_px = None
    if s_cam[2] > 0:
        px = intr.project(s_cam[None, :])[0]
        margin = SUN_ANGULAR_RADIUS * intr.fx
        if -margin <= px[0] <= intr.width - 1 + margin and -margin <= px[1] <= intr.height - 1 + margin:
            # не закрыто ли Солнце Землёй
            if ray_sphere(cam_pos, sun_dir, np.zeros(3), R_EARTH) is None:
                sun_in_fov = sunlit > 0
            sun_px = [float(px[0]), float(px[1])]

    # Поток на входной зрачок (по аналогии с исходной версией программы)
    flux = flux_1au_scaled * max(0.0, cos_sun) * sunlit

    nadir = -cam_pos / np.linalg.norm(cam_pos)
    ang_nadir = math.degrees(math.acos(max(-1.0, min(1.0, float(np.dot(bore, nadir))))))

    # Пересечение оси визирования с Землёй
    t = ray_sphere(cam_pos, bore, np.zeros(3), R_EARTH)
    ground = None
    if t is not None:
        p = cam_pos + t * bore
        n = p / np.linalg.norm(p)
        lat, lon = ecef_to_latlon(eci_to_ecef_matrix(theta_g) @ p)
        incidence = math.degrees(math.acos(max(-1.0, min(1.0, float(-np.dot(bore, n))))))
        sun_el = math.degrees(math.asin(max(-1.0, min(1.0, float(np.dot(n, sun_pos - p)
                                                                 / np.linalg.norm(sun_pos - p))))))
        gsd = t * 1000.0 * intr.ifov_rad
        ground = {
            "lat": math.degrees(lat), "lon": math.degrees(lon),
            "range_km": t, "incidence_deg": incidence,
            "gsd_m": gsd, "gsd_oblique_m": gsd / max(math.cos(math.radians(incidence)), 1e-3),
            "sun_elevation_deg": sun_el,
        }

    return {
        "sun_angle_deg": ang_sun,
        "nadir_angle_deg": ang_nadir,
        "sun_in_fov": bool(sun_in_fov),
        "sun_px": sun_px,
        "flux_w_m2": flux,
        "earth_fraction": earth_fraction(cam_pos, cam_R, intr),
        "ground": ground,
    }


_GRID_CACHE: dict = {}


def earth_fraction(cam_pos: np.ndarray, cam_R: np.ndarray, intr: Intrinsics) -> float:
    """Доля кадра, занятая Землёй (оценка по разреженной сетке лучей 48×36)."""
    key = (intr.width, intr.height, round(intr.fov_h_deg, 6))
    if key not in _GRID_CACHE:
        step = max(1, intr.width // 48)
        _GRID_CACHE[key] = intr.local_rays(step).reshape(-1, 3)
    d = _GRID_CACHE[key] @ cam_R.T
    c = -cam_pos
    b = d @ c
    disc = b * b - (c @ c - R_EARTH ** 2)
    hit = (disc >= 0) & (b - np.sqrt(np.maximum(disc, 0)) > 0)
    return float(hit.mean())
