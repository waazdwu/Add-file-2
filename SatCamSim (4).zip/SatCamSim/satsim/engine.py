"""Движок: симуляция + рендер + трансляция, без привязки к интерфейсу.

Используется и веб-интерфейсом, и скриптами (генерация датасетов,
собственные эксперименты с камерой).
"""
from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from . import camera_model
from .config import SimConfig
from .feed import CameraFeed, Frame, Recorder
from .render import Renderer, RenderOptions, ViewCamera, draw_overlays, overview_camera
from .simulation import SimState, Simulation


class Engine:
    def __init__(self, cfg: SimConfig | None = None, allow_download: bool = True,
                 output_dir: str = "output"):
        self.cfg = cfg or SimConfig()
        self.sim = Simulation(self.cfg)
        self.renderer = Renderer(allow_download=allow_download)
        self.feed = CameraFeed()
        self.recorder = Recorder(output_dir)
        self.feed.subscribe(self.recorder.push)
        self.lock = threading.RLock()        # защищает cfg и sim от одновременного изменения
        self._pool = ThreadPoolExecutor(max_workers=2)
        self.frame_index = 0

    # ---- рендер ------------------------------------------------------------
    def camera_options(self) -> RenderOptions:
        c, s = self.cfg.camera, self.cfg.scene
        return RenderOptions(exposure_ev=c.exposure_ev, noise=c.noise, bloom=c.bloom, stars=c.stars,
                             clouds=s.clouds, atmosphere=s.atmosphere, sun_glint=s.sun_glint,
                             surface_detail=s.surface_detail)

    def preview_scale(self) -> int:
        """Во сколько раз уменьшено разрешение кадра в живой трансляции."""
        c = self.cfg.camera
        return max(1, int(c.preview_scale)) if c.optics_mode == "sensor" else 1

    def render_camera(self, st: SimState, opts: RenderOptions | None = None,
                      scale: int = 1) -> tuple[np.ndarray, object]:
        """Кадр камеры. scale > 1 — то же поле зрения в уменьшенном разрешении (предпросмотр)."""
        intr = st.intr.scaled(scale)
        view = ViewCamera(st.cam_pos, st.cam_R, intr, hide_camera_parts=True,
                          show_body=self.cfg.camera.show_own_body)
        return self.renderer.render(view, st, opts or self.camera_options())

    def _frame_meta(self, st: SimState, img: np.ndarray, info) -> dict:
        """Метаданные кадра: внутренние параметры — для реально полученного изображения."""
        meta = self.sim.frame_metadata(st)
        h, w = img.shape[:2]
        k = st.intr.width / w
        meta.update(fx=st.intr.fx / k, fy=st.intr.fy / k, cx=(w - 1) / 2.0, cy=(h - 1) / 2.0,
                    width=w, height=h, image_scale=k,
                    sensor_width=st.intr.width, sensor_height=st.intr.height)
        d = camera_model.derived(self.cfg.camera)
        meta["camera_mode"] = d["mode"]
        if d["mode"] == "sensor":
            meta.update({f"cam_{key}": d[key] for key in (
                "sensor", "pixel_um", "binning", "focal_mm", "f_number", "aperture_mm",
                "fov_h_deg", "fov_v_deg", "ifov_urad", "sensor_w_mm", "sensor_h_mm")})
        meta["render_earth_fraction"] = info.earth_fraction
        meta["render_body_fraction"] = info.body_fraction
        meta["saturated_fraction"] = info.saturated_fraction
        return meta

    def render_overview(self, st: SimState) -> np.ndarray:
        vc = self.cfg.view
        s = self.cfg.scene
        view = overview_camera(vc, st)
        k = max(0.25, min(1.0, vc.render_scale))
        small = view
        if k < 0.999:
            # рендер в уменьшенном разрешении (то же поле зрения), наложения — в полном
            from dataclasses import replace
            small = replace(view, intr=replace(view.intr, width=max(32, int(view.intr.width * k)),
                                                height=max(24, int(view.intr.height * k))))
        opts = RenderOptions(exposure_ev=0.0, bloom=vc.mode == "closeup", glare=False, stars=True,
                             clouds=s.clouds, atmosphere=s.atmosphere, sun_glint=s.sun_glint,
                             surface_detail=s.surface_detail, night_ambient=0.035)
        img, _ = self.renderer.render(small, st, opts)
        if small is not view:
            import cv2
            img = cv2.resize(img, (view.intr.width, view.intr.height), interpolation=cv2.INTER_LINEAR)
        draw_overlays(img, view, st, vc, self.cfg.orbit)
        return img

    # ---- один шаг ----------------------------------------------------------
    def tick(self, dt_real: float, overview: bool = True):
        """Продвинуть время, отрисовать кадры, разослать кадр камеры подписчикам."""
        with self.lock:
            self.sim.step(dt_real)
            st = self.sim.state()
            cam_opts = self.camera_options()
            scale = self.preview_scale()
        f_cam = self._pool.submit(self.render_camera, st, cam_opts, scale)
        f_ov = self._pool.submit(self.render_overview, st) if overview else None
        cam_img, info = f_cam.result()
        ov_img = f_ov.result() if f_ov else None
        meta = self._frame_meta(st, cam_img, info)
        meta["frame_index"] = self.frame_index
        frame = Frame(self.frame_index, cam_img, meta)
        self.frame_index += 1
        self.feed.publish(frame)
        return st, frame, ov_img

    def capture_at(self, t: float, seed: int | None = None, scale: int = 1) -> Frame:
        """Кадр камеры в заданный момент модельного времени (детерминированно;
        seed задаёт реализацию шума матрицы, если шум включён).
        По умолчанию — в полном разрешении матрицы; scale > 1 — уменьшенное."""
        with self.lock:
            st = self.sim.state(t)
            opts = self.camera_options()
        opts.seed = seed
        img, info = self.render_camera(st, opts, scale)
        return Frame(-1, img, self._frame_meta(st, img, info))

    def close(self):
        self.recorder.stop()
        self._pool.shutdown(wait=False)
