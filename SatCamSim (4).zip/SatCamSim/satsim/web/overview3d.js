'use strict';
/* Общий вид сцены на WebGL.
 *
 * Python присылает компактное состояние (/api/scene) ~15 раз в секунду,
 * браузер рисует 60 кадров/с, интерполируя положение и ориентацию между
 * состояниями. Поэтому движение плавное, а вращение/масштаб мышью — мгновенные.
 * Если WebGL недоступен — вызывающий код переключается на картинки с сервера.
 */
const Overview3D = (() => {
  const RE = 6378.137;
  const DEG = Math.PI / 180;

  // ---------- векторы и матрицы (3×3 — массив строк, как в numpy) ----------
  const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const len = a => Math.hypot(a[0], a[1], a[2]);
  const norm = a => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
  const lerp = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
  const mv = (M, v) => [dot(M[0], v), dot(M[1], v), dot(M[2], v)];
  const col = (M, j) => [M[0][j], M[1][j], M[2][j]];
  const mm = (A, B) => [0, 1, 2].map(i => [0, 1, 2].map(j => A[i][0] * B[0][j] + A[i][1] * B[1][j] + A[i][2] * B[2][j]));
  const fromCols = (a, b, c) => [[a[0], b[0], c[0]], [a[1], b[1], c[1]], [a[2], b[2], c[2]]];

  function quatFromMat(m) {
    const t = m[0][0] + m[1][1] + m[2][2];
    let w, x, y, z, s;
    if (t > 0) { s = Math.sqrt(t + 1) * 2; w = s / 4; x = (m[2][1] - m[1][2]) / s; y = (m[0][2] - m[2][0]) / s; z = (m[1][0] - m[0][1]) / s; }
    else if (m[0][0] > m[1][1] && m[0][0] > m[2][2]) { s = Math.sqrt(1 + m[0][0] - m[1][1] - m[2][2]) * 2; w = (m[2][1] - m[1][2]) / s; x = s / 4; y = (m[0][1] + m[1][0]) / s; z = (m[0][2] + m[2][0]) / s; }
    else if (m[1][1] > m[2][2]) { s = Math.sqrt(1 + m[1][1] - m[0][0] - m[2][2]) * 2; w = (m[0][2] - m[2][0]) / s; x = (m[0][1] + m[1][0]) / s; y = s / 4; z = (m[1][2] + m[2][1]) / s; }
    else { s = Math.sqrt(1 + m[2][2] - m[0][0] - m[1][1]) * 2; w = (m[1][0] - m[0][1]) / s; x = (m[0][2] + m[2][0]) / s; y = (m[1][2] + m[2][1]) / s; z = s / 4; }
    return [w, x, y, z];
  }
  function matFromQuat(q) {
    const [w, x, y, z] = q;
    return [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
      [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
      [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]];
  }
  function slerp(a, b, k) {
    let d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
    if (d < 0) { b = b.map(v => -v); d = -d; }
    if (d > 0.9995) { const r = a.map((v, i) => v + (b[i] - v) * k); const l = Math.hypot(...r); return r.map(v => v / l); }
    const th = Math.acos(d), s = Math.sin(th);
    const ka = Math.sin((1 - k) * th) / s, kb = Math.sin(k * th) / s;
    return a.map((v, i) => v * ka + b[i] * kb);
  }

  // ---------- WebGL ----------
  let gl, canvas, lines, ctx2d;
  let progEarth, progAtm, progPart, progStar, progSun;
  let meshSphere, meshCube, meshDisk, starBuf, starCount = 0;
  let texDay = null, texClouds = null;
  let ready = false;

  function shader(type, src) {
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('Шейдер: ' + gl.getShaderInfoLog(s));
    return s;
  }
  function program(vs, fs) {
    const p = gl.createProgram();
    gl.attachShader(p, shader(gl.VERTEX_SHADER, vs));
    gl.attachShader(p, shader(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Программа: ' + gl.getProgramInfoLog(p));
    const u = {}, a = {};
    const nu = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < nu; i++) { const n = gl.getActiveUniform(p, i).name; u[n] = gl.getUniformLocation(p, n); }
    const na = gl.getProgramParameter(p, gl.ACTIVE_ATTRIBUTES);
    for (let i = 0; i < na; i++) { const n = gl.getActiveAttrib(p, i).name; a[n] = gl.getAttribLocation(p, n); }
    return { p, u, a };
  }
  // выключить все массивы атрибутов перед сменой программы (чтобы не тянуть чужие указатели)
  let maxAttr = 8;
  function use(P) {
    for (let i = 0; i < maxAttr; i++) gl.disableVertexAttribArray(i);
    gl.useProgram(P.p);
  }
  function buffer(data, target = gl.ARRAY_BUFFER) {
    const b = gl.createBuffer();
    gl.bindBuffer(target, b);
    gl.bufferData(target, data, gl.STATIC_DRAW);
    return b;
  }

  const GAMMA = 'vec3 toSRGB(vec3 c){ return pow(clamp(c, 0.0, 1.0), vec3(1.0/2.2)); }\n';

  const VS_EARTH = `
attribute vec3 aPos; attribute vec2 aUV;
uniform mat4 uVP; uniform mat3 uRot; uniform vec3 uCenter; uniform float uR;
varying vec3 vN; varying vec2 vUV; varying vec3 vP;
void main(){ vec3 n = uRot * aPos; vN = n; vUV = aUV; vP = uCenter + n * uR; gl_Position = uVP * vec4(vP, 1.0); }`;
  const FS_EARTH = `precision highp float;
uniform sampler2D uDay; uniform sampler2D uClouds; uniform vec3 uSun;
uniform float uNight; uniform float uCloudsOn; uniform float uAtmOn; uniform float uHasTex;
varying vec3 vN; varying vec2 vUV; varying vec3 vP;
${GAMMA}
void main(){
  vec3 n = normalize(vN);
  vec3 albedo = uHasTex > 0.5 ? pow(texture2D(uDay, vUV).rgb, vec3(2.2)) : vec3(0.05, 0.12, 0.30);
  float ndl = dot(n, uSun);
  float light = clamp(ndl, 0.0, 1.0);
  float tw = clamp((ndl + 0.1) / 0.1, 0.0, 1.0) * 0.015;
  vec3 col = albedo * (light + tw + uNight) * 1.35;
  float a = uHasTex > 0.5 ? texture2D(uClouds, vUV).r * uCloudsOn : 0.0;
  col = mix(col, vec3(light * 0.95 + tw * 2.0 + uNight * 0.7), a);
  vec3 vd = normalize(-vP);
  float mu = clamp(dot(vd, n), 0.0, 1.0);
  float haze = (pow(1.0 - mu, 4.0) * 0.6 + 0.012) * clamp(ndl + 0.15, 0.0, 1.0) * uAtmOn;
  col = col * (1.0 - 0.25 * pow(1.0 - mu, 2.0) * uAtmOn) + haze * vec3(0.30, 0.52, 1.0);
  gl_FragColor = vec4(toSRGB(col), 1.0);
}`;
  const FS_ATM = `precision highp float;
uniform vec3 uSun; varying vec3 vN; varying vec2 vUV; varying vec3 vP;
void main(){
  vec3 n = normalize(vN); vec3 vd = normalize(-vP);
  float d = clamp(-dot(n, vd), 0.0, 1.0);            // задние грани оболочки
  float k = smoothstep(0.0, 0.32, d) * (1.0 - smoothstep(0.32, 0.55, d));
  float lit = clamp(dot(n, uSun) + 0.25, 0.0, 1.0);
  gl_FragColor = vec4(vec3(0.30, 0.52, 1.0) * k * lit * 0.9, 1.0);
}`;
  const VS_PART = `
attribute vec3 aPos; attribute vec3 aNrm;
uniform mat4 uVP; uniform mat3 uRw; uniform vec3 uC; uniform vec3 uH; uniform vec3 uHm;
varying vec3 vN; varying vec3 vP; varying vec3 vLm; varying float vFront;
void main(){ vec3 lp = aPos * uH; vec3 p = uC + uRw * lp; vN = uRw * aNrm; vP = p; vLm = aPos * uHm; vFront = aNrm.z;
  gl_Position = uVP * vec4(p, 1.0); }`;
  const FS_PART = `precision highp float;
uniform vec3 uColor; uniform float uSpec; uniform float uShin; uniform float uCells;
uniform float uSunlit; uniform float uEarthLit; uniform vec3 uSun; uniform vec3 uNadir;
varying vec3 vN; varying vec3 vP; varying vec3 vLm; varying float vFront;
${GAMMA}
void main(){
  vec3 n = normalize(vN); if (!gl_FrontFacing) n = -n;
  vec3 base = uColor;
  if (uCells > 0.5) {
    if (vFront > 0.5) {
      vec2 g = abs(fract(vLm.xy / 0.11) - 0.5);
      if (max(g.x, g.y) > 0.44) base = vec3(0.55, 0.57, 0.62);
    } else if (vFront < -0.5) base = vec3(0.70);
  }
  float ndl = max(dot(n, uSun), 0.0) * uSunlit;
  float es = max(dot(n, uNadir), 0.0) * 0.22 * uEarthLit;
  vec3 h = normalize(uSun + normalize(-vP));
  float sp = uSpec * pow(max(dot(n, h), 0.0), uShin) * step(0.0001, ndl);
  vec3 col = base * (ndl + es + 0.06) + sp * 1.4;
  gl_FragColor = vec4(toSRGB(col), 1.0);
}`;
  const VS_STAR = `
attribute vec3 aDir; attribute float aB; uniform mat4 uVP; uniform float uDpr; varying float vB;
void main(){ vec4 p = uVP * vec4(aDir, 0.0); p.z = p.w * 0.99999; gl_Position = p; vB = aB; gl_PointSize = (aB > 0.6 ? 2.0 : 1.0) * uDpr; }`;
  const FS_STAR = `precision mediump float; varying float vB;
void main(){ gl_FragColor = vec4(vec3(0.85, 0.9, 1.0) * vB, 1.0); }`;
  const VS_SUN = `
attribute vec3 aDir; uniform mat4 uVP; uniform float uSize;
void main(){ vec4 p = uVP * vec4(aDir, 0.0); p.z = p.w * 0.99998; gl_Position = p; gl_PointSize = uSize; }`;
  const FS_SUN = `precision mediump float; uniform float uVis;
void main(){ vec2 c = gl_PointCoord - 0.5; float r = length(c) * 2.0;
  float core = 1.0 - smoothstep(0.10, 0.16, r);
  float glow = pow(max(1.0 - r, 0.0), 3.0) * 0.8;
  gl_FragColor = vec4(vec3(1.0, 0.95, 0.80) * (core + glow) * uVis, 1.0); }`;

  // ---------- геометрия ----------
  function makeSphere(nLat, nLon) {
    const pos = [], uv = [], idx = [];
    for (let i = 0; i <= nLat; i++) {
      const v = i / nLat, lat = Math.PI / 2 - v * Math.PI;
      for (let j = 0; j <= nLon; j++) {
        const u = j / nLon, lon = u * 2 * Math.PI - Math.PI;
        pos.push(Math.cos(lat) * Math.cos(lon), Math.cos(lat) * Math.sin(lon), Math.sin(lat));
        uv.push(u, v);
      }
    }
    for (let i = 0; i < nLat; i++) for (let j = 0; j < nLon; j++) {
      const a = i * (nLon + 1) + j, b = a + nLon + 1;
      idx.push(a, b, a + 1, a + 1, b, b + 1);
    }
    return { pos: buffer(new Float32Array(pos)), uv: buffer(new Float32Array(uv)),
      idx: buffer(new Uint16Array(idx), gl.ELEMENT_ARRAY_BUFFER), n: idx.length };
  }
  function makeCube() {
    const P = [], N = [], I = [];
    const faces = [[0, 1], [0, -1], [1, 1], [1, -1], [2, 1], [2, -1]];
    for (const [ax, sg] of faces) {
      const u = (ax + 1) % 3, v = (ax + 2) % 3, base = P.length / 3;
      for (const [a, b] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
        const p = [0, 0, 0], n = [0, 0, 0];
        p[ax] = sg; p[u] = a; p[v] = b * sg; n[ax] = sg;
        P.push(...p); N.push(...n);
      }
      I.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
    return { pos: buffer(new Float32Array(P)), nrm: buffer(new Float32Array(N)),
      idx: buffer(new Uint16Array(I), gl.ELEMENT_ARRAY_BUFFER), n: I.length };
  }
  function makeDisk(seg) {
    const P = [0, 0, 0], N = [0, 0, 1], I = [];
    for (let i = 0; i <= seg; i++) { const a = i / seg * 2 * Math.PI; P.push(Math.cos(a), Math.sin(a), 0); N.push(0, 0, 1); }
    for (let i = 1; i <= seg; i++) I.push(0, i, i + 1);
    return { pos: buffer(new Float32Array(P)), nrm: buffer(new Float32Array(N)),
      idx: buffer(new Uint16Array(I), gl.ELEMENT_ARRAY_BUFFER), n: I.length };
  }
  function makeStars(n) {
    let seed = 7;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    const d = [];
    for (let i = 0; i < n; i++) {
      const z = rnd() * 2 - 1, a = rnd() * 2 * Math.PI, r = Math.sqrt(1 - z * z);
      d.push(r * Math.cos(a), r * Math.sin(a), z, Math.pow(rnd(), 3) * 0.9 + 0.08);
    }
    starCount = n;
    return buffer(new Float32Array(d));
  }
  function loadTexture(url, cb) {
    const img = new Image();
    img.onload = () => {
      const t = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, img);
      gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      const ext = gl.getExtension('EXT_texture_filter_anisotropic');
      if (ext) gl.texParameterf(gl.TEXTURE_2D, ext.TEXTURE_MAX_ANISOTROPY_EXT, 8);
      cb(t);
    };
    img.src = url;
  }

  function init(glCanvas, lineCanvas) {
    canvas = glCanvas; lines = lineCanvas;
    gl = canvas.getContext('webgl', { antialias: true, alpha: false });
    if (!gl) return false;
    ctx2d = lines.getContext('2d');
    maxAttr = Math.min(16, gl.getParameter(gl.MAX_VERTEX_ATTRIBS));
    progEarth = program(VS_EARTH, FS_EARTH);
    progAtm = program(VS_EARTH, FS_ATM);
    progPart = program(VS_PART, FS_PART);
    progStar = program(VS_STAR, FS_STAR);
    progSun = program(VS_SUN, FS_SUN);
    meshSphere = makeSphere(64, 128);
    meshCube = makeCube();
    meshDisk = makeDisk(40);
    starBuf = makeStars(3500);
    loadTexture('/api/texture/earth.jpg', t => { texDay = t; });
    loadTexture('/api/texture/clouds.jpg', t => { texClouds = t; });
    ready = true;
    return true;
  }

  // ---------- состояние и интерполяция ----------
  const snaps = [];            // буфер состояний {t, r, v, q, sunE, gmst, ...}
  let latest = null, recvWall = 0;
  const DELAY = 0.18;          // с — задержка отображения ради плавной интерполяции

  function pushScene(sc) {
    const s = { t: sc.t, r: sc.r, v: sc.v, q: quatFromMat(sc.Rb), sunE: sc.sunE, gmst: sc.gmst,
      sunlit: sc.sunlit, raw: sc };
    const last = snaps[snaps.length - 1];
    // скачок времени (перемотка, «→ тень») — начинаем буфер заново
    if (last && (s.t < last.t - 1e-6 || s.t - last.t > Math.max(30, 4 * Math.max(sc.scale, 1)))) snaps.length = 0;
    if (!last || s.t !== last.t || snaps.length === 0) snaps.push(s);
    while (snaps.length > 40) snaps.shift();
    latest = sc;
    recvWall = performance.now();
  }

  function sampleState() {
    if (!latest || !snaps.length) return null;
    const scale = latest.paused ? 0 : latest.scale;
    let tr = latest.t + ((performance.now() - recvWall) / 1000 - DELAY) * scale;
    const first = snaps[0], last = snaps[snaps.length - 1];
    if (tr <= first.t || snaps.length === 1) tr = Math.max(tr, first.t);
    let a = first, b = first, k = 0;
    if (tr >= last.t) {
      // нет свежего состояния — продолжаем движение по последним двум (не дальше 1.5 интервала)
      if (snaps.length >= 2) {
        a = snaps[snaps.length - 2]; b = last;
        k = Math.min((tr - a.t) / Math.max(b.t - a.t, 1e-9), 1.5);
      } else { a = b = last; }
    } else {
      for (let i = 0; i < snaps.length - 1; i++) {
        if (snaps[i].t <= tr && tr <= snaps[i + 1].t) {
          a = snaps[i]; b = snaps[i + 1]; k = (tr - a.t) / Math.max(b.t - a.t, 1e-9); break;
        }
      }
    }
    const rl = len(a.r) + (len(b.r) - len(a.r)) * k;
    const r = mul(norm(lerp(a.r, b.r, k)), rl);
    let dg = b.gmst - a.gmst;
    if (dg > Math.PI) dg -= 2 * Math.PI; else if (dg < -Math.PI) dg += 2 * Math.PI;
    return {
      t: a.t + (b.t - a.t) * k, r, v: lerp(a.v, b.v, k), Rb: matFromQuat(slerp(a.q, b.q, Math.min(k, 1))),
      sunE: norm(lerp(a.sunE, b.sunE, k)), gmst: a.gmst + dg * k, sunlit: k < 0.5 ? a.sunlit : b.sunlit,
      raw: latest,
    };
  }

  // ---------- камера наблюдателя (как overview_camera в Python) ----------
  function lookAt(eye, target, up) {
    const f = norm(sub(target, eye));
    let r = cross(f, up);
    if (len(r) < 1e-9) r = cross(f, Math.abs(f[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0]);
    r = norm(r);
    const d = cross(f, r);
    return fromCols(r, d, f);       // столбцы: вправо, вниз, вперёд
  }
  function viewCamera(vc, s) {
    const az = vc.azimuth_deg * DEG, el = vc.elevation_deg * DEG;
    if (vc.mode === 'closeup') {
      const B = s.Rb;
      const dir = add(add(mul(col(B, 0), Math.cos(el) * Math.cos(az)), mul(col(B, 1), Math.cos(el) * Math.sin(az))), mul(col(B, 2), -Math.sin(el)));
      const eye = add(s.r, mul(dir, vc.distance_m / 1000));
      return { eye, R: lookAt(eye, s.r, mul(col(B, 2), -1)), fov: 50, scale: 1, dist: vc.distance_m / 1000, mode: 'closeup' };
    }
    let eye, R, fov, frac, dist;
    if (vc.mode === 'follow') {
      const up = norm(s.r);
      const fwd = norm(sub(s.v, mul(up, dot(s.v, up))));
      const side = cross(up, fwd);
      const dir = add(mul(add(mul(fwd, -Math.cos(az)), mul(side, Math.sin(az))), Math.cos(el)), mul(up, Math.sin(el)));
      dist = vc.follow_distance_km;
      eye = add(s.r, mul(dir, dist));
      R = lookAt(eye, s.r, up); fov = 45; frac = 0.10;
    } else {
      const h = norm(cross(s.r, s.v));
      let node = cross([0, 0, 1], h);
      node = len(node) > 1e-6 ? norm(node) : [1, 0, 0];
      const e1 = cross(h, node);
      const dir = add(add(mul(node, Math.cos(el) * Math.cos(az)), mul(e1, Math.cos(el) * Math.sin(az))), mul(h, Math.sin(el)));
      dist = vc.distance_km;
      eye = mul(dir, dist);
      R = lookAt(eye, [0, 0, 0], Math.abs(Math.sin(el)) < 0.98 ? h : e1); fov = 40; frac = 0.035;
    }
    const want = frac * 2 * dist * Math.tan(fov / 2 * DEG) * 1000;
    return { eye, R, fov, scale: Math.max(1, want / 5.6) * vc.sat_scale, dist, mode: vc.mode };
  }

  // GL-матрица «проекция × поворот вида» (наблюдатель в начале координат)
  function viewProj(R, fovH, aspect, near, far) {
    const fy = 1 / Math.tan(fovH / 2 * DEG) * aspect;   // fovH — горизонтальный
    const fx = 1 / Math.tan(fovH / 2 * DEG);
    // строки вида: x = вправо, y = -вниз (вверх), z = -вперёд
    const rx = col(R, 0), ry = mul(col(R, 1), -1), rz = mul(col(R, 2), -1);
    const A = -(far + near) / (far - near), Bz = -2 * far * near / (far - near);
    // P*V, столбцовый порядок для uniformMatrix4fv
    const m = new Float32Array(16);
    for (let j = 0; j < 3; j++) {
      m[j * 4 + 0] = fx * rx[j];
      m[j * 4 + 1] = fy * ry[j];
      m[j * 4 + 2] = A * rz[j];
      m[j * 4 + 3] = -rz[j];
    }
    m[12] = 0; m[13] = 0; m[14] = Bz; m[15] = 0;
    return m;
  }
  const m3 = M => new Float32Array([M[0][0], M[1][0], M[2][0], M[0][1], M[1][1], M[2][1], M[0][2], M[1][2], M[2][2]]);

  // ---------- отрисовка ----------
  function drawEarth(vp, cam, s, opts) {
    const P = progEarth;
    use(P);
    gl.uniformMatrix4fv(P.u.uVP, false, vp);
    const c = Math.cos(s.gmst), sn = Math.sin(s.gmst);
    gl.uniformMatrix3fv(P.u.uRot, false, m3([[c, -sn, 0], [sn, c, 0], [0, 0, 1]]));
    gl.uniform3fv(P.u.uCenter, mul(cam.eye, -1));
    gl.uniform1f(P.u.uR, RE);
    gl.uniform3fv(P.u.uSun, s.sunE);
    gl.uniform1f(P.u.uNight, 0.035);
    gl.uniform1f(P.u.uCloudsOn, opts.clouds ? 1 : 0);
    gl.uniform1f(P.u.uAtmOn, opts.atmosphere ? 1 : 0);
    gl.uniform1f(P.u.uHasTex, texDay && texClouds ? 1 : 0);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texDay);
    gl.uniform1i(P.u.uDay, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, texClouds);
    gl.uniform1i(P.u.uClouds, 1);
    bindSphere(P);
    gl.drawElements(gl.TRIANGLES, meshSphere.n, gl.UNSIGNED_SHORT, 0);
    if (opts.atmosphere) {
      const A = progAtm;
      use(A);
      gl.uniformMatrix4fv(A.u.uVP, false, vp);
      gl.uniformMatrix3fv(A.u.uRot, false, m3([[1, 0, 0], [0, 1, 0], [0, 0, 1]]));
      gl.uniform3fv(A.u.uCenter, mul(cam.eye, -1));
      gl.uniform1f(A.u.uR, RE * 1.025);
      gl.uniform3fv(A.u.uSun, s.sunE);
      bindSphere(A);
      gl.enable(gl.CULL_FACE); gl.cullFace(gl.FRONT);
      gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE); gl.depthMask(false);
      gl.drawElements(gl.TRIANGLES, meshSphere.n, gl.UNSIGNED_SHORT, 0);
      gl.disable(gl.BLEND); gl.depthMask(true); gl.disable(gl.CULL_FACE);
    }
  }
  function bindSphere(P) {
    gl.bindBuffer(gl.ARRAY_BUFFER, meshSphere.pos);
    gl.enableVertexAttribArray(P.a.aPos); gl.vertexAttribPointer(P.a.aPos, 3, gl.FLOAT, false, 0, 0);
    if (P.a.aUV !== undefined) {
      gl.bindBuffer(gl.ARRAY_BUFFER, meshSphere.uv);
      gl.enableVertexAttribArray(P.a.aUV); gl.vertexAttribPointer(P.a.aUV, 2, gl.FLOAT, false, 0, 0);
    }
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, meshSphere.idx);
  }
  function drawParts(vp, cam, s) {
    const P = progPart;
    use(P);
    gl.uniformMatrix4fv(P.u.uVP, false, vp);
    const sunDir = s.sunE;
    gl.uniform3fv(P.u.uSun, sunDir);
    gl.uniform3fv(P.u.uNadir, mul(norm(s.r), -1));
    gl.uniform1f(P.u.uSunlit, s.sunlit);
    gl.uniform1f(P.u.uEarthLit, Math.min(1, Math.max(0, 0.5 + 0.5 * dot(norm(s.r), s.sunE))));
    const rel = sub(s.r, cam.eye);
    for (const p of s.raw.parts) {
      const mesh = p.k === 'box' ? meshCube : meshDisk;
      const Rw = mm(s.Rb, p.R);
      const c = add(rel, mul(mv(s.Rb, p.c), cam.scale / 1000));
      const hk = p.k === 'box' ? p.h : [p.h[0], p.h[0], 1e-6];
      gl.uniformMatrix3fv(P.u.uRw, false, m3(Rw));
      gl.uniform3fv(P.u.uC, c);
      gl.uniform3fv(P.u.uH, mul(hk, cam.scale / 1000));
      gl.uniform3fv(P.u.uHm, hk);
      gl.uniform3fv(P.u.uColor, p.col);
      gl.uniform1f(P.u.uSpec, p.sp);
      gl.uniform1f(P.u.uShin, p.sh);
      gl.uniform1f(P.u.uCells, p.cells ? 1 : 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.pos);
      gl.enableVertexAttribArray(P.a.aPos); gl.vertexAttribPointer(P.a.aPos, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.nrm);
      gl.enableVertexAttribArray(P.a.aNrm); gl.vertexAttribPointer(P.a.aNrm, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.idx);
      gl.drawElements(gl.TRIANGLES, mesh.n, gl.UNSIGNED_SHORT, 0);
    }
  }
  function drawSky(vp, cam, s, dpr) {
    const P = progStar;
    use(P);
    gl.uniformMatrix4fv(P.u.uVP, false, vp);
    gl.uniform1f(P.u.uDpr, Math.max(1, dpr * 0.8));
    gl.bindBuffer(gl.ARRAY_BUFFER, starBuf);
    gl.enableVertexAttribArray(P.a.aDir); gl.vertexAttribPointer(P.a.aDir, 3, gl.FLOAT, false, 16, 0);
    gl.enableVertexAttribArray(P.a.aB); gl.vertexAttribPointer(P.a.aB, 1, gl.FLOAT, false, 16, 12);
    gl.drawArrays(gl.POINTS, 0, starCount);
    gl.disableVertexAttribArray(P.a.aB);
  }
  let sunBuf = null;
  function drawSun(vp, cam, s, dpr) {
    const P = progSun;
    use(P);
    if (!sunBuf) sunBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, sunBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(s.sunE), gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(P.a.aDir); gl.vertexAttribPointer(P.a.aDir, 3, gl.FLOAT, false, 0, 0);
    gl.uniformMatrix4fv(P.u.uVP, false, vp);
    gl.uniform1f(P.u.uSize, Math.min(gl.getParameter(gl.ALIASED_POINT_SIZE_RANGE)[1], 70 * dpr));
    // Солнце, закрытое Землёй, не рисуем (простая проверка луча)
    const vis = hitsEarth(cam.eye, s.sunE) ? 0 : 1;
    gl.uniform1f(P.u.uVis, vis);
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE);
    gl.drawArrays(gl.POINTS, 0, 1);
    gl.disable(gl.BLEND);
  }
  function hitsEarth(o, d) {
    const b = -dot(o, d), c = dot(o, o) - RE * RE, disc = b * b - c;
    return disc > 0 && b - Math.sqrt(disc) > 0;
  }

  // ---------- 2D-наложения (линии с учётом заслонения Землёй) ----------
  function drawOverlays(cam, s, vc, W, H) {
    const g = ctx2d;
    g.clearRect(0, 0, W, H);
    const f = (W / 2) / Math.tan(cam.fov / 2 * DEG);
    const proj = P => {
      const rel = sub(P, cam.eye);
      const pc = [dot(col(cam.R, 0), rel), dot(col(cam.R, 1), rel), dot(col(cam.R, 2), rel)];
      if (pc[2] <= 1e-9) return null;
      const L = len(rel), d = mul(rel, 1 / L);
      const b = -dot(cam.eye, d), c = dot(cam.eye, cam.eye) - RE * RE, disc = b * b - c;
      const hidden = disc > 0 && b - Math.sqrt(disc) > 0 && b - Math.sqrt(disc) < L - 1;
      return [W / 2 + f * pc[0] / pc[2], H / 2 + f * pc[1] / pc[2], hidden];
    };
    const poly = (pts, color, width, hiddenColor, closed) => {
      const pp = pts.map(proj);
      const n = closed ? pp.length : pp.length - 1;
      g.lineCap = 'round';
      for (let i = 0; i < n; i++) {
        const a = pp[i], b = pp[(i + 1) % pp.length];
        if (!a || !b) continue;
        const hid = a[2] || b[2];
        if (hid && !hiddenColor) continue;
        g.strokeStyle = hid ? hiddenColor : color;
        g.lineWidth = hid ? 1 : width;
        g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke();
      }
      return pp;
    };
    const raw = s.raw;
    const closeup = vc.mode === 'closeup';
    if (vc.show_orbit && raw.orbit && !closeup) poly(raw.orbit, '#5adcff', 2, 'rgba(70,140,170,.55)');
    if (vc.show_ground_track && raw.track && !closeup) poly(raw.track, '#ffaa3c', 2, null);

    // камера на КА (интерполированная ориентация)
    const camPos = add(s.r, mul(mv(s.Rb, raw.camPosB), 1 / 1000));
    const camR = mm(s.Rb, raw.camRB);
    if (vc.show_footprint) {
      const fp = footprint(camPos, camR, raw.fov, raw.aspect);
      if (fp) {
        poly(fp, '#78ff78', 2, null, true);
        if (!closeup) for (const k of [0, 16, 32, 48]) poly([camPos, fp[k]], 'rgba(120,255,120,.7)', 1, null);
      }
    }
    if (vc.show_vectors) {
      const items = [];
      if (closeup) {
        const L = 2.5 / 1000;
        items.push([camPos, mul(col(camR, 2), 6 * L), '#ff50dc'], [s.r, mul(s.sunE, 1.4 * L), '#ffdc3c'],
          [s.r, mul(norm(s.r), -1.4 * L), '#5adcff']);
      } else {
        items.push([[0, 0, 0], mul(s.sunE, RE * 1.9), '#ffdc3c'],
          [camPos, mul(col(camR, 2), raw.range || 3000), '#ff50dc'],
          [s.r, mul(norm(s.v), RE * 0.25), '#dcdcdc']);
      }
      for (const [p0, vec, color] of items) {
        const pp = poly([p0, add(p0, vec)], color, 2, null);
        const e = pp[1];
        if (e && !e[2]) { g.fillStyle = color; g.beginPath(); g.arc(e[0], e[1], 3, 0, 2 * Math.PI); g.fill(); }
      }
    }
    if (!closeup) {
      const p = proj(s.r);
      if (p) {
        g.strokeStyle = p[2] ? 'rgba(130,130,150,.8)' : '#fff'; g.lineWidth = 1;
        g.beginPath(); g.arc(p[0], p[1], 16, 0, 2 * Math.PI); g.stroke();
        g.beginPath(); g.moveTo(p[0] + 12, p[1] - 12); g.lineTo(p[0] + 24, p[1] - 24); g.stroke();
      }
    }
  }
  function footprint(camPos, camR, fov, aspect) {
    const tx = Math.tan(fov / 2 * DEG), ty = tx / aspect;
    const border = [];
    const n = 16;
    for (let i = 0; i < n; i++) border.push([-tx + 2 * tx * i / n, -ty]);
    for (let i = 0; i < n; i++) border.push([tx, -ty + 2 * ty * i / n]);
    for (let i = 0; i < n; i++) border.push([tx - 2 * tx * i / n, ty]);
    for (let i = 0; i < n; i++) border.push([-tx, ty - 2 * ty * i / n]);
    let hits = 0;
    const tH = Math.sqrt(Math.max(dot(camPos, camPos) - RE * RE, 0));
    const pts = border.map(([x, y]) => {
      const d = norm(add(add(mul(col(camR, 0), x), mul(col(camR, 1), y)), col(camR, 2)));
      const b = -dot(camPos, d), disc = b * b - (dot(camPos, camPos) - RE * RE);
      let t = tH;
      if (disc > 0 && b > 0) { t = b - Math.sqrt(disc); hits++; }
      const P = add(camPos, mul(d, t));
      return mul(norm(P), RE * 1.0015);
    });
    return hits >= 3 ? pts : null;
  }

  // ---------- главный цикл ----------
  let vcRef = null, sceneOpts = { clouds: true, atmosphere: true };
  let frames = 0, fpsT = performance.now(), fps = 0;

  function frame() {
    requestAnimationFrame(frame);
    if (!ready || !vcRef) return;
    const s = sampleState();
    const dpr = window.devicePixelRatio || 1;
    const W = canvas.clientWidth, H = canvas.clientHeight;
    if (!W || !H) return;
    if (canvas.width !== Math.round(W * dpr) || canvas.height !== Math.round(H * dpr)) {
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
      lines.width = canvas.width; lines.height = canvas.height;
    }
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    if (!s) return;
    const cam = viewCamera(vcRef, s);
    const aspect = W / H;
    gl.enable(gl.DEPTH_TEST);

    if (cam.mode === 'closeup') {
      // Земля и аппарат — в разных диапазонах глубины (км и метры)
      const vpFar = viewProj(cam.R, cam.fov, aspect, 10, 4e5);
      drawSky(vpFar, cam, s, dpr);
      drawEarth(vpFar, cam, s, sceneOpts);
      drawSun(vpFar, cam, s, dpr);
      gl.clear(gl.DEPTH_BUFFER_BIT);
      drawParts(viewProj(cam.R, cam.fov, aspect, 0.0005, 2), cam, s);
    } else {
      const dEye = len(cam.eye);
      const near = Math.max(1, Math.min(cam.dist * 0.05, dEye - RE * 1.05));
      const vp = viewProj(cam.R, cam.fov, aspect, near, dEye + RE * 2);
      drawSky(vp, cam, s, dpr);
      drawEarth(vp, cam, s, sceneOpts);
      drawSun(vp, cam, s, dpr);
      drawParts(vp, cam, s);
    }
    ctx2d.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawOverlays(cam, s, vcRef, W, H);

    frames++;
    const now = performance.now();
    if (now - fpsT > 1000) { fps = frames * 1000 / (now - fpsT); frames = 0; fpsT = now; }
  }

  return {
    init(glCanvas, lineCanvas) {
      const ok = init(glCanvas, lineCanvas);
      if (ok) requestAnimationFrame(frame);
      return ok;
    },
    pushScene,
    setView(vc, scene) { vcRef = vc; if (scene) sceneOpts = scene; },
    get fps() { return fps; },
  };
})();
