'use strict';
/* SatCamSim — клиентская часть интерфейса (без внешних библиотек). */

/* Любая ошибка в браузере — сразу на экран, а не только в консоль F12 */
function showFatal(msg) {
  let b = document.getElementById('errBanner');
  if (!b) {
    b = document.createElement('div');
    b.id = 'errBanner';
    b.style.cssText = 'position:fixed;left:12px;right:12px;bottom:12px;z-index:99;background:#5a0f1a;'
      + 'border:1px solid #ff5a6a;color:#fff;padding:10px 14px;border-radius:8px;font:12px/1.4 monospace;'
      + 'white-space:pre-wrap;max-height:40vh;overflow:auto';
    document.body.appendChild(b);
  }
  b.textContent += (b.textContent ? '\n' : '') + msg;
}
window.addEventListener('error', e => showFatal('Ошибка в браузере: ' + e.message + ' (' + (e.filename || '') + ':' + (e.lineno || '') + ')'));
window.addEventListener('unhandledrejection', e => showFatal('Ошибка в браузере: ' + (e.reason && (e.reason.stack || e.reason.message) || e.reason)));

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const sleep = ms => new Promise(r => setTimeout(r, ms));

let CFG = null;        // текущие параметры (зеркало сервера)
let SCHEMA = null;     // списки режимов
let TEL = {};          // телеметрия
let STATE = {};
let activeTab = 'camera';
const controls = [];   // зарегистрированные элементы управления
const lastEdit = {};   // ключ → время последней правки пользователем

let connOk = null;
function setConn(ok, why) {
  if (ok === connOk) return;
  connOk = ok;
  const c = document.getElementById('chipConn');
  if (!c) return;
  c.textContent = ok ? 'связь: есть' : 'нет связи с программой';
  c.className = 'chip ' + (ok ? 'conn-ok' : 'conn-bad');
  c.title = why || '';
}
const api = {
  get: url => fetch(url, { cache: 'no-store' }).then(r => { if (!r.ok) throw new Error(url + ' → HTTP ' + r.status); return r.json(); }),
  post: (url, body) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body) }).then(r => r.json()).catch(e => { setConn(false, String(e)); toast('Команда не дошла до программы: ' + e.message); return {}; }),
};
const getKey = (o, k) => k.split('.').reduce((a, p) => (a == null ? a : a[p]), o);
const setKey = (o, k, v) => { const p = k.split('.'); const last = p.pop(); p.reduce((a, x) => a[x], o)[last] = v; };

/* ---------- отправка параметров (с объединением частых изменений) ---------- */
const pending = {};
let flushTimer = null;
function setParam(key, value) {
  pending[key] = value;
  lastEdit[key] = performance.now();
  if (CFG) setKey(CFG, key, value);
  if (!flushTimer) flushTimer = setTimeout(flushParams, 50);
}
function flushParams() {
  const body = { ...pending };
  for (const k in pending) delete pending[k];
  flushTimer = null;
  api.post('/api/params', body);
}
async function action(name, extra = {}) {
  const r = await api.post('/api/action', { action: name, ...extra });
  if (r && r.message) toast(r.message);
  return r;
}
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 4200);
}

/* ---------- конструктор элементов управления ---------- */
function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== undefined && v !== null) e.setAttribute(k, v);
  }
  for (const k of kids.flat()) if (k != null) e.append(k.nodeType ? k : document.createTextNode(k));
  return e;
}
const title = t => el('div', { class: 'group-title' }, t);
const note = html => { const n = el('div', { class: 'note' }); n.innerHTML = html; return n; };

function range(key, label, min, max, step, digits = 1, opt = {}) {
  const r = el('input', { type: 'range', min, max, step });
  const num = el('input', { type: 'number', step, min: opt.numMin ?? min, max: opt.numMax ?? max });
  const row = el('div', { class: 'row' }, el('label', { class: 'name' }, label), r, num);
  const send = v => { setParam(key, v); };
  r.addEventListener('input', () => { num.value = (+r.value).toFixed(digits); send(+r.value); });
  num.addEventListener('change', () => { r.value = num.value; send(+num.value); });
  controls.push({ key, row, kind: 'range', set: v => { r.value = v; num.value = (+v).toFixed(digits); },
    inputs: [r, num], opt, digits });
  return row;
}
function number(key, label, min, max, step) {
  const num = el('input', { type: 'number', min, max, step });
  const row = el('div', { class: 'row wide' }, el('label', { class: 'name' }, label), num);
  num.addEventListener('change', () => setParam(key, +num.value));
  controls.push({ key, row, kind: 'number', set: v => { num.value = v; }, inputs: [num] });
  return row;
}
function select(key, label, options) {
  const s = el('select');
  const opts = typeof options === 'function' ? options() : options;
  for (const [v, t] of Object.entries(opts)) s.append(el('option', { value: v }, t));
  const row = el('div', { class: 'row wide' }, el('label', { class: 'name' }, label), s);
  s.addEventListener('change', () => { setParam(key, s.value); render(); });
  controls.push({ key, row, kind: 'select', set: v => { s.value = v; }, inputs: [s] });
  return row;
}
function checks(list) {
  const box = el('div', { class: 'checks' });
  for (const [key, label] of list) {
    const c = el('input', { type: 'checkbox' });
    c.addEventListener('change', () => { setParam(key, c.checked); render(); });
    controls.push({ key, kind: 'check', set: v => { c.checked = !!v; }, inputs: [c] });
    box.append(el('label', {}, c, label));
  }
  return box;
}
function buttons(list) {
  return el('div', { class: 'btnrow' }, list.map(([t, fn, cls]) =>
    el('button', { class: 'btn small ' + (cls || ''), onclick: fn }, t)));
}

const RESOLUTIONS = ['320x240', '640x480', '800x600', '1024x768', '1280x720', '1280x960'];

/* ---------- содержимое вкладок ---------- */
const TABS = {
  camera() {
    const c = CFG.camera;
    const auto = c.pointing !== 'manual';
    const ext = SCHEMA.face_extent[c.face] || [0.5, 0.5];
    const res = el('select');
    for (const r of RESOLUTIONS) res.append(el('option', { value: r }, r.replace('x', ' × ')));
    res.addEventListener('change', () => {
      const [w, h] = res.value.split('x').map(Number);
      setParam('camera.width', w); setParam('camera.height', h);
    });
    controls.push({ key: '_res', kind: 'custom', set: () => { res.value = `${CFG.camera.width}x${CFG.camera.height}`; }, inputs: [res] });
    return [
      title('Крепление на корпусе'),
      select('camera.face', 'Грань', SCHEMA.faces),
      range('camera.u', 'Смещение u, м', -ext[0].toFixed(2), ext[0].toFixed(2), 0.01, 2),
      range('camera.v', 'Смещение v, м', -ext[1].toFixed(2), ext[1].toFixed(2), 0.01, 2),
      title('Наведение (поворотный привод)'),
      select('camera.pointing', 'Режим', SCHEMA.pointing),
      c.pointing === 'target' ? number('camera.target_lat', 'Широта цели, °', -90, 90, 0.01) : null,
      c.pointing === 'target' ? number('camera.target_lon', 'Долгота цели, °', -180, 180, 0.01) : null,
      range('camera.azimuth_deg', 'Азимут, °', -180, 180, 0.5, 1, { auto: 'cam_azimuth_deg' }),
      range('camera.tilt_deg', 'Угол места, °', -90, 90, 0.5, 1, { auto: 'cam_tilt_deg' }),
      range('camera.max_tilt_deg', 'Предел отклонения, °', 5, 180, 1, 0),
      range('camera.roll_deg', 'Крен кадра, °', -180, 180, 1, 0),
      buttons([['Обнулить углы', () => action('camera_zero')],
        auto ? ['Зафиксировать текущее наведение', () => action('freeze_pointing')] : null].filter(Boolean)),
      note(auto ? 'Углы привода считаются автоматически (розовые значения). Ручная правка — в режиме «Ручное».'
        : 'Привод «азимут — угол места». 0°/0° — ось по нормали к грани. Для боковых граней угол места −90° — надир, около −22° — горизонт; Земля всегда внизу кадра. Для грани +Z угол места > 0 — вперёд по полёту, азимут — поперёк трассы. Предел отклонения — максимальный угол оси от нормали (дальше мешает корпус). Клавиши: ← → азимут, ↑ ↓ угол места.'),
      title('Модель камеры'),
      select('camera.optics_mode', 'Модель', { sensor: 'Реальная: матрица + объектив', fov: 'Условная: поле зрения задаётся напрямую' }),
      ...(c.optics_mode === 'sensor' ? sensorBlock() : [
        range('camera.fov_h_deg', 'Поле зрения, °', 1, 120, 0.5, 1),
        el('div', { class: 'row wide' }, el('label', { class: 'name' }, 'Разрешение'), res),
      ]),
      title('Изображение'),
      range('camera.exposure_ev', 'Экспозиция, EV', -6, 6, 0.25, 2),
      range('camera.noise', 'Шум матрицы, σ', 0, 0.1, 0.002, 3),
      checks([['camera.bloom', 'засветка и ореол'], ['camera.stars', 'звёзды'],
        ['camera.show_own_body', 'элементы корпуса в кадре']]),
    ];
  },
  orbit() {
    return [
      title('Типовые орбиты'),
      buttons(Object.entries(SCHEMA.presets).map(([id, t]) => [t, () => action('preset', { id })])),
      title('Элементы орбиты'),
      range('orbit.perigee_alt_km', 'Высота перигея, км', 160, 2000, 5, 0, { numMax: 40000 }),
      range('orbit.eccentricity', 'Эксцентриситет', 0, 0.8, 0.005, 3),
      range('orbit.inclination_deg', 'Наклонение, °', 0, 180, 0.1, 1),
      range('orbit.raan_deg', 'Долгота восх. узла, °', 0, 360, 0.5, 1),
      range('orbit.arg_perigee_deg', 'Аргумент перигея, °', 0, 360, 0.5, 1),
      range('orbit.mean_anomaly_deg', 'Ср. аномалия (эпоха), °', 0, 360, 0.5, 1),
      checks([['orbit.use_j2', 'вековые возмущения J2']]),
      buttons([['Наклонение ССО для этой высоты', () => action('sso_inclination')]]),
      title('Время'),
      (() => {
        const inp = el('input', { type: 'datetime-local', step: 1 });
        inp.addEventListener('change', () => { setParam('time.epoch_utc', inp.value); action('reset_time'); });
        controls.push({ key: 'time.epoch_utc', kind: 'custom', set: v => { inp.value = v.slice(0, 19); }, inputs: [inp] });
        return el('div', { class: 'row wide' }, el('label', { class: 'name' }, 'Эпоха (UTC)'), inp);
      })(),
      buttons([['t = 0 (к эпохе)', () => action('reset_time')], ['+10 мин', () => action('step', { seconds: 600 })],
        ['+1 виток', () => action('step', { seconds: CFG ? orbitPeriod() : 5400 })]]),
      note('Положение Солнца и вращение Земли считаются по дате эпохи, поэтому от неё зависят освещённость и β-угол орбиты.'),
    ];
  },
  attitude() {
    return [
      title('Режим ориентации'),
      select('attitude.mode', 'Режим', SCHEMA.attitude),
      range('attitude.yaw_deg', 'Рыскание, °', -180, 180, 1, 0),
      range('attitude.pitch_deg', 'Тангаж, °', -180, 180, 1, 0),
      range('attitude.roll_deg', 'Крен, °', -180, 180, 1, 0),
      title('Солнечные батареи'),
      checks([['attitude.panel_tracking', 'автоповорот панелей на Солнце']]),
      range('attitude.panel_angle_deg', 'Угол панелей, °', -180, 180, 1, 0),
      note('Связанные оси КА: +Z — «нижняя» грань (в режиме LVLH смотрит в надир), +X — по полёту, ±Y — панели. Повороты применяются в порядке рыскание → тангаж → крен.'),
    ];
  },
  scene() {
    return [
      title('Земля'),
      checks([['scene.clouds', 'облачность'], ['scene.atmosphere', 'атмосфера'],
        ['scene.sun_glint', 'блик Солнца на океане'], ['scene.surface_detail', 'детализация поверхности']]),
      note(`Текстура: <b>${STATE.message ? STATE.message.replace('Текстура Земли: ', '') : '—'}</b>. Свою карту (равнопромежуточная проекция 2:1) положите в <code>assets/earth_day.jpg</code>.`),
      title('Общий вид'),
      range('view.sat_scale', 'Масштаб модели КА', 0.3, 5, 0.1, 1),
      range('view.render_scale', 'Качество общего вида', 0.25, 1, 0.05, 2),
      note('Если картинка обновляется редко — уменьшите «Качество общего вида» и разрешение камеры. Модельное время при этом идёт с заданным ускорением независимо от частоты кадров.'),
      range('fps', 'Ограничение к/с', 2, 30, 1, 0),
    ];
  },
  record() {
    const png = el('input', { type: 'checkbox', checked: '' });
    const mp4 = el('input', { type: 'checkbox' });
    const every = el('input', { type: 'number', min: 1, max: 100, value: 1, style: 'width:70px' });
    const file = el('input', { type: 'file', accept: '.json', style: 'display:none' });
    file.addEventListener('change', async () => {
      const f = file.files[0]; if (!f) return;
      const r = await api.post('/api/scenario', JSON.parse(await f.text()));
      toast(r.ok ? 'Сценарий загружен' : 'Ошибка: ' + r.error);
      await refreshConfig();
    });
    const base = location.origin;
    return [
      title('Запись кадров камеры'),
      el('div', { class: 'checks' }, el('label', {}, png, 'PNG-кадры'), el('label', {}, mp4, 'видео MP4')),
      el('div', { class: 'row wide' }, el('label', { class: 'name' }, 'Каждый N-й кадр'), every),
      buttons([['● Начать запись', () => action('record_start', { options: { png: png.checked, mp4: mp4.checked, every_n: +every.value } }), 'primary'],
        ['■ Остановить', () => action('record_stop')], ['Снимок', () => action('snapshot')]]),
      el('div', { class: 'note', id: 'recStatus' }, '—'),
      note('В папке прогона: <code>frames/*.png</code>, <code>telemetry.csv</code> (положение, ориентация, параметры камеры, освещённость на каждый кадр), <code>camera_intrinsics.json</code>, <code>scenario.json</code>. Для воспроизводимых датасетов без интерфейса: <code>python tools/capture_dataset.py</code>.'),
      title('Трансляция для внешних программ'),
      note(`Видеопоток (OpenCV, VLC, ffmpeg): <code>${base}/stream/camera.mjpg</code>`),
      note(`Кадр без сжатия: <code>${base}/api/frame/camera.png</code> · метаданные: <code>${base}/api/meta</code>`),
      note('Пример обработки: <code>python examples/read_stream_opencv.py</code>'),
      title('Сценарий'),
      buttons([['Сохранить сценарий (JSON)', () => { location.href = '/api/scenario'; }],
        ['Загрузить…', () => file.click()]]),
      file,
    ];
  },
};

// ---- матрица и объектив (этап 1: геометрия) ----
function presetSelect(label, options, current, actionName, deviated) {
  const s = el('select');
  for (const [id, t] of Object.entries(options)) s.append(el('option', { value: id }, t));
  s.value = current;
  s.addEventListener('change', async () => { await action(actionName, { id: s.value }); await refreshConfig(); });
  const row = el('div', { class: 'row wide' }, el('label', { class: 'name' }, label), s);
  if (deviated) row.append(el('span', { class: 'dev-mark', title: 'параметры изменены относительно паспорта' }, '≠ паспорт'));
  return row;
}
function sensorBlock() {
  const c = CFG.camera;
  const dev = (TEL.camera && TEL.camera.deviations) || [];
  const binSel = select('camera.binning', 'Бининг (объединение пикселей)', { 1: 'нет (1×1)', 2: '2×2', 4: '4×4' });
  return [
    title('Матрица'),
    presetSelect('Матрица', SCHEMA.sensors, c.sensor_preset, 'sensor_preset',
      dev.includes('размер пикселя') || dev.includes('число пикселей')),
    range('camera.pixel_um', 'Размер пикселя, мкм', 1, 20, 0.01, 2),
    range('camera.sensor_w_px', 'Пикселей по горизонтали', 256, 4096, 16, 0),
    range('camera.sensor_h_px', 'Пикселей по вертикали', 192, 3072, 16, 0),
    binSel,
    title('Объектив'),
    presetSelect('Объектив', SCHEMA.lenses, c.lens_preset, 'lens_preset', dev.includes('объектив')),
    range('camera.focal_mm', 'Фокусное расстояние, мм', 4, 300, 0.5, 1),
    range('camera.f_number', 'Диафрагменное число, f/', 0.95, 16, 0.05, 2),
    title('Расчёт: что следует из матрицы и объектива'),
    el('div', { class: 'derived', id: 'camDerived' }, '—'),
    title('Предпросмотр'),
    select('camera.preview_scale', 'Разрешение трансляции', { 1: '1:1 — полное (медленно)', 2: '1:2', 4: '1:4', 8: '1:8' }),
    note('Окно трансляции показывает кадр в уменьшенном разрешении с тем же полем зрения, чтобы картинка обновлялась часто. Запись датасетов (tools/capture_dataset.py) по умолчанию идёт в полном разрешении матрицы.'),
  ];
}
function renderDerived(d, t) {
  const box = document.getElementById('camDerived');
  if (!box || !d || d.mode !== 'sensor') return;
  const n = (v, k = 1) => (v == null ? '—' : (+v).toFixed(k));
  const rows = [
    ['Матрица', `${d.sensor}${d.chroma ? (d.chroma === 'mono' ? ', монохромная' : ', цветная (Байер)') : ''}`],
    ['Размер матрицы', `${n(d.sensor_w_mm, 2)} × ${n(d.sensor_h_mm, 2)} мм (диагональ ${n(d.sensor_diag_mm, 2)} мм)`],
    ['Пиксель', `${n(d.pixel_um, 2)} мкм${d.binning > 1 ? ` (бининг ${d.binning}×${d.binning})` : ''}`],
    ['Кадр матрицы', `${d.w_px} × ${d.h_px} (${n(d.megapixels, 2)} Мп)`],
    ['Кадр трансляции', t.frame_w ? `${t.frame_w} × ${t.frame_h}` : '—'],
    ['Поле зрения', `${n(d.fov_h_deg, 2)}° × ${n(d.fov_v_deg, 2)}° (диагональ ${n(d.fov_d_deg, 2)}°)`],
    ['Угловой размер пикселя', `${n(d.ifov_urad, 1)} мкрад = ${n(d.ifov_arcsec, 1)}″`],
    ['Апертура D = f/N', `${n(d.aperture_mm, 1)} мм`],
    ['Дифракционное пятно 2,44·λ·N', `${n(d.airy_um, 2)} мкм = ${n(d.airy_px, 2)} пикселя`],
    ['Пиксель на дальности 100 км', `${n(d.pixel_100km_m, 2)} м`],
    ['Пиксель в точке визирования', d.pixel_at_range_m != null ? `${n(d.pixel_at_range_m, 1)} м` : 'ось не пересекает Землю'],
    ['Отличия от паспорта', d.deviations.length ? d.deviations.join(', ') : 'нет — паспортные значения'],
  ];
  box.replaceChildren(...rows.map(([k, v]) => el('div', { class: 'kv' }, el('span', { class: 'k' }, k), el('span', { class: 'v' }, v))));
}

function orbitPeriod() {
  const a = (6378.137 + CFG.orbit.perigee_alt_km) / (1 - CFG.orbit.eccentricity);
  return 2 * Math.PI * Math.sqrt(a ** 3 / 398600.4418);
}

function render() {
  if (!CFG || !SCHEMA) return;
  controls.length = 0;
  const body = $('#tabBody');
  body.replaceChildren(...TABS[activeTab]().filter(Boolean));
  // переключатели в шапке общего вида
  for (const c of $$('.toggles input')) {
    const key = c.dataset.key;
    c.onchange = () => setParam(key, c.checked);
    controls.push({ key, kind: 'check', set: v => { c.checked = !!v; }, inputs: [c] });
  }
  syncControls(true);
}

function syncControls(force = false) {
  const now = performance.now();
  for (const c of controls) {
    if (c.key === '_res') { c.set(); continue; }
    const v = getKey(CFG, c.key);
    const busy = c.inputs.some(i => i === document.activeElement) || now - (lastEdit[c.key] || 0) < 800;
    const autoKey = c.opt && c.opt.auto;
    const isAuto = autoKey && CFG.camera.pointing !== 'manual';
    if (c.row) {
      c.row.classList.toggle('auto', !!isAuto);
      c.row.classList.toggle('disabled', c.key === 'attitude.panel_angle_deg' && CFG.attitude.panel_tracking);
      c.inputs.forEach(i => { i.disabled = !!isAuto; });
    }
    if (isAuto && TEL[autoKey] != null) { c.set(TEL[autoKey]); continue; }
    if (v === undefined) continue;
    if (force || !busy) c.set(v);
  }
  $$('#viewModes button').forEach(b => b.classList.toggle('active', b.dataset.mode === CFG.view.mode));
  $('#timeScale').value = String(Math.round(CFG.time.time_scale));
  $('#btnPause').textContent = CFG.time.paused ? '▶' : '❚❚';
}

/* ---------- телеметрия ---------- */
const f = (v, d = 1, u = '') => (v == null || Number.isNaN(v) ? '—' : (+v).toFixed(d) + u);
const lat = v => v == null ? '—' : `${Math.abs(v).toFixed(2)}° ${v >= 0 ? 'с.ш.' : 'ю.ш.'}`;
const lon = v => v == null ? '—' : `${Math.abs(v).toFixed(2)}° ${v >= 0 ? 'в.д.' : 'з.д.'}`;
const TELE_ROWS = [
  ['Орбита'],
  ['Высота', t => f(t.alt_km, 1, ' км')], ['Скорость', t => f(t.speed_kms, 3, ' км/с')],
  ['Период', t => f(t.period_min, 2, ' мин')], ['β-угол орбиты', t => f(t.beta_deg, 1, '°')],
  ['Подспутн. широта', t => lat(t.sub_lat)], ['Подспутн. долгота', t => lon(t.sub_lon)],
  ['Освещённость'],
  ['Аппарат', t => t.light, t => t.light === 'Солнце' ? 'good' : t.light === 'Тень' ? 'bad' : 'warn'],
  ['Видимая доля диска', t => f(t.sunlit * 100, 1, ' %')],
  ['Поток на объектив', t => f(t.flux_w_m2, 1, ' Вт/м²'), t => t.flux_w_m2 > 300 ? 'warn' : ''],
  ['Угол ось–Солнце', t => f(t.sun_angle_deg, 1, '°'), t => t.sun_angle_deg < 30 ? 'bad' : ''],
  ['Солнце в кадре', t => t.sun_in_fov ? 'да' : 'нет', t => t.sun_in_fov ? 'bad' : ''],
  ['Пересвет. пикселей', t => f(t.saturated_fraction * 100, 2, ' %')],
  ['Камера'],
  ['Азимут / угол места', t => `${f(t.cam_azimuth_deg, 1)}° / ${f(t.cam_tilt_deg, 1)}°`, t => t.pointing_ok ? '' : 'bad'],
  ['Угол ось–надир', t => f(t.nadir_angle_deg, 1, '°')],
  ['Земля в кадре', t => f(t.earth_fraction * 100, 1, ' %')],
  ['Корпус КА в кадре', t => f(t.render_body_fraction * 100, 1, ' %')],
  ['Поле зрения (верт.)', t => f(t.fov_v_deg, 1, '°')], ['Угл. размер пикселя', t => f(t.ifov_urad, 0, ' мкрад')],
  ['Точка визирования'],
  ['Широта', t => lat(t.gp_lat)], ['Долгота', t => lon(t.gp_lon)],
  ['Наклонная дальность', t => f(t.range_km, 1, ' км')], ['Проекция пикселя', t => t.gsd_m == null ? '—' : t.gsd_m < 1000 ? f(t.gsd_m, 1, ' м') : f(t.gsd_m / 1000, 2, ' км')],
  ['Высота Солнца в точке', t => f(t.gp_sun_el, 1, '°'), t => t.gp_sun_el != null && t.gp_sun_el < 0 ? 'bad' : ''],
];
function buildTele() {
  const box = $('#tele');
  box.replaceChildren();
  for (const r of TELE_ROWS) {
    if (r.length === 1) { box.append(el('div', { class: 'sec' }, r[0])); continue; }
    const v = el('span', { class: 'v' }, '—');
    r.v = v;
    box.append(el('div', { class: 'kv' }, el('span', { class: 'k' }, r[0]), v));
  }
}
function updateTele(t) {
  for (const r of TELE_ROWS) {
    if (!r.v) continue;
    try { r.v.textContent = r[1](t); r.v.className = 'v ' + (r[2] ? r[2](t) : ''); } catch { r.v.textContent = '—'; }
  }
}

function fmtT(s) {
  const sign = s < 0 ? '−' : '';
  s = Math.abs(s);
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), ss = Math.floor(s % 60);
  return `${sign}${h}:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
}

function updateHeader(st) {
  const t = st.telemetry;
  if (!t || t.utc == null) return;
  $('#utc').textContent = t.utc;
  $('#tsim').textContent = fmtT(t.t);
  $('#fps').textContent = (window.USE_GL ? `вид ${Overview3D.fps.toFixed(0)} · ` : '') + `камера ${st.fps.toFixed(1)}`;
  const chip = $('#chipLight');
  chip.textContent = t.light === 'Солнце' ? '☀ на Солнце' : t.light === 'Тень' ? 'в тени Земли' : 'полутень';
  chip.className = 'chip ' + (t.light === 'Солнце' ? 'sun' : t.light === 'Тень' ? 'shadow' : 'pen');
  const rec = st.recording;
  $('#chipRec').classList.toggle('hidden', !rec.active);
  $('#recCount').textContent = rec.count;
  $('#btnRec').classList.toggle('on', rec.active);
  $('#btnRec').textContent = rec.active ? '■ Стоп' : '● Запись';
  const rs = $('#recStatus');
  if (rs) rs.textContent = rec.active ? `Идёт запись: ${rec.count} кадров → ${rec.dir}` + (rec.dropped ? ` (пропущено ${rec.dropped})` : '')
    : (rec.dir ? `Последняя запись: ${rec.dir}` : 'Запись не ведётся');
}

function updateHud(t) {
  if (!t || t.utc == null) return;
  const c = CFG.camera;
  const cd = t.camera;
  const optics = cd && cd.mode === 'sensor'
    ? `${cd.sensor} · ${f(cd.focal_mm, 0)} мм f/${f(cd.f_number, 1)}\nFOV ${f(cd.fov_h_deg, 2)}°×${f(cd.fov_v_deg, 2)}° · ${cd.w_px}×${cd.h_px}`
    : `FOV ${f(c.fov_h_deg, 1)}° · ${c.width}×${c.height}`;
  $('#hudTL').textContent = `AZ ${f(t.cam_azimuth_deg, 1).padStart(6)}°\nEL ${f(t.cam_tilt_deg, 1).padStart(6)}°\n${optics}`;
  $('#hudTR').textContent = `${t.utc}\nH ${f(t.alt_km, 0)} km\n${c.face} · ${c.pointing.toUpperCase()}`;
  $('#hudBL').textContent = `SUN ∠ ${f(t.sun_angle_deg, 1)}°\nNADIR ∠ ${f(t.nadir_angle_deg, 1)}°`;
  $('#hudBR').textContent = t.gp_lat == null ? 'NO GROUND' : `${f(t.gp_lat, 2)}°, ${f(t.gp_lon, 2)}°\nGSD ${t.gsd_m < 1000 ? f(t.gsd_m, 0) + ' m' : f(t.gsd_m / 1000, 2) + ' km'}`;
  const w = [];
  if (t.sun_in_fov) w.push(['СОЛНЦЕ В КАДРЕ', '']);
  else if (t.sun_angle_deg < 25 && t.sunlit > 0) w.push(['ЗАСВЕТКА: СОЛНЦЕ У КРАЯ', '']);
  if (!t.pointing_ok) w.push([c.pointing === 'target' && t.target_visible === false ? 'ЦЕЛЬ ЗА ГОРИЗОНТОМ' : 'ВНЕ ДИАПАЗОНА ПРИВОДА', '']);
  if (t.light === 'Тень') w.push(['КА В ТЕНИ ЗЕМЛИ', 'info']);
  $('#hudWarn').replaceChildren(...w.map(([s, cls]) => el('span', { class: cls }, s)));
}

/* ---------- график ---------- */
const hist = [];
function pushHistory(t) {
  if (t.t == null) return;
  const last = hist[hist.length - 1];
  if (last && t.t < last.t) hist.length = 0;         // перемотка назад
  if (last && t.t === last.t) return;
  hist.push({ t: t.t, flux: t.flux_w_m2, earth: t.earth_fraction, lit: t.sunlit });
  if (hist.length > 1500) hist.shift();
}
function drawChart() {
  const cv = $('#chart');
  const dpr = window.devicePixelRatio || 1;
  const W = cv.clientWidth, H = cv.clientHeight;
  if (cv.width !== W * dpr) { cv.width = W * dpr; cv.height = H * dpr; }
  const g = cv.getContext('2d');
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, W, H);
  const L = 46, R = 40, T = 10, B = 20;
  const pw = W - L - R, ph = H - T - B;
  g.font = '10px ' + getComputedStyle(document.body).fontFamily;
  g.strokeStyle = '#1e2a3d'; g.fillStyle = '#55637a'; g.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = T + ph * i / 4;
    g.beginPath(); g.moveTo(L, y); g.lineTo(L + pw, y); g.stroke();
    g.textAlign = 'right'; g.fillText(String(1400 - i * 350), L - 6, y + 3);
    g.textAlign = 'left'; g.fillText(String(100 - i * 25), L + pw + 6, y + 3);
  }
  if (hist.length < 2) return;
  const t1 = hist[hist.length - 1].t;
  const span = Math.max(CFG ? orbitPeriod() * 1.5 : 8000, 60);
  const t0 = t1 - span;
  const X = t => L + (t - t0) / span * pw;
  const pts = hist.filter(p => p.t >= t0);
  // тень
  g.fillStyle = 'rgba(40, 52, 110, .45)';
  for (let i = 1; i < pts.length; i++) {
    if (pts[i].lit < 0.5) g.fillRect(X(pts[i - 1].t), T, Math.max(1, X(pts[i].t) - X(pts[i - 1].t)), ph);
  }
  const line = (key, color, k) => {
    g.strokeStyle = color; g.lineWidth = 1.6; g.beginPath();
    pts.forEach((p, i) => { const y = T + ph * (1 - Math.min(1, p[key] * k)); i ? g.lineTo(X(p.t), y) : g.moveTo(X(p.t), y); });
    g.stroke();
  };
  line('earth', '#5adcff', 1);
  line('flux', '#ffb547', 1 / 1400);
  g.fillStyle = '#55637a'; g.textAlign = 'center';
  for (let i = 0; i <= 4; i++) {
    const tt = t0 + span * i / 4;
    g.fillText(tt < 0 ? '' : fmtT(tt), L + pw * i / 4, H - 5);
  }
}

/* ---------- потоки кадров ---------- */
async function pump(view, img) {
  let seq = 0;
  let prevUrl = null;
  for (;;) {
    try {
      const r = await fetch(`/api/frame/${view}.jpg?after=${seq}`, { cache: 'no-store' });
      if (!r.ok) { await sleep(400); continue; }
      seq = +r.headers.get('X-Seq') || seq;
      const url = URL.createObjectURL(await r.blob());
      img.src = url;
      try { await img.decode(); } catch { /* кадр мог смениться */ }
      if (prevUrl) URL.revokeObjectURL(prevUrl);
      prevUrl = url;
    } catch {
      await sleep(1000);
    }
  }
}

/* ---------- мышь в общем виде ---------- */
// Вид меняется сразу в браузере (без ожидания сервера), на сервер уходит для сохранения в сценарий.
function moveView(dx, dy, zoom) {
  const v = CFG.view;
  v.azimuth_deg = ((v.azimuth_deg - dx * 0.3) % 360 + 360) % 360;
  v.elevation_deg = Math.max(-89, Math.min(89, v.elevation_deg + dy * 0.3));
  setParam('view.azimuth_deg', v.azimuth_deg);
  setParam('view.elevation_deg', v.elevation_deg);
  if (zoom) {
    const k = Math.exp(Math.max(-400, Math.min(400, zoom)) * 0.0008);
    if (v.mode === 'closeup') setParam('view.distance_m', Math.max(2.5, Math.min(200, v.distance_m * k)));
    else if (v.mode === 'follow') setParam('view.follow_distance_km', Math.max(0.05, Math.min(30000, v.follow_distance_km * k)));
    else setParam('view.distance_km', Math.max(7500, Math.min(400000, v.distance_km * k)));
  }
  if (window.USE_GL) Overview3D.setView(CFG.view, CFG.scene);
}
function setupDrag() {
  const wrap = $('#ovWrap');
  let drag = null;
  wrap.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY }; wrap.setPointerCapture(e.pointerId); });
  wrap.addEventListener('pointermove', e => {
    if (!drag || !CFG) return;
    moveView(e.clientX - drag.x, e.clientY - drag.y, 0);
    drag = { x: e.clientX, y: e.clientY };
  });
  wrap.addEventListener('pointerup', () => { drag = null; });
  wrap.addEventListener('wheel', e => { e.preventDefault(); if (CFG) moveView(0, 0, e.deltaY); }, { passive: false });
}

// удобные углы обзора для каждого режима
const VIEW_DEFAULTS = { earth: [-60, 78], follow: [30, 18], closeup: [40, 22] };
function setViewMode(m) {
  if (!CFG) return;
  setParam('view.mode', m);
  const [az, el] = VIEW_DEFAULTS[m] || [0, 20];
  setParam('view.azimuth_deg', az);
  setParam('view.elevation_deg', el);
  syncControls();
  if (window.USE_GL) Overview3D.setView(CFG.view, CFG.scene);
}

/* ---------- состояние сцены для WebGL ---------- */
async function scenePump() {
  for (;;) {
    try {
      const sc = await api.get('/api/scene');
      Overview3D.pushScene(sc);
      setConn(true);
    } catch (e) { setConn(false, String(e)); await sleep(500); }
    await sleep(45);
  }
}

/* ---------- клавиатура ---------- */
function setupKeys() {
  document.addEventListener('keydown', e => {
    if (['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName) && e.key !== 'Escape') return;
    const c = CFG && CFG.camera;
    const manual = c && c.pointing === 'manual';
    const k = e.key;
    if (k === ' ') { e.preventDefault(); action('pause'); }
    else if (k === 'ArrowLeft' && manual) { e.preventDefault(); setParam('camera.azimuth_deg', Math.max(-180, c.azimuth_deg - 2)); }
    else if (k === 'ArrowRight' && manual) { e.preventDefault(); setParam('camera.azimuth_deg', Math.min(180, c.azimuth_deg + 2)); }
    else if (k === 'ArrowUp' && manual) { e.preventDefault(); setParam('camera.tilt_deg', Math.min(90, c.tilt_deg + 2)); }
    else if (k === 'ArrowDown' && manual) { e.preventDefault(); setParam('camera.tilt_deg', Math.max(-90, c.tilt_deg - 2)); }
    else if (k === '+' || k === '=') { stepScale(1); }
    else if (k === '-') { stepScale(-1); }
    else if (k === 's' || k === 'ы') action('snapshot');
    else if (k === 'r' || k === 'к') toggleRec();
    else if (k === 'h' || k === 'р') toggleHud();
    else if (k === '1' || k === '2' || k === '3') setViewMode(['earth', 'follow', 'closeup'][+k - 1]);
    else return;
    syncControls();
  });
}
function stepScale(dir) {
  const opts = [...$('#timeScale').options].map(o => +o.value);
  const cur = CFG.time.time_scale;
  let i = opts.findIndex(v => v >= cur);
  if (i < 0) i = opts.length - 1;
  i = Math.max(0, Math.min(opts.length - 1, i + dir));
  setParam('time.time_scale', opts[i]);
}
function toggleRec() {
  if (STATE.recording && STATE.recording.active) action('record_stop');
  else action('record_start', { options: { png: true, mp4: false, every_n: 1 } });
}
function toggleHud() { $('#hud').classList.toggle('off'); $('#btnHud').classList.toggle('active', !$('#hud').classList.contains('off')); }

/* ---------- запуск ---------- */
async function refreshConfig() {
  STATE = await api.get('/api/state');
  CFG = STATE.config;
  render();
}

async function pollState() {
  let shown = '';
  for (;;) {
    let st;
    try {
      st = await api.get('/api/state');
      setConn(true);
    } catch (e) { setConn(false, String(e)); await sleep(800); continue; }
    try {
      STATE = st;
      // не затираем то, что пользователь только что менял
      const keep = {};
      for (const [k, t] of Object.entries(lastEdit)) if (performance.now() - t < 800) keep[k] = getKey(CFG, k);
      CFG = st.config;
      for (const [k, v] of Object.entries(keep)) if (v !== undefined) setKey(CFG, k, v);
      TEL = st.telemetry || {};
      if (st.error && st.error !== pollState.lastErr) toast('Ошибка расчёта: ' + st.error + ' (подробности в окне консоли)');
      pollState.lastErr = st.error;
      updateHeader(st);
      updateTele(TEL);
      updateHud(TEL);
      renderDerived(TEL.camera, TEL);
      pushHistory(TEL);
      drawChart();
      syncControls();
      if (window.USE_GL) Overview3D.setView(CFG.view, CFG.scene);
    } catch (e) {
      const m = String(e && (e.stack || e));
      if (m !== shown) { showFatal('Ошибка обновления интерфейса: ' + m); shown = m; }
    }
    await sleep(250);
  }
}

async function main() {
  SCHEMA = await api.get('/api/schema');
  const vm = $('#viewModes');
  for (const [m, t] of Object.entries(SCHEMA.views)) {
    vm.append(el('button', { 'data-mode': m, onclick: () => setViewMode(m) }, t));
  }
  $$('#tabs button').forEach(b => b.addEventListener('click', () => {
    activeTab = b.dataset.tab;
    $$('#tabs button').forEach(x => x.classList.toggle('active', x === b));
    render();
  }));
  $$('[data-action]').forEach(b => b.addEventListener('click', () =>
    action(b.dataset.action, b.dataset.seconds ? { seconds: +b.dataset.seconds } : {})));
  $('#btnPause').addEventListener('click', () => action('pause'));
  $('#timeScale').addEventListener('change', e => setParam('time.time_scale', +e.target.value));
  $('#btnRec').addEventListener('click', toggleRec);
  $('#btnHud').addEventListener('click', toggleHud);
  $('#btnHud').classList.add('active');
  buildTele();
  setupDrag();
  setupKeys();
  await refreshConfig();
  window.addEventListener('resize', drawChart);
  pump('camera', $('#camImg'));
  let gl = false;
  try { gl = Overview3D.init($('#ovGL'), $('#ovLines')); } catch (e) { showFatal('WebGL: ' + e.message + ' — общий вид будет картинками с сервера'); gl = false; }
  window.USE_GL = gl;
  if (gl) {
    Overview3D.setView(CFG.view, CFG.scene);
    scenePump();
  } else {
    $('#ovGL').classList.add('hidden'); $('#ovLines').classList.add('hidden'); $('#ovImg').classList.remove('hidden');
    pump('overview', $('#ovImg'));
  }
  pollState();
}
main().catch(e => showFatal('Не удалось запустить интерфейс: ' + (e.stack || e)));
