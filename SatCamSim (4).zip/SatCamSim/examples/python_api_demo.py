"""Работа с симулятором напрямую из Python (без интерфейса).

    python examples/python_api_demo.py

Показывает: настройку сценария в коде, получение кадров с метаданными,
подписку на трансляцию и простую обработку кадра.
"""
import sys
from pathlib import Path

import cv2

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from satsim import imgio                 # noqa: E402
from satsim.config import SimConfig      # noqa: E402
from satsim.engine import Engine         # noqa: E402
from satsim.orbit import sun_synchronous_inclination  # noqa: E402

cfg = SimConfig()
cfg.orbit.perigee_alt_km = 600
cfg.orbit.inclination_deg = sun_synchronous_inclination(600)
cfg.camera.face = "+X"            # камера на грани «по полёту»
cfg.camera.tilt_deg = -24         # угол места: чуть ниже горизонта (горизонт с 600 км ≈ −24.5°)
cfg.camera.azimuth_deg = 0
cfg.camera.lens_preset, cfg.camera.focal_mm, cfg.camera.f_number = "25f14", 25.0, 1.4   # широкий объектив

eng = Engine(cfg)


def on_frame(frame):
    # frame.image — RGB uint8, frame.meta — словарь с «истинными» данными
    m = frame.meta
    print(f"кадр {frame.index}: t={m['t']:.0f} c, Земля занимает {m['render_earth_fraction'] * 100:.1f}% кадра, "
          f"угол на Солнце {m['sun_angle_deg']:.1f}°")


eng.feed.subscribe(on_frame)
print("Камера:", cfg.camera.sensor_preset, f"{cfg.camera.focal_mm:.0f} мм f/{cfg.camera.f_number}")
for _ in range(5):
    eng.tick(dt_real=10.0, overview=False)       # 10 реальных секунд × ускорение времени

# Отдельный кадр на произвольный момент (детерминированно)
fr = eng.capture_at(1800.0)
out = Path("output")
out.mkdir(exist_ok=True)
imgio.imwrite(out / "api_demo_frame.png", fr.bgr())   # работает и с кириллицей в пути
print("Матрица K:\n", eng.sim.state(1800.0).intr.K)
print("Сохранено:", out / "api_demo_frame.png")
eng.close()
