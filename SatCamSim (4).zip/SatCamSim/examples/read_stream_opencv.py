"""Пример внешней программы, работающей с трансляцией камеры.

Запустите симулятор (python main.py), затем в другом окне:
    python examples/read_stream_opencv.py

Скрипт получает видеопоток камеры по сети (MJPEG через HTTP — его понимает
OpenCV, ffmpeg, VLC), а метаданные кадра — в JSON. Здесь для примера
выделяется линия горизонта (граница Земля/космос) и печатаются данные.
Это заготовка для отдельного исследования по камере.
"""
import json
import urllib.request

import cv2
import numpy as np

HOST = "http://127.0.0.1:8765"


def telemetry():
    with urllib.request.urlopen(HOST + "/api/state", timeout=2) as r:
        return json.loads(r.read())["telemetry"]


def main():
    cap = cv2.VideoCapture(HOST + "/stream/camera.mjpg")
    if not cap.isOpened():
        raise SystemExit("Не удалось открыть поток. Запущен ли main.py?")
    k = 0
    while True:
        ok, frame = cap.read()            # BGR, uint8
        if not ok:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Простейшая сегментация «Земля / космос» и контур горизонта
        _, mask = cv2.threshold(cv2.GaussianBlur(gray, (5, 5), 0), 18, 255, cv2.THRESH_BINARY)
        edges = cv2.Canny(mask, 50, 150)
        vis = frame.copy()
        vis[edges > 0] = (0, 0, 255)
        if k % 20 == 0:
            t = telemetry()
            print(f"t={t['t']:.0f}s  alt={t['alt_km']:.0f}km  sun∠={t['sun_angle_deg']:.1f}°  "
                  f"Земля в кадре={t['earth_fraction'] * 100:.0f}%  {t['light']}")
        cv2.imshow("camera + horizon", vis)
        if cv2.waitKey(1) & 0xFF in (27, ord("q")):
            break
        k += 1
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
