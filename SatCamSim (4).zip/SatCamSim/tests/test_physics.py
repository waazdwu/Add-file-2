import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from satsim import astro
from satsim.orbit import OrbitElements, propagate, sun_synchronous_inclination
from satsim.sensor import Intrinsics
from satsim.simulation import Simulation
from satsim.config import SimConfig
from satsim.spacecraft import CameraMount, Ry, Rz, matrix_to_quaternion


def test_julian_date_j2000():
    assert astro.julian_date(datetime(2000, 1, 1, 12, tzinfo=timezone.utc)) == pytest.approx(2451545.0)


def test_gmst_reference():
    # Vallado, пример 3-5: 1992-08-20 12:14 UT1 → GMST = 152.578787°
    jd = astro.julian_date(datetime(1992, 8, 20, 12, 14, tzinfo=timezone.utc))
    assert math.degrees(astro.gmst(jd)) == pytest.approx(152.5788, abs=0.01)


def test_sun_at_solstice_and_equinox():
    s = astro.sun_position_eci(astro.julian_date(datetime(2026, 6, 21, 8, 24, tzinfo=timezone.utc)))
    dec = math.degrees(math.asin(s[2] / np.linalg.norm(s)))
    assert dec == pytest.approx(23.44, abs=0.05)
    assert np.linalg.norm(s) / astro.AU == pytest.approx(1.0163, abs=0.001)   # афелий
    s = astro.sun_position_eci(astro.julian_date(datetime(2026, 3, 20, 14, 46, tzinfo=timezone.utc)))
    assert math.degrees(math.asin(s[2] / np.linalg.norm(s))) == pytest.approx(0.0, abs=0.05)


def test_circular_orbit_radius_and_period():
    el = OrbitElements(perigee_alt_km=400, inclination_deg=51.6, raan_deg=30)
    for t in np.linspace(0, el.period_s, 7):
        r, v = propagate(el, t)
        assert np.linalg.norm(r) == pytest.approx(astro.R_EARTH + 400, abs=1e-6)
        assert np.dot(r, v) == pytest.approx(0, abs=1e-6)
    assert el.period_s / 60 == pytest.approx(92.56, abs=0.05)
    r0, _ = propagate(el, 0)
    r1, _ = propagate(el, el.period_s)
    assert np.linalg.norm(r1 - r0) < 1e-6


def test_elliptic_orbit_energy():
    el = OrbitElements(perigee_alt_km=300, eccentricity=0.1, inclination_deg=63.4, arg_perigee_deg=270)
    E0 = None
    for t in np.linspace(0, el.period_s, 11):
        r, v = propagate(el, t)
        E = np.dot(v, v) / 2 - astro.MU_EARTH / np.linalg.norm(r)
        E0 = E if E0 is None else E0
        assert E == pytest.approx(E0, rel=1e-9)
    r, _ = propagate(el, 0)
    assert np.linalg.norm(r) - astro.R_EARTH == pytest.approx(300, abs=1e-6)


def test_sun_synchronous_inclination():
    assert sun_synchronous_inclination(600) == pytest.approx(97.79, abs=0.05)


def test_eclipse_geometry():
    sun = np.array([astro.AU, 0, 0])
    R = astro.R_EARTH + 500
    assert astro.sunlit_fraction(np.array([R, 0, 0]), sun) == 1.0     # подсолнечная точка
    assert astro.sunlit_fraction(np.array([-R, 0, 0]), sun) == 0.0    # за Землёй
    assert astro.sunlit_fraction(np.array([0, R, 0]), sun) == 1.0     # терминатор, над Землёй
    # Проход через полутень: доля монотонно падает
    vals = [astro.sunlit_fraction(np.array([-R * math.cos(a), R * math.sin(a), 0]), sun)
            for a in np.radians(np.linspace(75, 60, 200))]
    assert vals[0] == 1.0 and vals[-1] == 0.0
    assert all(b <= a + 1e-12 for a, b in zip(vals, vals[1:]))
    assert any(0 < x < 1 for x in vals)


def test_camera_mount_pointing_roundtrip():
    for face in ["+X", "-X", "+Y", "-Y", "+Z", "-Z"]:
        m = CameraMount(face=face)
        n = m.frame()[:, 2]
        R = m.rotation_body()
        assert np.allclose(R[:, 2], n)                    # ось = нормаль грани
        assert np.allclose(R, m.frame())                  # нулевые углы = базис грани
        for az, tl, rl in [(30, -40, 0), (-75, 20, 15), (0, -89, 0), (120, 10, -30)]:
            m.azimuth_deg, m.tilt_deg, m.roll_deg = az, tl, rl
            R = m.rotation_body()
            assert np.allclose(R.T @ R, np.eye(3), atol=1e-12)
            assert np.linalg.det(R) == pytest.approx(1.0)
        m.roll_deg = 0
        d = np.array([0.3, -0.5, 0.8]) * (1 if face != "-Z" else -1)
        d /= np.linalg.norm(d)
        if d @ n > 0.05:
            assert m.point_at(d)
            assert np.allclose(m.rotation_body()[:, 2], d, atol=1e-9)
        # направление «за корпус» недостижимо → ось на границе конуса
        assert not m.point_at(-n + 0.1 * m.frame()[:, 0])
        assert m.off_normal_deg() == pytest.approx(m.max_tilt_deg, abs=1e-6)


def test_side_camera_keeps_horizon_level():
    # камера на боковой грани, смотрит на горизонт: ось x кадра горизонтальна,
    # «низ» кадра направлен к Земле (+Z связанной СК в режиме LVLH)
    for face in ["+X", "-X", "+Y", "-Y"]:
        m = CameraMount(face=face, azimuth_deg=37, tilt_deg=-22)
        R = m.rotation_body()
        assert abs(R[2, 0]) < 1e-12          # x ⟂ вертикали
        assert R[2, 1] > 0                   # y (вниз) смотрит к надиру
    m = CameraMount(face="+Z", tilt_deg=70)  # с надирной грани вперёд к горизонту
    assert m.rotation_body()[2, 1] > 0       # Земля внизу кадра


def test_intrinsics():
    i = Intrinsics(640, 480, 90)
    assert i.fx == pytest.approx(320)
    rays = i.local_rays()
    assert rays.shape == (480, 640, 3)
    p = i.project(rays.reshape(-1, 3)[[0, -1]])
    assert np.allclose(p, [[0, 0], [639, 479]], atol=1e-6)


def test_quaternion():
    R = Rz(0.3) @ Ry(-1.1)
    q = matrix_to_quaternion(R)
    w, x, y, z = q
    Rq = np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                   [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                   [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
    assert np.allclose(R, Rq)


def test_simulation_nadir_camera_sees_earth():
    sim = Simulation(SimConfig())
    s = sim.state()
    assert s.metrics["nadir_angle_deg"] < 0.5
    assert s.metrics["earth_fraction"] == pytest.approx(1.0)
    assert s.telemetry["alt_km"] == pytest.approx(500, abs=1)
    assert s.metrics["ground"]["range_km"] == pytest.approx(500, abs=1)


def test_simulation_auto_pointing_sun_and_target():
    cfg = SimConfig()
    cfg.camera.face = "-Z"
    cfg.camera.pointing = "sun"
    cfg.attitude.mode = "sun"
    s = Simulation(cfg).state()
    assert s.metrics["sun_angle_deg"] < 0.01
    cfg = SimConfig()
    cfg.camera.pointing = "target"
    sim = Simulation(cfg)
    st = sim.state()
    # подспутниковая точка всегда видна → навели и попали
    cfg.camera.target_lat, cfg.camera.target_lon = st.telemetry["sub_lat"], st.telemetry["sub_lon"]
    st = sim.state()
    g = st.metrics["ground"]
    assert g["lat"] == pytest.approx(cfg.camera.target_lat, abs=0.05)


def test_config_update_coercion():
    cfg = SimConfig()
    changed = cfg.update({"orbit.inclination_deg": "97.5", "camera.width": "800",
                          "camera.bloom": "false", "nope.x": 1, "view.mode": "closeup"})
    assert cfg.orbit.inclination_deg == 97.5 and cfg.camera.width == 800
    assert cfg.camera.bloom is False and cfg.view.mode == "closeup"
    assert "nope.x" not in changed


def test_target_beyond_horizon_flagged():
    cfg = SimConfig()
    cfg.camera.pointing = "target"
    sim = Simulation(cfg)
    st = sim.state()
    cfg.camera.target_lat = -st.telemetry["sub_lat"]                 # антипод подспутниковой точки
    cfg.camera.target_lon = st.telemetry["sub_lon"] + 180.0
    st = sim.state()
    assert st.telemetry["target_visible"] is False
    assert st.telemetry["pointing_ok"] is False


def test_renderer_smoke():
    from satsim.engine import Engine
    cfg = SimConfig()
    cfg.camera.optics_mode = "fov"          # условная камера 640×480, 60°
    eng = Engine(cfg, allow_download=False, output_dir="/tmp/satsim_test_out")
    fr = eng.capture_at(0.0)
    assert fr.image.shape == (480, 640, 3) and fr.image.dtype == np.uint8
    assert fr.meta["render_earth_fraction"] == pytest.approx(1.0)      # камера в надир
    assert fr.image.mean() > 20                                         # дневная сторона
    eng.cfg.camera.face, eng.cfg.camera.pointing = "-Z", "sun"
    fr = eng.capture_at(0.0)
    assert fr.meta["sun_in_fov"] and fr.meta["saturated_fraction"] > 0
    eng.close()



# ---------------- Этап 1: геометрия камеры (матрица + объектив) ----------------
def test_imx265_lens_geometry_matches_plan_table():
    from satsim import camera_model as cm
    c = SimConfig().camera
    expect = {"25f14": (16.09, 12.10, 138.0, 17.9), "50f18": (8.08, 6.07, 69.0, 27.8),
              "75f20": (5.39, 4.05, 46.0, 37.5)}
    for key, (fh, fv, ifov, D) in expect.items():
        cm.apply_lens_preset(c, key)
        d = cm.derived(c)
        assert d["fov_h_deg"] == pytest.approx(fh, abs=0.01)
        assert d["fov_v_deg"] == pytest.approx(fv, abs=0.01)
        assert d["ifov_urad"] == pytest.approx(ifov, abs=0.1)
        assert d["aperture_mm"] == pytest.approx(D, abs=0.05)
        assert d["sensor_w_mm"] == pytest.approx(7.07, abs=0.01)
        assert d["deviations"] == []
        intr = cm.intrinsics(c)
        assert intr.fx == pytest.approx(c.focal_mm * 1000 / c.pixel_um, rel=1e-9)   # fx = f/p


def test_binning_keeps_field_of_view():
    from satsim import camera_model as cm
    c = SimConfig().camera
    g1 = cm.geometry(c)
    c.binning = 2
    g2 = cm.geometry(c)
    assert (g2.w_px, g2.h_px) == (1024, 768)
    assert g2.pixel_um == pytest.approx(6.9)
    assert g2.fov_h_deg == pytest.approx(g1.fov_h_deg)
    assert g2.ifov_rad == pytest.approx(2 * g1.ifov_rad)


def test_passport_deviation_flags():
    from satsim import camera_model as cm
    c = SimConfig().camera
    c.pixel_um = 5.86
    c.focal_mm = 35.0
    assert set(cm.passport_deviations(c)) == {"размер пикселя", "объектив"}


def test_preview_and_full_resolution_frames():
    from satsim.engine import Engine
    eng = Engine(SimConfig(), allow_download=False, output_dir="/tmp/satsim_test_out")
    st = eng.sim.state(0.0)
    assert (st.intr.width, st.intr.height) == (2048, 1536)
    prev = eng.capture_at(0.0, scale=4)
    assert prev.image.shape == (384, 512, 3)
    assert prev.meta["fx"] == pytest.approx(st.intr.fx / 4, rel=1e-6)
    assert prev.meta["cam_fov_h_deg"] == pytest.approx(8.08, abs=0.01)
    assert prev.meta["sensor_width"] == 2048
    # тот же кадр в полном разрешении — те же доли Земли/корпуса (геометрия не зависит от масштаба)
    full = eng.capture_at(0.0, scale=1)
    assert full.image.shape == (1536, 2048, 3)
    assert full.meta["render_earth_fraction"] == pytest.approx(prev.meta["render_earth_fraction"], abs=0.01)
    eng.close()


def test_old_scenarios_open_as_fov_camera(tmp_path):
    import json
    old = {"camera": {"width": 800, "height": 600, "fov_h_deg": 5.0}}
    p = tmp_path / "old.json"
    p.write_text(json.dumps(old), encoding="utf-8")
    cfg = SimConfig.load(p)
    assert cfg.camera.optics_mode == "fov"
    st = __import__("satsim.simulation", fromlist=["Simulation"]).Simulation(cfg).state()
    assert (st.intr.width, st.intr.fov_h_deg) == (800, 5.0)
