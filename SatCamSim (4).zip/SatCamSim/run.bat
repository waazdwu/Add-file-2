@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem Ищем Python: сначала лаунчер py, затем python из PATH
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
    where python >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo Python не найден.
    echo Установите Python 3.9+ с https://www.python.org/downloads/
    echo и при установке отметьте "Add python.exe to PATH".
    pause
    exit /b 1
)

%PY% main.py %*
echo.
pause
