"""SatCamSim — запуск симулятора с веб-интерфейсом.

    python main.py                      # откроет интерфейс в браузере
    python main.py --scenario my.json   # начать с сохранённого сценария
    python main.py --port 9000 --no-browser

Можно запускать и двойным щелчком: при ошибке окно не закроется,
а текст ошибки сохранится в файл satcamsim_error.log рядом с программой.
"""
import argparse
import importlib
import subprocess
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

REQUIRED = {"numpy": "numpy", "cv2": "opencv-python"}


def wait_key(msg="\nНажмите Enter, чтобы закрыть окно…"):
    try:
        input(msg)
    except (EOFError, KeyboardInterrupt):
        pass


def check_python():
    if sys.version_info < (3, 9):
        print(f"Нужен Python 3.9 или новее, а запущен {sys.version.split()[0]}\n"
              f"({sys.executable}).\nУстановите свежий Python с https://www.python.org/downloads/ "
              "(при установке отметьте «Add python.exe to PATH»).")
        wait_key()
        sys.exit(1)


def check_dependencies():
    """Проверить numpy и OpenCV; при отсутствии — предложить установить."""
    missing = []
    for mod, pkg in REQUIRED.items():
        try:
            importlib.import_module(mod)
        except ImportError:
            missing.append(pkg)
    if not missing:
        return
    print("Не установлены нужные библиотеки: " + ", ".join(missing))
    print(f"Python: {sys.executable}")
    ans = ""
    try:
        ans = input("Установить их сейчас через pip? [Y/n]: ").strip().lower()
    except EOFError:
        pass
    if ans in ("", "y", "yes", "д", "да"):
        cmd = [sys.executable, "-m", "pip", "install", *missing]
        print("Выполняю:", " ".join(cmd))
        if subprocess.call(cmd) != 0:
            print("\nУстановка не удалась. Попробуйте вручную в командной строке:\n"
                  f'  "{sys.executable}" -m pip install {" ".join(missing)}')
            wait_key()
            sys.exit(1)
        importlib.invalidate_caches()
        for mod in REQUIRED:
            importlib.import_module(mod)
        print("Готово.\n")
    else:
        print(f'Установите вручную:  "{sys.executable}" -m pip install {" ".join(missing)}')
        wait_key()
        sys.exit(1)


def bind_server(app, host, port, serve):
    """Занять порт; если он занят (например, уже запущена копия) — взять следующий."""
    last_err = None
    for p in range(port, port + 15):
        try:
            return serve(app, host, p), p
        except OSError as exc:
            last_err = exc
    raise OSError(f"Не удалось занять порты {port}–{port + 14}: {last_err}")


def self_test(app):
    """Один пробный кадр камеры и общего вида с замером времени."""
    import time
    import numpy as np
    eng = app.engine
    t0 = time.perf_counter()
    st = eng.sim.state()
    print("Самопроверка: пробный кадр камеры…", flush=True)
    img, info = eng.render_camera(st, scale=eng.preview_scale())
    t1 = time.perf_counter()
    ov = eng.render_overview(st)
    t2 = time.perf_counter()
    print(f"Самопроверка: кадр камеры {img.shape[1]}×{img.shape[0]} — {(t1 - t0) * 1000:.0f} мс "
          f"(Земля {info.earth_fraction * 100:.0f}% кадра, ср. яркость {img.mean():.0f}), "
          f"общий вид — {(t2 - t1) * 1000:.0f} мс; numpy {np.__version__}, "
          f"OpenCV {__import__('cv2').__version__}, Python {sys.version.split()[0]}")
    if t2 - t0 > 1.5:
        print("  Отрисовка медленная — уменьшаю качество общего вида до 0.5 "
              "(вкладка «Сцена» → «Качество общего вида»).")
        app.cfg.view.render_scale = 0.5


def run():
    import logging
    import threading
    import webbrowser

    from satsim.config import SimConfig
    from satsim.server import App, serve

    ap = argparse.ArgumentParser(description="Симулятор ИСЗ с бортовой камерой")
    ap.add_argument("--scenario", help="JSON-файл сценария")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true", help="не открывать браузер автоматически")
    ap.add_argument("--offline", action="store_true", help="не пытаться скачать текстуру Земли")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    cfg = SimConfig.load(args.scenario) if args.scenario else SimConfig()
    print("Подготовка сцены (при первом запуске — загрузка/генерация текстур, до минуты)…")
    app = App(cfg, allow_download=not args.offline)
    print(app.message)
    self_test(app)
    httpd, port = bind_server(app, args.host, args.port, serve)
    url = f"http://{args.host}:{port}/"
    app.start()
    print(f"\nИнтерфейс:            {url}")
    print(f"Видеопоток камеры:    {url}stream/camera.mjpg")
    print("Не закрывайте это окно, пока работаете с программой. Остановка: Ctrl+C.\n")
    if not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        app.running = False
        app.engine.close()
        httpd.server_close()
        print("Остановлено.")


def check_unpacked():
    """Запуск прямо из zip-архива: Windows извлекает только main.py, без папки satsim."""
    if (ROOT / "satsim" / "__init__.py").exists():
        return
    print("Не найдена папка satsim рядом с main.py.\n")
    if ".zip" in str(ROOT).lower():
        print("Похоже, программа запущена прямо из ZIP-архива.\n"
              "Распакуйте архив: правой кнопкой по файлу .zip → «Извлечь все…»,\n"
              "затем запустите run.bat или main.py из распакованной папки SatCamSim.")
    else:
        print(f"Папка программы: {ROOT}\n"
              "Распакуйте архив целиком, чтобы рядом с main.py были папки satsim, assets и др.")
    wait_key()
    sys.exit(1)


def enable_crash_log():
    """Аварийное завершение без исключения Python (нехватка памяти, сбой в numpy/OpenCV)
    закрывает окно без сообщения — faulthandler хотя бы записывает, где это случилось."""
    import faulthandler
    try:
        f = open(ROOT / "satcamsim_crash.log", "w", encoding="utf-8")
        faulthandler.enable(file=f, all_threads=True)
        return f
    except OSError:
        faulthandler.enable()
        return None


def main():
    check_unpacked()
    _crash_log = enable_crash_log()  # noqa: F841 — файл должен оставаться открытым
    check_python()
    check_dependencies()
    try:
        run()
    except SystemExit:
        raise
    except Exception:
        tb = traceback.format_exc()
        print("\n=== Ошибка при запуске SatCamSim ===\n" + tb)
        log = ROOT / "satcamsim_error.log"
        try:
            log.write_text(f"Python {sys.version}\n{sys.executable}\n\n{tb}", encoding="utf-8")
            print(f"Текст ошибки сохранён в {log}")
        except OSError:
            pass
        wait_key()
        sys.exit(1)


if __name__ == "__main__":
    main()
