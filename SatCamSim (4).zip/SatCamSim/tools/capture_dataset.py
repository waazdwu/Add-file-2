"""Генерация набора кадров бортовой камеры без интерфейса (детерминированно).

Примеры:
    python tools/capture_dataset.py --duration 5600 --step 10
    python tools/capture_dataset.py --scenario scenarios/sso_horizon.json --duration 600 --step 2 --mp4

Результат: output/<имя>/frames/*.png, telemetry.csv (метаданные каждого кадра),
camera_intrinsics.json, scenario.json.
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from satsim.config import SimConfig          # noqa: E402
from satsim.engine import Engine             # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenario", help="JSON-файл сценария (сохраняется из интерфейса)")
    ap.add_argument("--duration", type=float, default=600.0, help="длительность, модельные секунды")
    ap.add_argument("--step", type=float, default=5.0, help="шаг между кадрами, модельные секунды")
    ap.add_argument("--start", type=float, default=0.0, help="начальный момент от эпохи, с")
    ap.add_argument("--out", default="output", help="корневая папка для результатов")
    ap.add_argument("--name", default=None, help="имя папки прогона")
    ap.add_argument("--mp4", action="store_true", help="дополнительно собрать видео video.mp4")
    ap.add_argument("--no-png", action="store_true", help="не сохранять отдельные PNG")
    ap.add_argument("--seed", type=int, default=0, help="зерно шума матрицы (для воспроизводимости)")
    ap.add_argument("--scale", type=int, default=1,
                    help="уменьшение разрешения кадра (1 — полное разрешение матрицы, 2 — вдвое меньше и т.д.)")
    args = ap.parse_args()

    cfg = SimConfig.load(args.scenario) if args.scenario else SimConfig()
    eng = Engine(cfg, output_dir=args.out)
    print(f"Текстура Земли: {eng.renderer.texture_source}")
    run = eng.recorder.start(cfg.to_dict(), save_png=not args.no_png, save_mp4=args.mp4, name=args.name)
    n = int(args.duration // args.step) + 1
    t0 = time.time()
    for k in range(n):
        t = args.start + k * args.step
        fr = eng.capture_at(t, seed=args.seed + k, scale=args.scale)   # воспроизводимый шум матрицы
        fr.index = k
        fr.meta["frame_index"] = k
        eng.recorder.push(fr)
        if k % 10 == 0 or k == n - 1:
            print(f"\r{k + 1}/{n} кадров, t = {t:.0f} с, {fr.meta['light']:<8}", end="", flush=True)
    eng.close()
    print(f"\nГотово за {time.time() - t0:.1f} с → {run}")


if __name__ == "__main__":
    main()
